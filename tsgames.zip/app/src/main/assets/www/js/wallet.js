/*
 * TSGames — Módulo único da carteira
 * Uma criação de Thalisson Torricelli.
 *
 * ÚNICO ponto que altera saldos e movimentações. As telas e os jogos só
 * chamam as funções daqui. Valores guardados internamente em centavos
 * (inteiros), para evitar erros de ponto flutuante.
 *
 * Regras dos campos:
 *  - available   : saldo livre para usar.
 *  - reserved    : valor separado em saques em análise e apostas em aberto.
 *  - total       : available + reserved.
 *  - deposits    : soma dos depósitos concluídos.
 *  - withdrawals : soma dos saques aprovados.
 *  - gameResult  : soma de (prêmios − valores apostados) das apostas liquidadas.
 *  Identidade: total = crédito inicial + deposits − withdrawals + gameResult + ajustes.
 *
 * Todas as operações são locais (armazenamento do aparelho). Nada é enviado
 * para fora e não existe integração financeira.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  } else {
    root.TS = root.TS || {};
    root.TS.Wallet = api;
    if (root.TS.store) root.TS.wallet = api.create({ storage: root.TS.store });
  }
})(typeof window !== "undefined" ? window : this, function () {
  "use strict";

  var KEY = "wallet";
  var MAXTX = 1000;
  var INITIAL_CREDIT = 125000; // R$ 1.250,00 em centavos

  var STATUS = {
    completed: "Concluído", review: "Em análise", approved: "Aprovado",
    rejected: "Recusado", cancelled: "Cancelado", open: "Em aberto",
    won: "Ganhou", lost: "Perdeu", refunded: "Devolvida"
  };
  var CATEGORY = {
    deposit: "Depósitos", withdraw: "Saques", bet: "Apostas",
    prize: "Prêmios", adjust: "Ajustes"
  };

  function fmt(c) {
    return (c / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }
  function pad(n, w) { var s = String(n); while (s.length < w) s = "0" + s; return s; }

  // Aceita "1.250,50", "R$ 1250,5", "12.5", 12.5. Retorna NaN se inválido.
  function parseBRL(v) {
    if (typeof v === "number") return v;
    var s = String(v == null ? "" : v).replace(/R\$|\s/g, "");
    if (!s) return NaN;
    if (s.indexOf(",") >= 0) s = s.replace(/\./g, "").replace(",", ".");
    else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
    return /^\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
  }
  function toC(v) {
    var n = parseBRL(v);
    if (typeof n !== "number" || !isFinite(n) || n <= 0 || n > 1e9) return null;
    return Math.round(n * 100);
  }
  function fail(msg) { return { ok: false, error: msg }; }

  function memStore() {
    var m = {};
    return {
      get: function (k, d) { return k in m ? JSON.parse(JSON.stringify(m[k])) : d; },
      set: function (k, v) { m[k] = JSON.parse(JSON.stringify(v)); return true; }
    };
  }

  function create(opts) {
    opts = opts || {};
    var storage = opts.storage || memStore();
    var clock = opts.now || function () { return Date.now(); };
    var listeners = [];
    var st;

    function fresh() {
      return {
        v: 1, available: 0, reserved: 0, deposits: 0, withdrawals: 0, gameResult: 0,
        seq: 0, tx: [], pending: {}, keys: [],
        settings: {
          minDeposit: 1000, maxDeposit: 1000000,
          minWithdraw: 2000, maxWithdraw: 500000, autoApproveMs: 20000
        }
      };
    }

    function nextId() { st.seq += 1; return "TSG-" + pad(st.seq, 6); }

    // Única função que altera o saldo disponível. Sempre gera lançamento.
    function post(o) {
      var before = st.available;
      st.available += o.delta;
      var e = {
        id: nextId(), ref: o.ref || null, type: o.type, category: o.category,
        desc: o.desc, amount: o.delta, before: before, after: st.available,
        status: o.status, ts: clock()
      };
      st.tx.push(e);
      if (st.tx.length > MAXTX) st.tx.splice(0, st.tx.length - MAXTX);
      return e;
    }
    function find(id) {
      for (var i = st.tx.length - 1; i >= 0; i--) if (st.tx[i].id === id) return st.tx[i];
      return null;
    }
    function dup(key) {
      if (!key) return null;
      for (var i = 0; i < st.keys.length; i++) if (st.keys[i][0] === key) return st.keys[i][1];
      return null;
    }
    function remember(key, id) {
      if (!key) return;
      st.keys.push([key, id]);
      if (st.keys.length > 300) st.keys.shift();
    }
    function commit() {
      storage.set(KEY, st);
      listeners.slice().forEach(function (fn) { try { fn(); } catch (e) { /* ignora */ } });
    }

    function load() {
      var s = storage.get(KEY, null);
      if (s && s.v === 1) { st = s; return; }
      st = fresh();
      post({ type: "Crédito inicial", category: "adjust", desc: "Crédito inicial",
             delta: INITIAL_CREDIT, status: "completed" });
      storage.set(KEY, st);
    }
    load();

    // ---------- Depósito ----------
    function deposit(value, o) {
      o = o || {};
      var d = dup(o.key);
      if (d) return { ok: true, duplicate: true, id: d };
      var c = toC(value);
      if (c === null) return fail("Informe um valor válido.");
      var S = st.settings;
      if (c < S.minDeposit) return fail("O valor mínimo é " + fmt(S.minDeposit) + ".");
      if (c > S.maxDeposit) return fail("O valor máximo é " + fmt(S.maxDeposit) + ".");
      var e = post({ type: "Depósito", category: "deposit", desc: "Depósito",
                     delta: c, status: "completed" });
      st.deposits += c;
      remember(o.key, e.id);
      commit();
      return { ok: true, id: e.id };
    }

    // ---------- Saque: reserva o valor até a solicitação ser resolvida ----------
    function requestWithdraw(value, o) {
      o = o || {};
      var d = dup(o.key);
      if (d) return { ok: true, duplicate: true, id: d };
      var c = toC(value);
      if (c === null) return fail("Informe um valor válido.");
      var S = st.settings;
      if (c < S.minWithdraw) return fail("O valor mínimo é " + fmt(S.minWithdraw) + ".");
      if (c > S.maxWithdraw) return fail("O valor máximo é " + fmt(S.maxWithdraw) + ".");
      if (c > st.available) return fail("Saldo disponível insuficiente.");
      var e = post({ type: "Saque", category: "withdraw", desc: "Carteira TSGames",
                     delta: -c, status: "review" });
      st.reserved += c;
      st.pending[e.id] = { kind: "withdraw", amount: c };
      remember(o.key, e.id);
      commit();
      return { ok: true, id: e.id };
    }

    // Transições permitidas: review -> approved | rejected | cancelled.
    function resolveWithdrawal(id, outcome) {
      var p = st.pending[id];
      if (!p || p.kind !== "withdraw") return fail("Esta solicitação já foi finalizada.");
      if (["approved", "rejected", "cancelled"].indexOf(outcome) < 0) return fail("Status inválido.");
      var e = find(id);
      st.reserved -= p.amount;
      delete st.pending[id];
      if (outcome === "approved") {
        st.withdrawals += p.amount;
      } else {
        post({ type: "Estorno de saque", category: "withdraw", desc: "Ref. " + id,
               delta: p.amount, status: "completed", ref: id });
      }
      if (e) e.status = outcome;
      commit();
      return { ok: true };
    }

    // Aprova automaticamente saques em análise após o tempo configurado.
    function processPending() {
      var ms = st.settings.autoApproveMs, n = 0;
      if (!ms) return 0;
      Object.keys(st.pending).forEach(function (id) {
        var p = st.pending[id];
        if (p.kind !== "withdraw") return;
        var e = find(id);
        if (clock() - (e ? e.ts : 0) >= ms && resolveWithdrawal(id, "approved").ok) n++;
      });
      return n;
    }

    // ---------- Apostas e jogos ----------
    function placeBet(value, o) {
      o = o || {};
      var d = dup(o.key);
      if (d) return { ok: true, duplicate: true, id: d };
      var c = toC(value);
      if (c === null) return fail("Informe um valor válido.");
      if (c > st.available) return fail("Saldo disponível insuficiente.");
      var e = post({ type: "Aposta", category: "bet", desc: o.desc || "Aposta",
                     delta: -c, status: "open" });
      st.reserved += c;
      st.pending[e.id] = { kind: "bet", amount: c };
      remember(o.key, e.id);
      commit();
      return { ok: true, id: e.id };
    }

    function payoutC(v) {
      var n = Number(v);
      if (!isFinite(n) || n < 0 || n > 1e9) return null;
      return Math.round(n * 100);
    }

    function settleBet(id, payout) {
      var p = st.pending[id];
      if (!p || p.kind !== "bet") return fail("Esta aposta já foi liquidada.");
      var c = payoutC(payout);
      if (c === null) return fail("Prêmio inválido.");
      var e = find(id);
      st.reserved -= p.amount;
      delete st.pending[id];
      st.gameResult += c - p.amount;
      var status = c > p.amount ? "won" : (c === p.amount ? "refunded" : "lost");
      if (e) e.status = status;
      if (c > 0) {
        post({ type: "Prêmio", category: "prize", desc: "Ref. " + id,
               delta: c, status: "completed", ref: id });
      }
      commit();
      return { ok: true, payout: c / 100, status: status };
    }

    // Aposta + liquidação em uma única operação (jogos instantâneos).
    function playRound(stake, payout, o) {
      o = o || {};
      var d = dup(o.key);
      if (d) return { ok: true, duplicate: true, id: d };
      if (payoutC(payout) === null) return fail("Prêmio inválido.");
      var r = placeBet(stake, o);
      if (!r.ok) return r;
      var s = settleBet(r.id, payout);
      return s.ok ? { ok: true, id: r.id, payout: s.payout, status: s.status } : s;
    }

    // ---------- Ajuste administrativo local ----------
    function adjust(value, desc) {
      var n = Number(value);
      if (!isFinite(n) || n === 0 || Math.abs(n) > 1e9) return fail("Informe um valor válido.");
      var c = Math.round(n * 100);
      if (st.available + c < 0) return fail("O ajuste deixaria o saldo negativo.");
      var e = post({ type: "Ajuste", category: "adjust", desc: desc || "Ajuste administrativo",
                     delta: c, status: "completed" });
      commit();
      return { ok: true, id: e.id };
    }

    // ---------- Configurações (em reais) ----------
    function getSettings() {
      var S = st.settings;
      return {
        minDeposit: S.minDeposit / 100, maxDeposit: S.maxDeposit / 100,
        minWithdraw: S.minWithdraw / 100, maxWithdraw: S.maxWithdraw / 100,
        autoApproveMs: S.autoApproveMs
      };
    }
    function setSettings(o) {
      var S = JSON.parse(JSON.stringify(st.settings));
      ["minDeposit", "maxDeposit", "minWithdraw", "maxWithdraw"].forEach(function (k) {
        if (o[k] != null) { var c = toC(o[k]); if (c !== null) S[k] = c; }
      });
      if (o.autoApproveMs != null && isFinite(o.autoApproveMs) && o.autoApproveMs >= 0) {
        S.autoApproveMs = Math.floor(o.autoApproveMs);
      }
      if (S.minDeposit > S.maxDeposit || S.minWithdraw > S.maxWithdraw) {
        return fail("O mínimo não pode ser maior que o máximo.");
      }
      st.settings = S;
      commit();
      return { ok: true };
    }

    // ---------- Consultas ----------
    function summary() {
      return {
        available: st.available / 100, reserved: st.reserved / 100,
        total: (st.available + st.reserved) / 100,
        deposits: st.deposits / 100, withdrawals: st.withdrawals / 100,
        gameResult: st.gameResult / 100
      };
    }
    function view(e) {
      return {
        id: e.id, ref: e.ref, type: e.type, category: e.category,
        categoryLabel: CATEGORY[e.category] || e.category, desc: e.desc,
        amount: e.amount / 100, before: e.before / 100, after: e.after / 100,
        status: e.status, statusLabel: STATUS[e.status] || e.status, ts: e.ts
      };
    }
    // o: { category, status, order: "desc"|"asc", limit }
    function list(o) {
      o = o || {};
      var rows = st.tx.filter(function (e) {
        return (!o.category || o.category === "all" || e.category === o.category) &&
               (!o.status || o.status === "all" || e.status === o.status);
      });
      if (o.order !== "asc") rows = rows.slice().reverse();
      if (o.limit) rows = rows.slice(0, o.limit);
      return rows.map(view);
    }
    // Apostas em aberto (reservadas): [{ id, amount, desc }].
    function openBets() {
      return Object.keys(st.pending).filter(function (id) { return st.pending[id].kind === "bet"; })
        .map(function (id) { var e = find(id); return { id: id, amount: st.pending[id].amount / 100, desc: e ? e.desc : "" }; });
    }
    function pendingWithdrawals() {
      return list({ category: "withdraw", status: "review" });
    }

    function csvText(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
    function csvNum(n) { return n.toFixed(2).replace(".", ","); }
    function toCSV(rows) {
      var lines = ["id;data;tipo;categoria;descricao;valor;saldo_anterior;saldo_posterior;status"];
      rows.forEach(function (r) {
        lines.push([
          r.id, new Date(r.ts).toISOString(), csvText(r.type), csvText(r.categoryLabel),
          csvText(r.desc), csvNum(r.amount), csvNum(r.before), csvNum(r.after),
          csvText(r.statusLabel)
        ].join(";"));
      });
      return lines.join("\n");
    }

    // Verifica as regras internas da carteira.
    function check() {
      var errors = [], sumPending = 0;
      if (st.available < 0) errors.push("saldo disponível negativo");
      if (st.reserved < 0) errors.push("saldo reservado negativo");
      Object.keys(st.pending).forEach(function (id) { sumPending += st.pending[id].amount; });
      if (sumPending !== st.reserved) errors.push("reservado diferente das pendências");
      var last = st.tx[st.tx.length - 1];
      if (last && last.after !== st.available) errors.push("extrato desalinhado do saldo");
      for (var i = 1; i < st.tx.length; i++) {
        if (st.tx[i].before !== st.tx[i - 1].after) { errors.push("encadeamento quebrado em " + st.tx[i].id); break; }
      }
      return { ok: errors.length === 0, errors: errors };
    }

    function reset() {
      st = fresh();
      post({ type: "Crédito inicial", category: "adjust", desc: "Crédito inicial",
             delta: INITIAL_CREDIT, status: "completed" });
      commit();
      return { ok: true };
    }
    function on(fn) {
      listeners.push(fn);
      return function () { listeners = listeners.filter(function (f) { return f !== fn; }); };
    }

    return {
      deposit: deposit, requestWithdraw: requestWithdraw, resolveWithdrawal: resolveWithdrawal,
      processPending: processPending, placeBet: placeBet, settleBet: settleBet,
      playRound: playRound, adjust: adjust, getSettings: getSettings, setSettings: setSettings,
      summary: summary, list: list, openBets: openBets, pendingWithdrawals: pendingWithdrawals, toCSV: toCSV,
      check: check, reset: reset, on: on
    };
  }

  return { create: create, parseBRL: parseBRL, fmt: fmt, STATUS: STATUS, CATEGORY: CATEGORY };
});
