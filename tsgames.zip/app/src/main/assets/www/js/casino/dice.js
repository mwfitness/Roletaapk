/* TSGames — Dados (soma de 2 dados). Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic.dice, ui = TS.ui, brl = TS.brl;
  var type = "under7", busy = false, settle = null, iv = 0, FACES = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
  TS.pages.dice = function () {
    busy = false; settle = null; clearInterval(iv);
    TS.onLeave = function () { clearInterval(iv); if (settle) settle(); };
    return ui.head("Dados", "casino") +
      '<div class="dices" id="dfaces"><span>⚃</span><span>⚂</span></div><div class="say" id="dsay">Escolha a aposta e role</div>' +
      '<div class="grid">' + Object.keys(L.TYPES).map(function (k) {
        var t = L.TYPES[k], r = L.rtp(k);
        return '<div class="tile" data-dt="' + k + '" style="' + (type === k ? "border-color:var(--gold)" : "") + '"><b>' + t.name + "</b><span>Paga " + ui.x(t.mult) + " · " + ui.pct(r.probability) + "</span></div>";
      }).join("") + "</div>" + ui.stake("dstake", "5,00") +
      '<button class="btn primary full" id="dgo">Rolar</button>' +
      ui.rules("São lançados dois dados de 6 faces (36 combinações equiprováveis)." +
        "<table><tr><th>Aposta</th><th>Combinações</th><th>Chance</th><th>Retorno teórico</th></tr>" +
        Object.keys(L.TYPES).map(function (k) { var r = L.rtp(k); return "<tr><td>" + L.TYPES[k].name + "</td><td>" + r.combos + "/36</td><td>" + ui.pct(r.probability) + "</td><td>" + ui.pct(r.rtp) + "</td></tr>"; }).join("") +
        "</table>O valor pago é o retorno total (inclui o valor apostado).") + ui.hist("dice");
  };
  document.addEventListener("click", function (e) {
    if (TS.current !== "dice") return;
    var tt = e.target.closest("[data-dt]");
    if (tt) { if (!busy) { type = tt.getAttribute("data-dt"); TS.refresh(); } return; }
    if (!e.target.closest("#dgo") || busy) return;
    var bet = ui.bet("dstake", "Cassino · Dados"); if (!bet) return;
    var r = L.roll(), win = L.wins(type, r[0], r[1]), tp = type, done = false;
    busy = true; ui.say("dsay", "Rolando…", "info");
    var box = ui.el("dfaces"); box.classList.add("roll");
    iv = setInterval(function () { if (box) box.innerHTML = "<span>" + FACES[Math.floor(Math.random() * 6)] + "</span><span>" + FACES[Math.floor(Math.random() * 6)] + "</span>"; }, 90);
    settle = function () {
      if (done) return; done = true; settle = null; busy = false; clearInterval(iv);
      var p = ui.finish("dice", bet, win ? bet.stake * L.TYPES[tp].mult : 0, r[0] + "+" + r[1] + "=" + (r[0] + r[1]) + " · " + L.TYPES[tp].name);
      var b = ui.el("dfaces");
      if (TS.current === "dice" && b) {
        b.classList.remove("roll"); b.innerHTML = "<span>" + FACES[r[0] - 1] + "</span><span>" + FACES[r[1] - 1] + "</span>";
        ui.say("dsay", "Soma " + (r[0] + r[1]) + " · " + (win ? "Você ganhou " + brl(p) : "Sem retorno"), win ? "win" : "lose"); ui.refreshHist("dice");
      }
    };
    setTimeout(function () { if (settle) settle(); }, 1300);
  });
})(window);
