/*
 * TSGames — Páginas da carteira: Carteira, Depositar, Sacar e Extrato.
 * Uma criação de Thalisson Torricelli.
 * Depende de: storage.js, router.js, engine.js (opcional), wallet.js.
 * Não altera saldos diretamente: tudo passa por TS.wallet.
 */
(function (g) {
  var TS = g.TS, W = TS.wallet, brl = TS.brl, P = TS.Wallet.parseBRL;
  var ui = { filter: "all", order: "desc", depKey: null, wdKey: null };
  var FILTERS = [["all", "Todos"], ["deposit", "Depósitos"], ["withdraw", "Saques"],
                 ["bet", "Apostas"], ["prize", "Prêmios"], ["adjust", "Ajustes"]];

  TS.parentTab = TS.parentTab || {};
  TS.parentTab.deposit = TS.parentTab.withdraw = TS.parentTab.statement = "wallet";

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function newKey(p) { return p + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function fdate(ts) {
    var d = new Date(ts);
    return d.toLocaleDateString("pt-BR") + " " +
      d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }
  function signed(n) { return (n > 0 ? "+ " : n < 0 ? "− " : "") + brl(Math.abs(n)); }
  TS.fmt = { esc: esc, signed: signed, fdate: fdate };

  var toastTimer;
  TS.toast = function (msg, kind) {
    var t = document.getElementById("toast");
    if (!t) { t = document.createElement("div"); t.id = "toast"; document.body.appendChild(t); }
    t.textContent = msg;
    t.className = (kind === "err" ? "err " : "") + "show";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = kind === "err" ? "err" : ""; }, 2600);
  };

  function row(r, opt) {
    opt = opt || {};
    return '<div class="tx"><div class="l"><b>' + esc(r.type) + "</b>" +
      (r.desc !== r.type ? '<div class="muted">' + esc(r.desc) + "</div>" : "") +
      '<div class="muted small">' + fdate(r.ts) + " · " + r.id + "</div>" +
      (opt.detail ? '<div class="muted small">Saldo: ' + brl(r.before) + " → " + brl(r.after) + "</div>" : "") +
      '</div><div class="r"><div class="amt ' + (r.amount > 0 ? "pos" : "") + '">' + signed(r.amount) + "</div>" +
      '<span class="badge st-' + r.status + '">' + r.statusLabel + "</span>" +
      (opt.cancel && r.status === "review" ? '<button class="mini" data-cancel="' + r.id + '">Cancelar</button>' : "") +
      "</div></div>";
  }
  function rows(list, opt) {
    return list.length ? list.map(function (r) { return row(r, opt); }).join("")
                       : '<div class="empty">Nenhuma movimentação.</div>';
  }
  function stat(label, key, s) {
    return '<div class="stat"><div class="k">' + label + '</div><div class="v" data-bal="' + key + '">' + brl(s[key]) + "</div></div>";
  }
  function chips(forId, values, extra) {
    return '<div class="scroller chips">' + values.map(function (v) {
      return '<div class="pill" data-for="' + forId + '" data-amt="' + v + '">' + brl(v).replace(",00", "") + "</div>";
    }).join("") + (extra || "") + "</div>";
  }

  // ---------------- Carteira ----------------
  TS.pages.wallet = function () {
    var s = W.summary(), pend = W.pendingWithdrawals();
    return "<h1>Carteira</h1>" +
      '<div class="card balance"><div class="label">Saldo disponível</div>' +
      '<div class="value" data-bal="available">' + brl(s.available) + "</div>" +
      '<div class="row"><button class="btn primary" data-go="deposit">Depositar</button>' +
      '<button class="btn" data-go="withdraw">Sacar</button></div></div>' +
      '<div class="grid stats">' + stat("Reservado", "reserved", s) + stat("Total", "total", s) +
      stat("Depósitos", "deposits", s) + stat("Saques", "withdrawals", s) + "</div>" +
      '<div class="stat" style="margin-bottom:12px"><div class="k">Resultado dos jogos</div>' +
      '<div class="v" data-bal="gameResult">' + brl(s.gameResult) + "</div></div>" +
      (pend.length ? "<h2>Saques em andamento</h2><div class=\"card\">" + rows(pend, { cancel: true }) + "</div>" : "") +
      "<h2>Últimas movimentações</h2>" +
      '<div class="card">' + rows(W.list({ limit: 5 })) +
      '<button class="btn full" data-go="statement">Ver extrato completo</button></div>';
  };

  // ---------------- Depositar ----------------
  TS.pages.deposit = function () {
    ui.depKey = newKey("dep");
    var S = W.getSettings(), s = W.summary();
    return "<h1>Depositar</h1>" +
      '<div class="card balance"><div class="label">Saldo disponível</div>' +
      '<div class="value" data-bal="available">' + brl(s.available) + "</div></div>" +
      '<div class="card"><div class="muted">Valor do depósito</div>' +
      '<input class="field" id="depAmt" inputmode="decimal" autocomplete="off" placeholder="R$ 0,00" style="margin-top:8px">' +
      chips("depAmt", [50, 100, 200, 500, 1000]) +
      '<div class="muted small">Mínimo ' + brl(S.minDeposit) + " · Máximo " + brl(S.maxDeposit) + "</div>" +
      '<div class="sum" id="depSum"></div>' +
      '<button class="btn primary full" id="depGo">Confirmar depósito</button></div>' +
      "<h2>Histórico</h2>" +
      '<div class="card">' + rows(W.list({ category: "deposit", limit: 10 })) + "</div>";
  };
  TS.pages.deposit.after = function () { updateSum("dep"); };

  // ---------------- Sacar ----------------
  TS.pages.withdraw = function () {
    ui.wdKey = newKey("wd");
    var S = W.getSettings(), s = W.summary();
    return "<h1>Sacar</h1>" +
      '<div class="card balance"><div class="label">Saldo disponível</div>' +
      '<div class="value" data-bal="available">' + brl(s.available) + "</div></div>" +
      '<div class="card"><div class="muted">Valor do saque</div>' +
      '<input class="field" id="wdAmt" inputmode="decimal" autocomplete="off" placeholder="R$ 0,00" style="margin-top:8px">' +
      chips("wdAmt", [50, 100, 250, 500], '<div class="pill" data-for="wdAmt" data-amt="all">Tudo</div>') +
      '<div class="muted small">Mínimo ' + brl(S.minWithdraw) + " · Máximo " + brl(S.maxWithdraw) + "</div>" +
      '<div class="method"><span>Método</span><b>Carteira TSGames</b></div>' +
      '<div class="sum" id="wdSum"></div>' +
      '<button class="btn primary full" id="wdGo">Solicitar saque</button></div>' +
      "<h2>Solicitações</h2>" +
      '<div class="card">' + rows(W.list({ category: "withdraw", limit: 10 }), { cancel: true }) + "</div>";
  };
  TS.pages.withdraw.after = function () { updateSum("wd"); };

  function updateSum(kind) {
    var inp = document.getElementById(kind + "Amt"), box = document.getElementById(kind + "Sum");
    if (!inp || !box) return;
    var n = P(inp.value), ok = typeof n === "number" && isFinite(n) && n > 0, s = W.summary();
    function r(a, b) { return '<div class="sumrow"><span>' + a + "</span><b>" + b + "</b></div>"; }
    box.innerHTML = r("Valor", ok ? brl(n) : "—") + r("Taxa", brl(0)) +
      r("Saldo após a operação", ok ? brl(kind === "dep" ? s.available + n : s.available - n) : "—") +
      (kind === "wd" ? r("Status inicial", "Em análise") : "");
  }

  // ---------------- Extrato ----------------
  function stmtRows() { return W.list({ category: ui.filter, order: ui.order }); }
  TS.pages.statement = function () {
    var list = stmtRows();
    return "<h1>Extrato</h1>" +
      '<div class="scroller">' + FILTERS.map(function (f) {
        return '<div class="pill' + (ui.filter === f[0] ? " on" : "") + '" data-f="' + f[0] + '">' + f[1] + "</div>";
      }).join("") + "</div>" +
      '<div class="bar"><button class="btn" data-order="' + (ui.order === "desc" ? "asc" : "desc") + '">' +
      (ui.order === "desc" ? "Mais recentes" : "Mais antigos") + '</button>' +
      '<button class="btn" id="csvBtn">Exportar CSV</button></div>' +
      '<div class="card">' + rows(list, { detail: true }) + "</div>" +
      '<div id="csvBox"></div>';
  };

  // ---------------- Eventos (delegação única) ----------------
  document.addEventListener("input", function (e) {
    if (e.target.id === "depAmt") updateSum("dep");
    if (e.target.id === "wdAmt") updateSum("wd");
  });

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-amt],[data-cancel],[data-f],[data-order],#depGo,#wdGo,#csvBtn");
    if (!t) return;

    if (t.hasAttribute("data-amt")) {
      var inp = document.getElementById(t.getAttribute("data-for")), v = t.getAttribute("data-amt");
      if (!inp) return;
      var n = v === "all" ? Math.min(W.summary().available, W.getSettings().maxWithdraw) : Number(v);
      inp.value = n.toFixed(2).replace(".", ",");
      updateSum(inp.id === "depAmt" ? "dep" : "wd");
      return;
    }
    if (t.hasAttribute("data-cancel")) {
      var rc = W.resolveWithdrawal(t.getAttribute("data-cancel"), "cancelled");
      TS.toast(rc.ok ? "Saque cancelado" : rc.error, rc.ok ? "" : "err");
      TS.go(TS.current);
      return;
    }
    if (t.hasAttribute("data-f")) { ui.filter = t.getAttribute("data-f"); TS.go("statement"); return; }
    if (t.hasAttribute("data-order")) { ui.order = t.getAttribute("data-order"); TS.go("statement"); return; }

    if (t.id === "depGo") {
      var di = document.getElementById("depAmt");
      t.disabled = true;
      var rd = W.deposit(di.value, { key: ui.depKey });
      if (!rd.ok) { TS.toast(rd.error, "err"); t.disabled = false; return; }
      if (!rd.duplicate) TS.toast("Depósito concluído");
      TS.go("deposit");
      return;
    }
    if (t.id === "wdGo") {
      var wi = document.getElementById("wdAmt");
      t.disabled = true;
      var rw = W.requestWithdraw(wi.value, { key: ui.wdKey });
      if (!rw.ok) { TS.toast(rw.error, "err"); t.disabled = false; return; }
      if (!rw.duplicate) TS.toast("Saque solicitado");
      TS.go("withdraw");
      return;
    }
    if (t.id === "csvBtn") {
      var csv = W.toCSV(stmtRows()), box = document.getElementById("csvBox");
      box.innerHTML = '<textarea class="csv" id="csvText" readonly>' + esc(csv) + "</textarea>";
      var ta = document.getElementById("csvText");
      ta.focus(); ta.select();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(csv).then(function () { TS.toast("CSV copiado"); },
          function () { TS.toast("Copie o texto selecionado"); });
      } else { TS.toast("Copie o texto selecionado"); }
    }
  });
})(window);
