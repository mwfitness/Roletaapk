/*
 * TSGames — Utilitários de interface compartilhados pelos jogos.
 * Uma criação de Thalisson Torricelli.
 */
(function (g) {
  var TS = g.TS, esc = TS.fmt.esc, P = TS.Wallet.parseBRL, brl = TS.brl;
  var ui = (TS.ui = {});

  ui.prefs = function () { return TS.store.get("prefs", { name: "Jogador", avatar: 0, sound: true, theme: "esmeralda" }); };
  ui.setPref = function (k, v) { var p = ui.prefs(); p[k] = v; TS.store.set("prefs", p); };
  var THEMES = { esmeralda: "#10B981", ouro: "#C9A24B", cobalto: "#4C8DF6" };
  ui.THEMES = THEMES;
  ui.applyTheme = function () {
    document.documentElement.style.setProperty("--green", THEMES[ui.prefs().theme] || THEMES.esmeralda);
  };

  ui.sfx = function (kind) {
    try {
      if (!ui.prefs().sound) return;
      var C = g.AudioContext || g.webkitAudioContext; if (!C) return;
      ui._ac = ui._ac || new C();
      var o = ui._ac.createOscillator(), gn = ui._ac.createGain();
      o.frequency.value = { win: 660, lose: 180, tick: 420, click: 300 }[kind] || 300;
      gn.gain.value = 0.04; o.connect(gn); gn.connect(ui._ac.destination);
      o.start(); o.stop(ui._ac.currentTime + (kind === "win" ? 0.22 : 0.08));
    } catch (e) { /* som é opcional */ }
  };

  ui.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  ui.x = function (m) { return Number(m).toFixed(2).replace(".", ",") + "×"; };
  ui.pct = function (p) { return (p * 100).toFixed(2).replace(".", ",") + "%"; };
  ui.say = function (id, msg, cls) {
    var el = document.getElementById(id);
    if (el) { el.className = "say " + (cls || ""); el.textContent = msg; }
  };
  ui.el = function (id) { return document.getElementById(id); };

  ui.head = function (title, back, label) {
    return '<div class="head"><button class="back" data-go="' + back + '" aria-label="' + (label || "Voltar") + '">‹</button><h1>' + title + "</h1></div>";
  };
  ui.stake = function (id, def) {
    return '<div class="stake"><div class="muted">Valor</div>' +
      '<input class="field" id="' + id + '" inputmode="decimal" autocomplete="off" value="' + (def || "10,00") + '" style="margin-top:6px">' +
      '<div class="scroller chips">' + [5, 10, 25, 50, 100].map(function (v) {
        return '<div class="pill" data-stake="' + id + "|" + v + '">' + brl(v).replace(",00", "") + "</div>";
      }).join("") + "</div></div>";
  };
  ui.readStake = function (id) { var e = ui.el(id); return P(e ? e.value : ""); };
  ui.rules = function (html) {
    return '<details class="rules"><summary>Regras e probabilidades</summary><div>' + html + "</div></details>";
  };

  // Aposta o valor do campo na carteira (reserva). Retorna {id, stake} ou null.
  ui.bet = function (stakeId, desc) {
    var s = ui.readStake(stakeId);
    var r = TS.wallet.placeBet(s, { desc: desc });
    if (!r.ok) { TS.toast(r.error, "err"); return null; }
    return { id: r.id, stake: Math.round(s * 100) / 100 };
  };
  // Liquida a aposta e registra no histórico.
  ui.finish = function (game, bet, payout, detail) {
    payout = Math.round(payout * 100) / 100;
    TS.wallet.settleBet(bet.id, payout);
    TS.stats.record(game, bet.stake, payout, detail);
    ui.sfx(payout > bet.stake ? "win" : "lose");
    return payout;
  };
  ui.hist = function (game) {
    var l = TS.stats.list(game, 8);
    return "<h2>Últimas rodadas</h2><div class=\"card hist\" id=\"hist-" + game + "\">" + ui.histRows(l) + "</div>";
  };
  ui.histRows = function (l) {
    if (!l.length) return '<div class="empty muted">Nenhuma rodada ainda.</div>';
    return l.map(function (x) {
      var net = x.payout - x.stake;
      return '<div class="hrow"><span>' + esc(x.detail) + '</span><b class="' + (net > 0 ? "pos" : "") + '">' + TS.fmt.signed(Math.round(net * 100) / 100) + "</b></div>";
    }).join("");
  };
  ui.refreshHist = function (game) {
    var b = ui.el("hist-" + game); if (b) b.innerHTML = ui.histRows(TS.stats.list(game, 8));
  };

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-stake]");
    if (!t) return;
    var p = t.getAttribute("data-stake").split("|"), inp = ui.el(p[0]);
    if (inp) inp.value = Number(p[1]).toFixed(2).replace(".", ",");
    ui.sfx("click");
  });
})(window);
