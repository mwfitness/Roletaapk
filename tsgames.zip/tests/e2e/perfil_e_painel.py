import os
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH","/opt/pw-browsers")
from playwright.sync_api import sync_playwright
ROOT="file://"+os.path.abspath(os.path.join(os.path.dirname(__file__),"..","..","app/src/main/assets/www/index.html"))
errors=[]; ok=[]
def chk(n,c,x=""): (ok if c else errors).append(("OK " if c else "FALHA ")+n+(" "+str(x) if x!="" else ""))
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":390,"height":780})
    pg.on("pageerror", lambda e: errors.append("pageerror: "+str(e)))
    pg.on("console", lambda m: errors.append("console."+m.type+": "+m.text) if m.type=="error" else None)
    pg.on("dialog", lambda d: d.accept())
    pg.goto(ROOT); pg.wait_for_timeout(2000); pg.click("#welcomeOk")
    # Perfil: nome e avatar
    pg.click('#nav button[data-go="profile"]'); pg.wait_for_timeout(250)
    pg.fill("#pname","Thalisson"); pg.click("#pnameSave"); pg.wait_for_timeout(250)
    pg.click('#nav button[data-go="home"]'); pg.wait_for_timeout(250)
    chk("nome salvo aparece no Início", "Thalisson" in pg.inner_text("#view h1"), pg.inner_text("#view h1"))
    # Início: busca
    inp=pg.locator("#view input.field").first
    inp.fill("roleta"); pg.wait_for_timeout(300)
    chk("busca no Início responde", len(pg.inner_text("#view"))>200)
    # Painel: criar PIN
    pg.click('#nav button[data-go="profile"]'); pg.click('[data-go="adminlogin"]'); pg.wait_for_timeout(200)
    pg.fill("#pin1","12"); pg.fill("#pin2","12"); pg.click("#pinGo"); pg.wait_for_timeout(200)
    chk("PIN curto é rejeitado", pg.locator("#pin1").count()==1)
    pg.fill("#pin1","2468"); pg.fill("#pin2","2468"); pg.click("#pinGo"); pg.wait_for_timeout(300)
    chk("painel abre após criar PIN", pg.locator("[data-atab]").count()>=5, pg.locator("[data-atab]").count())
    # Eventos: editar cotação, simular e encerrar
    pg.click('[data-atab="events"]'); pg.wait_for_timeout(200)
    pg.locator('.teams[data-go="adminevent"]').first.click(); pg.wait_for_timeout(250)
    chk("tela de evento do admin", pg.locator("#evSim").count()==1)
    first=pg.locator("[data-odd]").first; first.fill("2,50"); pg.click("#oddSave"); pg.wait_for_timeout(250)
    ev0=pg.evaluate("TS.sports.list('all')[0]")
    chk("cotação editada persiste", abs(ev0['markets'][0]['sels'][0]['odds']-2.5)<1e-9, ev0['markets'][0]['sels'][0]['odds'])
    pg.click("#evSim"); pg.wait_for_timeout(300)
    chk("evento encerrado pelo admin", pg.evaluate("TS.sports.list('all')[0].status")=="finished")
    chk("ações registradas no log", pg.evaluate("TS.store.get('adminlog',[]).length")>=2, pg.evaluate("TS.store.get('adminlog',[]).length"))
    # Dados: ajuste de saldo
    pg.click('#nav button[data-go="profile"]'); pg.click('[data-go="adminlogin"]'); pg.wait_for_timeout(250)
    if pg.locator("#pin1").count():
        pg.fill("#pin1","2468"); pg.click("#pinGo"); pg.wait_for_timeout(250)
    pg.click('[data-atab="data"]'); pg.wait_for_timeout(200)
    pg.fill("#adjV","50"); pg.fill("#adjD","teste"); pg.click("#adjGo"); pg.wait_for_timeout(250)
    chk("ajuste administrativo creditou R$ 50", pg.evaluate("TS.wallet.summary().available")==1300, pg.evaluate("TS.wallet.summary().available"))
    pg.click("#rstEv"); pg.wait_for_timeout(100); pg.click("#rstEv"); pg.wait_for_timeout(300)
    chk("eventos restaurados (todos abertos)", pg.evaluate("TS.sports.list('all').every(e=>e.status==='open')"))
    chk("carteira consistente", pg.evaluate("TS.wallet.check().ok"))
    pg.click('[data-atab="ops"]'); pg.wait_for_timeout(200)
    chk("aba Operações mostra limites", pg.locator("#lmSave").count()==1)
    pg.click('[data-atab="log"]'); pg.wait_for_timeout(150)
    chk("registro de ações visível", len(pg.inner_text("#view"))>60)
    # PIN errado
    pg.evaluate("TS.vault.check('0000')")
    chk("PIN errado recusado", pg.evaluate("TS.vault.check('0000')")==False and pg.evaluate("TS.vault.check('2468')")==True)
    pg.click('#nav button[data-go="profile"]'); pg.wait_for_timeout(200)
    pg.click("#wipe"); pg.wait_for_timeout(200); pg.click("#wipe"); pg.wait_for_timeout(2500)
    chk("apagar dados volta ao estado inicial", pg.evaluate("TS.wallet.summary().available")==1250, pg.evaluate("TS.wallet.summary().available"))
    # Sobre / créditos
    pg.evaluate("TS.go('credits')"); pg.wait_for_timeout(200)
    t=pg.inner_text("#view"); chk("créditos citam Thalisson Torricelli", "Thalisson Torricelli" in t)
    chk("sem palavra 'fake' na interface", "fake" not in pg.inner_text("body").lower())
    print(*ok,sep="\n"); print("--- erros:", *errors, sep="\n")
    b.close()
