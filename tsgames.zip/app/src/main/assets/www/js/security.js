/*
 * TSGames — Acesso ao painel local (PIN definido pelo próprio usuário).
 * Uma criação de Thalisson Torricelli.
 *
 * Não há senha fixa no código: o PIN é criado no primeiro acesso e guardado
 * apenas como resumo (hash com sal) neste aparelho. Isso evita alterações
 * acidentais, mas NÃO oferece a segurança de um sistema com servidor e
 * autenticação: quem tem acesso ao aparelho desbloqueado pode apagar os dados locais.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else { root.TS = root.TS || {}; root.TS.Security = api; if (root.TS.store) root.TS.vault = api.create({ storage: root.TS.store }); }
})(typeof window !== "undefined" ? window : this, function () {
  "use strict";
  function fnv(s) {
    var h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return (h >>> 0).toString(16);
  }
  function hash(pin, salt) { return fnv(salt + ":" + pin) + fnv(pin + "|" + salt + "|x") + fnv(salt + pin + pin); }
  function validPin(pin) { return /^\d{4,8}$/.test(String(pin)); }
  function newSalt() { return Math.random().toString(36).slice(2) + Date.now().toString(36); }

  function create(o) {
    var storage = o.storage;
    return {
      hasPin: function () { return !!storage.get("pin", null); },
      setPin: function (pin, confirm) {
        if (!validPin(pin)) return { ok: false, error: "Use de 4 a 8 dígitos." };
        if (String(pin) !== String(confirm)) return { ok: false, error: "Os PINs não conferem." };
        var salt = newSalt();
        storage.set("pin", { salt: salt, hash: hash(String(pin), salt) });
        return { ok: true };
      },
      check: function (pin) {
        var p = storage.get("pin", null);
        if (!p) return false;
        return hash(String(pin), p.salt) === p.hash;
      },
      clear: function () { storage.set("pin", null); }
    };
  }
  return { create: create, validPin: validPin, hash: hash };
});
