"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const E = require("../app/src/main/assets/www/js/engine.js");

const close = (a, b, tol = 1e-9) => assert.ok(Math.abs(a - b) <= tol, `${a} != ${b}`);

test("probabilidade implícita = 1/cotação", () => {
  close(E.impliedProbability(2), 0.5);
  close(E.impliedPercent(4), 25);
  close(E.impliedPercent(1.85), 54.054054054, 1e-6);
});

test("cotação inválida lança erro", () => {
  assert.throws(() => E.impliedProbability(1));
  assert.throws(() => E.impliedProbability(0.5));
  assert.throws(() => E.impliedProbability(NaN));
  assert.throws(() => E.impliedProbability("2"));
});

test("retorno potencial e resultado líquido", () => {
  assert.equal(E.potentialReturn(100, 1.85), 185);
  assert.equal(E.netProfit(100, 1.85), 85);
  assert.equal(E.potentialReturn(0, 3), 0);
  assert.throws(() => E.potentialReturn(-1, 2));
});

test("margem teórica do mercado", () => {
  close(E.margin([2, 2]), 0);
  close(E.margin([1.9, 3.5, 4.2]), 0.0501253, 1e-6);
});

test("probabilidades normalizadas somam 1", () => {
  const n = E.normalizedProbabilities([1.9, 3.5, 4.2]);
  close(n.reduce((a, b) => a + b, 0), 1);
  assert.ok(n[0] > n[1] && n[1] > n[2]);
});

test("cotação justa e combinada", () => {
  close(E.fairOdds(0.25), 4);
  assert.throws(() => E.fairOdds(0));
  assert.equal(E.combinedOdds([1.5, 2]), 3);
  assert.equal(E.combinedOdds([1.5]), 1.5);
  assert.throws(() => E.combinedOdds([]));
});

test("valor esperado e variância", () => {
  const fair = [{ p: 0.5, net: 1 }, { p: 0.5, net: -1 }];
  close(E.expectedValue(fair), 0);
  close(E.variance(fair), 1);
  close(E.stdDev(fair), 1);
  assert.throws(() => E.expectedValue([{ p: 0.5, net: 1 }]));
});

test("frequência observada e comparação com a teoria", () => {
  const obs = E.observedFrequencies(["a", "a", "a", "b"]);
  assert.equal(obs.a.count, 3);
  close(obs.b.freq, 0.25);
  const cmp = E.compareDistribution({ a: 0.5, b: 0.5 }, ["a", "a", "a", "b"]);
  assert.equal(cmp.n, 4);
  close(cmp.chiSquare, 1);
  assert.equal(cmp.rows[0].expectedCount, 2);
});

test("roleta europeia: 37 resultados e vantagem da casa de 1/37", () => {
  close(E.rouletteBet("straight").probability, 1 / 37);
  close(E.rouletteBet("red").probability, 18 / 37);
  close(E.rouletteBet("dozen").probability, 12 / 37);
  ["straight", "red", "black", "even", "odd", "low", "high", "dozen", "column"].forEach((t) => {
    close(E.rouletteBet(t).expectedValue, -1 / 37, 1e-12);
  });
  close(E.rouletteBet("straight").returnToPlayer, 36 / 37, 1e-12);
  assert.throws(() => E.rouletteBet("xyz"));
});

test("cores da roleta: 18 vermelhos, 18 pretos, 1 verde", () => {
  const c = { red: 0, black: 0, green: 0 };
  for (let i = 0; i <= 36; i++) c[E.rouletteColor(i)]++;
  assert.deepEqual(c, { red: 18, black: 18, green: 1 });
});

test("randomInt fica no intervalo e cobre todos os valores", () => {
  const seen = new Set();
  for (let i = 0; i < 20000; i++) {
    const v = E.randomInt(37);
    assert.ok(Number.isInteger(v) && v >= 0 && v < 37);
    seen.add(v);
  }
  assert.equal(seen.size, 37);
  assert.equal(E.randomInt(1), 0);
  assert.throws(() => E.randomInt(0));
  assert.throws(() => E.randomInt(1.5));
});
