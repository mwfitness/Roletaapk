/* TSGames — Crash. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic.crash, ui = TS.ui, brl = TS.brl;
  var R = null, raf = 0, hist = [];
  function cfg() { return TS.store.get("gcfg", { crashEdge: 0.04, crashRate: 0.15 }); }
  function stop() { cancelAnimationFrame(raf); raf = 0; }
  function setBtn() {
    var b = ui.el("cgo"); if (!b) return;
    b.textContent = R && !R.over ? "Sacar" : "Apostar"; b.className = "btn full " + (R && !R.over ? "gold" : "primary");
  }
  function finish(cashMult) {
    if (!R || R.over) return;
    R.over = true; stop();
    var cashed = cashMult && cashMult < R.point;
    var payout = cashed ? R.bet.stake * cashMult : 0;
    var p = ui.finish("crash", R.bet, payout, (cashed ? "Saque " + ui.x(cashMult) : "Crash " + ui.x(R.point)) + " · " + brl(R.bet.stake));
    hist.unshift(R.point); hist = hist.slice(0, 12);
    if (TS.current === "crash") {
      var n = ui.el("cn");
      n.textContent = ui.x(R.point); n.className = "bust";
      ui.say("csay", cashed ? "Você sacou em " + ui.x(cashMult) + " · " + brl(p) : "Crash em " + ui.x(R.point) + ". Rodada perdida.", cashed ? "win" : "lose");
      ui.el("chist").innerHTML = hist.map(function (x) { return '<span class="xchip ' + (x >= 2 ? "hi" : "lo") + '">' + ui.x(x) + "</span>"; }).join("");
      ui.refreshHist("crash"); setBtn();
    }
  }
  function loop(now) {
    if (!R || R.over) return;
    var m = L.multAt((now - R.t0) / 1000, R.rate);
    if (m >= R.point) { finish(null); return; }
    if (R.auto && m >= R.auto) { finish(R.auto); return; }
    R.cur = m; ui.el("cn").textContent = ui.x(m);
    raf = requestAnimationFrame(loop);
  }
  TS.pages.crash = function () {
    R = null; stop();
    TS.onLeave = function () { if (R && !R.over) { var m = L.multAt((performance.now() - R.t0) / 1000, R.rate); finish(m < R.point ? m : null); } };
    var c = cfg();
    return ui.head("Crash", "casino") +
      '<div class="crashbox"><div id="cn">1,00×</div></div><div class="say" id="csay">Faça sua aposta</div>' +
      '<div class="dots" id="chist">' + hist.map(function (x) { return '<span class="xchip ' + (x >= 2 ? "hi" : "lo") + '">' + ui.x(x) + "</span>"; }).join("") + "</div>" +
      ui.stake("cstake", "10,00") +
      '<div class="muted">Saque automático em (opcional)</div><input class="field" id="cauto" inputmode="decimal" placeholder="Ex.: 2,00" style="margin:6px 0 12px">' +
      '<button class="btn primary full" id="cgo">Apostar</button>' +
      ui.rules("O multiplicador sobe continuamente e a rodada termina em um ponto de crash já sorteado no início. Saque antes do crash para receber valor × multiplicador; se o crash vier antes, a aposta é perdida. " +
        "Modelo: P(crash ≥ m) = (1 − margem) ÷ m para m ≥ 1. Margem atual: " + ui.pct(c.crashEdge) + ", logo o retorno teórico é " + ui.pct(1 - c.crashEdge) + " em qualquer estratégia de saque. " +
        "Existe " + ui.pct(c.crashEdge) + " de chance de crash imediato em 1,00×. Parâmetros ajustáveis no painel local.") + ui.hist("crash");
  };
  document.addEventListener("click", function (e) {
    if (!e.target.closest("#cgo") || TS.current !== "crash") return;
    if (R && !R.over) { var m = L.multAt((performance.now() - R.t0) / 1000, R.rate); finish(m < R.point ? m : null); return; }
    var bet = ui.bet("cstake", "Cassino · Crash"); if (!bet) return;
    var c = cfg(), a = TS.Wallet.parseBRL(ui.el("cauto").value);
    R = { bet: bet, point: L.random(c.crashEdge), rate: c.crashRate, auto: a > 1 ? a : 0, over: false, t0: performance.now(), cur: 1 };
    ui.el("cn").className = ""; ui.say("csay", "Em andamento…", "info"); setBtn(); ui.sfx("tick");
    raf = requestAnimationFrame(loop);
  });
})(window);
