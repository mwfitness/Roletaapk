/* TSGames — Roleta europeia. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic, E = TS.engine, W = TS.wallet, ui = TS.ui, brl = TS.brl;
  var BETS = {}, rot = 0, busy = false, settle = null, last = [];
  var COL = { red: "#B3262D", black: "#1A1B1F", green: "#10B981" };
  var NAMES = { straight: "Número", red: "Vermelho", black: "Preto", even: "Par", odd: "Ímpar", low: "1–18", high: "19–36", dozen: "Dúzia", column: "Coluna" };
  var OUT = [["red:0", "Vermelho"], ["black:0", "Preto"], ["even:0", "Par"], ["odd:0", "Ímpar"], ["low:0", "1–18"], ["high:0", "19–36"],
             ["dozen:1", "1ª dúzia"], ["dozen:2", "2ª dúzia"], ["dozen:3", "3ª dúzia"], ["column:1", "Coluna 1"], ["column:2", "Coluna 2"], ["column:3", "Coluna 3"]];
  function bg() {
    var s = 360 / 37;
    return "conic-gradient(" + L.roulette.ORDER.map(function (n, i) {
      return COL[E.rouletteColor(n)] + " " + (i * s) + "deg " + ((i + 1) * s) + "deg";
    }).join(",") + ")";
  }
  function list() {
    return Object.keys(BETS).map(function (k) { var p = k.split(":"); return { type: p[0], v: Number(p[1]), stake: BETS[k] }; });
  }
  function total() { return Math.round(list().reduce(function (a, b) { return a + b.stake; }, 0) * 100) / 100; }
  function renderBets() {
    var el = ui.el("rbets"); if (!el) return;
    var l = list();
    el.innerHTML = l.length ? l.map(function (b) {
      return NAMES[b.type] + (b.type === "straight" ? " " + b.v : (b.v ? " " + b.v : "")) + ": " + brl(b.stake);
    }).join(" · ") + "<br><b>Total: " + brl(total()) + "</b>" : "Toque nos números ou nas apostas externas para colocar fichas.";
  }
  TS.pages.roulette = function () {
    BETS = {}; busy = false; settle = null;
    TS.onLeave = function () { if (settle) settle(); };
    var nums = '<button class="n green" data-rb="straight:0">0</button>';
    for (var i = 1; i <= 36; i++) nums += '<button class="n ' + E.rouletteColor(i) + '" data-rb="straight:' + i + '">' + i + "</button>";
    var rows = [["straight", "Número (1 número)"], ["red", "Vermelho/Preto"], ["even", "Par/Ímpar"], ["low", "1–18 / 19–36"], ["dozen", "Dúzia"], ["column", "Coluna"]];
    return ui.head("Roleta", "casino") +
      '<div class="wheelbox"><div class="ptr"></div><div class="wheel" id="wheel" style="background:' + bg() + ";transform:rotate(" + rot + 'deg)"></div></div>' +
      '<div class="say" id="rsay">Faça suas apostas</div>' +
      '<div class="dots" id="rlast">' + last.map(function (n) { return '<span class="dot ' + E.rouletteColor(n) + '">' + n + "</span>"; }).join("") + "</div>" +
      ui.stake("rstake", "5,00") +
      '<div class="board">' + nums + "</div>" +
      '<div class="outs">' + OUT.map(function (o) { return '<button class="btn" data-rb="' + o[0] + '">' + o[1] + "</button>"; }).join("") + "</div>" +
      '<div class="card bsum" id="rbets"></div>' +
      '<div class="row"><button class="btn" id="rclear">Limpar</button><button class="btn primary" id="rspin">Girar</button></div>' +
      ui.rules("Roleta europeia: números 0 a 36, todos com a mesma chance (1/37 = " + ui.pct(1 / 37) + "). O zero faz perder as apostas externas." +
        "<table><tr><th>Aposta</th><th>Paga</th><th>Chance</th></tr>" +
        ["straight", "red", "even", "low", "dozen", "column"].map(function (t) {
          var b = E.rouletteBet(t); return "<tr><td>" + NAMES[t] + "</td><td>" + b.pays + ":1</td><td>" + ui.pct(b.probability) + "</td></tr>";
        }).join("") + "</table>Retorno teórico: " + ui.pct(36 / 37) + " do total apostado a longo prazo. Resultados passados não influenciam os próximos.") +
      ui.hist("roulette");
  };
  TS.pages.roulette.after = renderBets;

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-rb],#rclear,#rspin");
    if (!t || TS.current !== "roulette") return;
    if (busy) return;
    if (t.hasAttribute("data-rb")) {
      var s = ui.readStake("rstake");
      if (!(s > 0)) { TS.toast("Informe o valor da ficha.", "err"); return; }
      var k = t.getAttribute("data-rb");
      BETS[k] = Math.round(((BETS[k] || 0) + s) * 100) / 100;
      ui.sfx("tick"); renderBets(); return;
    }
    if (t.id === "rclear") { BETS = {}; renderBets(); return; }
    if (t.id === "rspin") {
      var bets = list();
      if (!bets.length) { TS.toast("Coloque ao menos uma ficha.", "err"); return; }
      var r = W.placeBet(total(), { desc: "Cassino · Roleta" });
      if (!r.ok) { TS.toast(r.error, "err"); return; }
      var stake = total(), n = L.roulette.spin(), payout = L.roulette.payout(bets, n), done = false;
      busy = true; ui.say("rsay", "Girando…", "info");
      var idx = L.roulette.ORDER.indexOf(n), step = 360 / 37;
      rot = (Math.ceil(rot / 360) + 5) * 360 - (idx + 0.5) * step;
      ui.el("wheel").style.transform = "rotate(" + rot + "deg)";
      settle = function () {
        if (done) return; done = true; settle = null; busy = false;
        var p = ui.finish("roulette", { id: r.id, stake: stake }, payout, "Saiu " + n + " · " + brl(stake));
        last.unshift(n); last = last.slice(0, 10);
        if (TS.current === "roulette") {
          var c = E.rouletteColor(n);
          ui.say("rsay", "Saiu " + n + " (" + (c === "red" ? "vermelho" : c === "black" ? "preto" : "verde") + ") · " + (p > 0 ? "Retorno " + brl(p) : "Sem retorno"), p > stake ? "win" : "lose");
          ui.el("rlast").innerHTML = last.map(function (x) { return '<span class="dot ' + E.rouletteColor(x) + '">' + x + "</span>"; }).join("");
          ui.refreshHist("roulette");
        }
      };
      setTimeout(function () { if (settle) settle(); }, 3300);
    }
  });
})(window);
