/*
 * TSGames — Bilhetes (apostas simples e combinadas).
 * Uma criação de Thalisson Torricelli.
 *
 * Regras:
 *  - Uma seleção por evento no bilhete (resultados do mesmo evento são dependentes).
 *  - Combinada: cotação = produto das cotações (válido para eventos independentes).
 *  - Simples: o valor informado vale para CADA seleção (um bilhete por seleção).
 *  - O valor é reservado na carteira ao confirmar e liquidado quando o evento termina.
 */
(function (root, factory) {
  var E = typeof module === "object" && module.exports ? require("./engine.js") : root.TS.engine;
  var S = typeof module === "object" && module.exports ? require("./sports.js") : root.TS.Sports;
  var api = factory(E, S);
  if (typeof module === "object" && module.exports) module.exports = api;
  else {
    root.TS = root.TS || {}; root.TS.Tickets = api;
    if (root.TS.store && root.TS.wallet && root.TS.sports && root.TS.stats)
      root.TS.tickets = api.create({ storage: root.TS.store, wallet: root.TS.wallet, sports: root.TS.sports, stats: root.TS.stats });
  }
})(typeof window !== "undefined" ? window : this, function (E, S) {
  "use strict";
  var MAX_LEGS = 10;
  function create(o) {
    var storage = o.storage, W = o.wallet, SP = o.sports, stats = o.stats, clock = o.now || Date.now;
    var data = storage.get("tickets", { seq: 0, list: [] });
    var slip = [];
    function save() { storage.set("tickets", data); }

    function toggle(eid, mid, sid) {
      var ev = SP.get(eid);
      if (!ev || ev.status !== "open") return { ok: false, error: "Evento indisponível." };
      var mk = ev.markets.filter(function (m) { return m.id === mid; })[0];
      var sl = mk && mk.sels.filter(function (s) { return s.id === sid; })[0];
      if (!sl) return { ok: false, error: "Seleção inválida." };
      var i = slip.findIndex(function (l) { return l.eventId === eid; });
      if (i >= 0) {
        var same = slip[i].marketId === mid && slip[i].selId === sid;
        slip.splice(i, 1);
        if (same) return { ok: true, removed: true };
      }
      if (slip.length >= MAX_LEGS) return { ok: false, error: "Máximo de " + MAX_LEGS + " seleções." };
      slip.push({ eventId: eid, marketId: mid, selId: sid, odds: sl.odds, label: sl.label,
                  market: mk.name, match: ev.home + " x " + ev.away, result: null });
      return { ok: true };
    }
    function isSel(eid, mid, sid) {
      return slip.some(function (l) { return l.eventId === eid && l.marketId === mid && l.selId === sid; });
    }
    function quote(stake, mode) {
      var n = slip.length, odds = n ? E.combinedOdds(slip.map(function (l) { return l.odds; })) : 0;
      if (mode === "single" || n < 2) {
        var pot = slip.reduce(function (a, l) { return a + stake * l.odds; }, 0);
        return { count: n, odds: n === 1 ? slip[0].odds : null, total: E.round2(stake * n), potential: E.round2(pot) };
      }
      return { count: 1, odds: odds, total: E.round2(stake), potential: E.potentialReturn(stake, odds) };
    }
    function place(stake, mode, key) {
      if (!slip.length) return { ok: false, error: "Seu bilhete está vazio." };
      if (!(stake > 0)) return { ok: false, error: "Informe um valor válido." };
      for (var i = 0; i < slip.length; i++) {
        var ev = SP.get(slip[i].eventId);
        if (!ev || ev.status !== "open") return { ok: false, error: "Um dos eventos não está mais disponível." };
      }
      var q = quote(stake, mode), single = mode === "single" || slip.length < 2;
      if (q.total > W.summary().available + 1e-9) return { ok: false, error: "Saldo disponível insuficiente." };
      var groups = single ? slip.map(function (l) { return [l]; }) : [slip.slice()], made = [];
      for (var g = 0; g < groups.length; g++) {
        var legs = groups[g].map(function (l) { return JSON.parse(JSON.stringify(l)); });
        var odds = legs.length === 1 ? legs[0].odds : E.combinedOdds(legs.map(function (l) { return l.odds; }));
        var desc = "Bilhete · " + (legs.length === 1 ? legs[0].match : "combinada " + legs.length + " seleções");
        var r = W.placeBet(stake, { desc: desc, key: key ? key + ":" + g : null });
        if (!r.ok) return r;
        if (r.duplicate) continue;
        data.seq++;
        var t = { id: "BL-" + ("0000" + data.seq).slice(-4), ts: clock(), mode: legs.length === 1 ? "simples" : "combinada",
                  stake: stake, odds: odds, legs: legs, betId: r.id, status: "open", payout: 0 };
        data.list.push(t); made.push(t);
      }
      slip = []; save();
      return { ok: true, tickets: made };
    }
    function settleEvent(eid) {
      var ev = SP.get(eid);
      if (!ev || ev.status !== "finished") return 0;
      var n = 0;
      data.list.forEach(function (t) {
        if (t.status !== "open") return;
        t.legs.forEach(function (l) {
          if (l.eventId !== eid || l.result) return;
          var mk = ev.markets.filter(function (m) { return m.id === l.marketId; })[0];
          l.result = S.settleSelection(mk, l.selId, ev.score) ? "won" : "lost";
        });
        var lost = t.legs.some(function (l) { return l.result === "lost"; });
        var done = t.legs.every(function (l) { return l.result; });
        if (!lost && !done) return;
        t.status = lost ? "lost" : "won";
        t.payout = lost ? 0 : E.potentialReturn(t.stake, t.odds);
        W.settleBet(t.betId, t.payout);
        stats.record("sports", t.stake, t.payout, t.id + " · " + (t.legs.length === 1 ? t.legs[0].match : "combinada"));
        n++;
      });
      save();
      return n;
    }
    function finishEvent(eid, score) {
      var r = SP.finish(eid, score);
      if (!r.ok) return r;
      return { ok: true, settled: settleEvent(eid) };
    }
    return {
      slip: function () { return slip; }, toggle: toggle, isSel: isSel, quote: quote, place: place,
      remove: function (i) { slip.splice(i, 1); }, clear: function () { slip = []; },
      list: function (status) { return data.list.filter(function (t) { return !status || t.status === status; }).slice().reverse(); },
      settleEvent: settleEvent, finishEvent: finishEvent,
      reset: function () { data = { seq: 0, list: [] }; slip = []; save(); }
    };
  }
  return { create: create, MAX_LEGS: MAX_LEGS };
});
