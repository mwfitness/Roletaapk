"use strict";
// Carrega os scripts do index.html (na ordem) num ambiente simulado e exercita telas e fluxos.
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const WWW = path.join(__dirname, "..", "app", "src", "main", "assets", "www");

function boot() {
  const ls = {}, handlers = {}, els = {}, q = {};
  function el(o) {
    return Object.assign({
      id: "", innerHTML: "", value: "", textContent: "", scrollTop: 0, dataset: {}, isConnected: true, className: "",
      classList: { toggle() {}, add() {}, remove() {} }, attrs: {}, disabled: false,
      getAttribute(n) { return this.attrs[n]; }, hasAttribute(n) { return n in this.attrs; },
      closest(sel) {
        return sel.split(",").some((s) => {
          s = s.trim();
          if (s[0] === "#") return this.id === s.slice(1);
          const m = /^\[([\w-]+)\]$/.exec(s);
          return m ? this.hasAttribute(m[1]) : false;
        }) ? this : null;
      }, focus() {}, select() {}
    }, o || {});
  }
  const on = (t, f) => { (handlers[t] = handlers[t] || []).push(f); };
  const doc = {
    addEventListener: on, getElementById: (id) => els[id] || null, querySelectorAll: (s) => q[s] || [],
    createElement: () => el(), body: { appendChild() {}, addEventListener() {} },
    documentElement: { style: { setProperty() {} } }, activeElement: null
  };
  ["view", "nav", "hdrBalance", "splash", "welcome", "welcomeOk", "homeRes"].forEach((id) => { els[id] = el({ id }); });
  const win = {
    localStorage: { getItem: (k) => (k in ls ? ls[k] : null), setItem: (k, v) => { ls[k] = String(v); }, removeItem: (k) => { delete ls[k]; } },
    document: doc, navigator: {}, performance: { now: () => Date.now() }, requestAnimationFrame: () => 0, cancelAnimationFrame() {},
    setInterval: () => 0, clearInterval() {}, setTimeout: () => 0, clearTimeout() {}, addEventListener: on, location: { reload() {} },
    console, Math, Date, JSON, Object, Array, Number, String, Uint32Array, Promise, Set, Map, Error, RangeError, isFinite, parseFloat, parseInt, Intl,
    crypto: require("crypto").webcrypto
  };
  win.window = win;
  vm.createContext(win);
  const html = fs.readFileSync(path.join(WWW, "index.html"), "utf8");
  const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => m[1]);
  scripts.forEach((f) => vm.runInContext(fs.readFileSync(path.join(WWW, f), "utf8"), win, { filename: f }));
  const click = (target) => (handlers.click || []).forEach((h) => h({ target }));
  const input = (target) => (handlers.input || []).forEach((h) => h({ target }));
  const target = (id, attrs) => el({ id: id || "", attrs: attrs || {} });
  return { win, TS: win.TS, els, q, el, click, input, target, handlers, scripts };
}

test("todos os scripts do index.html carregam sem erro", () => {
  const b = boot();
  assert.ok(b.scripts.length >= 20);
  ["wallet", "sports", "tickets", "stats", "vault", "ui", "logic", "engine"].forEach((k) => assert.ok(b.TS[k], "TS." + k));
});

test("todas as telas renderizam texto válido", () => {
  const b = boot(), TS = b.TS;
  const pages = [["home"], ["sports"], ["sports", "tennis"], ["event", "E01"], ["event", "E21"], ["slip"], ["tickets"], ["casino"],
    ["roulette"], ["blackjack"], ["slots"], ["crash"], ["plinko"], ["dice"], ["wallet"], ["deposit"], ["withdraw"], ["statement"],
    ["profile"], ["credits"], ["adminlogin"]];
  pages.forEach(([n, a]) => {
    const html = TS.pages[n](a);
    assert.equal(typeof html, "string", n);
    assert.ok(html.length > 60, n);
    assert.ok(!/undefined|NaN|\[object/.test(html), n + " contém valor inválido");
  });
});

test("todos os destinos data-go existem como telas", () => {
  const b = boot(), TS = b.TS, names = new Set();
  const files = [path.join(WWW, "index.html")];
  (function walk(d) { fs.readdirSync(d, { withFileTypes: true }).forEach((e) => { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else if (p.endsWith(".js")) files.push(p); }); })(path.join(WWW, "js"));
  files.forEach((f) => {
    const s = fs.readFileSync(f, "utf8");
    for (const m of s.matchAll(/data-go=\\?"([a-z]+)\\?"/g)) names.add(m[1]);
    for (const m of s.matchAll(/TS\.go\("([a-z]+)"/g)) names.add(m[1]);
    for (const m of s.matchAll(/ui\.head\([^)]*?,\s*"([a-z]+)"/g)) names.add(m[1]);
  });
  ["home", "sports", "casino", "wallet", "profile", "deposit", "withdraw", "statement", "admin", "adminevent", "slip", "tickets", "event"].forEach((n) => names.add(n));
  const missing = [...names].filter((n) => !TS.pages[n]);
  assert.deepEqual(missing, []);
});

test("navegação: voltar do Android percorre o histórico e fecha só no Início", () => {
  const b = boot(), TS = b.TS;
  TS.go("home"); TS.go("sports"); TS.go("event", "E01");
  assert.equal(TS.current, "event");
  assert.equal(TS.onBack(), true); assert.equal(TS.current, "sports");
  assert.equal(TS.onBack(), true); assert.equal(TS.current, "home");
  assert.equal(TS.onBack(), false);
  let left = 0;
  TS.go("dice"); TS.onLeave = () => { left++; };
  TS.go("casino");
  assert.equal(left, 1);
  assert.equal(TS.onLeave, null);
  TS.refresh(); assert.equal(TS.current, "casino");
});

test("carteira: depositar e sacar pelos botões atualizam o saldo", () => {
  const b = boot(), TS = b.TS;
  TS.go("deposit");
  b.els.depAmt = b.el({ id: "depAmt", value: "100,00" });
  b.click(b.target("depGo"));
  assert.equal(TS.wallet.summary().available, 1350);
  TS.go("withdraw");
  b.els.wdAmt = b.el({ id: "wdAmt", value: "50,00" });
  b.click(b.target("wdGo"));
  const s = TS.wallet.summary();
  assert.equal(s.available, 1300);
  assert.equal(s.reserved, 50);
  b.click(b.target("", { "data-cancel": TS.wallet.pendingWithdrawals()[0].id }));
  assert.equal(TS.wallet.summary().available, 1350);
  assert.equal(TS.wallet.check().ok, true);
});

test("painel: PIN, cotações, resultado e liquidação do bilhete combinado", () => {
  const b = boot(), TS = b.TS, W = TS.wallet, TK = TS.tickets, SP = TS.sports;
  // acesso: sem PIN fixo, o primeiro acesso cria o PIN
  TS.go("adminlogin");
  b.els.pin1 = b.el({ id: "pin1", value: "2468" });
  b.els.pin2 = b.el({ id: "pin2", value: "2468" });
  b.click(b.target("pinGo"));
  assert.equal(TS.current, "admin");
  assert.ok(TS.vault.hasPin());
  ["events", "games", "ops", "data", "log", "over"].forEach((t) => {
    b.click(b.target("", { "data-atab": t }));
    assert.ok(b.els.view.innerHTML.length > 100, t);
  });
  // bilhete combinado em dois eventos
  assert.ok(TK.toggle("E01", "x12", "h").ok);
  assert.ok(TK.toggle("E04", "ml", "h").ok);
  const placed = TK.place(10, "combined", "t1");
  assert.ok(placed.ok);
  assert.equal(W.summary().reserved, 10);
  // altera a cotação do evento pelo painel
  TS.go("adminevent", "E01");
  b.q["[data-odd]"] = [{ getAttribute: () => "E01|x12|h", value: "2,50" }];
  b.click(b.target("oddSave", { "data-ev": "E01" }));
  assert.equal(SP.get("E01").markets[0].sels[0].odds, 2.5);
  b.q["[data-odd]"] = [{ getAttribute: () => "E01|x12|h", value: "0,50" }];
  b.click(b.target("oddSave", { "data-ev": "E01" }));
  assert.equal(SP.get("E01").markets[0].sels[0].odds, 2.5, "cotação inválida é recusada");
  // encerra os dois eventos: casa vence nos dois
  b.els.sc0 = b.el({ id: "sc0", value: "2" }); b.els.sc1 = b.el({ id: "sc1", value: "0" });
  b.click(b.target("evFinish", { "data-ev": "E01" }));
  assert.equal(W.summary().reserved, 10, "ainda aguardando o segundo evento");
  TS.go("adminevent", "E04");
  b.els.sc0 = b.el({ id: "sc0", value: "100" }); b.els.sc1 = b.el({ id: "sc1", value: "90" });
  b.click(b.target("evFinish", { "data-ev": "E04" }));
  const t = TK.list()[0];
  assert.equal(t.status, "won");
  assert.equal(W.summary().reserved, 0);
  assert.equal(W.summary().available, Math.round((1240 + t.payout) * 100) / 100);
  assert.equal(W.check().ok, true);
  assert.ok(TS.store.get("adminlog", []).length >= 4, "ações registradas");
  // ajuste de saldo e limites
  TS.go("admin"); b.click(b.target("", { "data-atab": "data" }));
  const before = W.summary().available;
  b.els.adjV = b.el({ id: "adjV", value: "-40,00" }); b.els.adjD = b.el({ id: "adjD", value: "teste" });
  b.click(b.target("adjGo"));
  assert.equal(W.summary().available, before - 40);
  b.els.cfgEdge = b.el({ id: "cfgEdge", value: "5,00" }); b.els.cfgRate = b.el({ id: "cfgRate", value: "0,20" });
  b.click(b.target("cfgSave"));
  assert.equal(TS.store.get("gcfg").crashEdge, 0.05);
  b.els.cfgEdge.value = "50,00"; b.click(b.target("cfgSave"));
  assert.equal(TS.store.get("gcfg").crashEdge, 0.05, "margem fora do intervalo é recusada");
});

test("painel: PIN incorreto não dá acesso", () => {
  const b = boot(), TS = b.TS;
  TS.vault.setPin("1111", "1111");
  TS.go("adminlogin");
  b.els.pin1 = b.el({ id: "pin1", value: "9999" });
  b.click(b.target("pinGo"));
  assert.equal(TS.current, "adminlogin");
  assert.ok(/PIN/.test(TS.pages.admin()), "tela do painel pede o PIN");
});

test("painel: restaurar dados de teste exige confirmação e restaura tudo", () => {
  const b = boot(), TS = b.TS, W = TS.wallet;
  TS.vault.setPin("1111", "1111"); TS.go("adminlogin");
  b.els.pin1 = b.el({ id: "pin1", value: "1111" }); b.click(b.target("pinGo"));
  W.deposit(500);
  const rst = b.target("rstAll");
  b.click(rst);
  assert.equal(W.summary().available, 1750, "primeiro toque só arma a confirmação");
  b.click(rst);
  assert.equal(W.summary().available, 1250);
  assert.equal(TS.tickets.list().length, 0);
});

test("perfil: nome, avatar, bloqueio de tema, som e reinício", () => {
  const b = boot(), TS = b.TS;
  TS.go("profile");
  b.click(b.target("", { "data-av": "3" }));
  assert.equal(TS.ui.prefs().avatar, 3);
  b.els.pname = b.el({ id: "pname", value: "  Ana  " });
  b.click(b.target("pnameSave"));
  assert.equal(TS.ui.prefs().name, "Ana");
  b.els.pname.value = "   "; b.click(b.target("pnameSave"));
  assert.equal(TS.ui.prefs().name, "Ana");
  b.click(b.target("", { "data-theme": "cobalto" }));
  assert.equal(TS.ui.prefs().theme, "esmeralda", "tema bloqueado até jogar mais");
  TS.stats.record("dice", 1, 0, "a");
  for (let i = 0; i < 5; i++) TS.stats.record("dice", 1, 0, "a");
  b.click(b.target("", { "data-theme": "ouro" }));
  assert.equal(TS.ui.prefs().theme, "ouro");
  const snd = TS.ui.prefs().sound;
  b.click(b.target("", { "data-sound": "1" }));
  assert.equal(TS.ui.prefs().sound, !snd);
  TS.wallet.deposit(100);
  const r = b.target("rstExp");
  b.click(r); assert.equal(TS.wallet.summary().available, 1350);
  b.click(r); assert.equal(TS.wallet.summary().available, 1250);
  assert.equal(TS.stats.summary().rounds, 0);
  assert.ok(/Thalisson Torricelli/.test(TS.pages.credits()));
  assert.ok(/não têm valor monetário/.test(TS.pages.profile()));
});

test("início: busca por equipe e por jogo", () => {
  const b = boot(), TS = b.TS;
  b.input({ id: "homeSearch", value: "aurora" });
  assert.ok(/Aurora FC/.test(b.els.homeRes.innerHTML));
  b.input({ id: "homeSearch", value: "roleta" });
  assert.ok(/Roleta/.test(b.els.homeRes.innerHTML));
  b.input({ id: "homeSearch", value: "zzzz" });
  assert.ok(/Nada encontrado/.test(b.els.homeRes.innerHTML));
  b.input({ id: "homeSearch", value: "a" });
  assert.equal(b.els.homeRes.innerHTML, "");
  void TS;
});

test("jogos: aposta e liquidação pela UI compartilhada atualizam carteira e histórico", () => {
  const b = boot(), TS = b.TS, W = TS.wallet;
  b.els.tst = b.el({ id: "tst", value: "10,00" });
  const bet = TS.ui.bet("tst", "Cassino · Teste");
  assert.ok(bet);
  assert.equal(W.summary().reserved, 10);
  TS.ui.finish("dice", bet, 25, "teste");
  assert.equal(W.summary().available, 1265);
  assert.equal(TS.stats.summary().rounds, 1);
  b.els.tst.value = "999999,00";
  assert.equal(TS.ui.bet("tst", "Cassino · Teste"), null, "saldo insuficiente");
  assert.equal(W.check().ok, true);
});

test("inicialização: rodada de cassino interrompida é liquidada como perdida", () => {
  const b = boot(), TS = b.TS, W = TS.wallet;
  W.placeBet(30, { desc: "Cassino · Crash" });
  const tk = W.placeBet(20, { desc: "Bilhete · A x B" });
  assert.equal(W.summary().reserved, 50);
  (b.handlers.DOMContentLoaded || []).forEach((h) => h());
  assert.equal(TS.current, "home");
  assert.equal(W.summary().reserved, 20, "bilhete segue aberto; só a rodada é encerrada");
  assert.equal(W.summary().available, 1200);
  assert.equal(W.openBets()[0].id, tk.id);
  assert.equal(W.check().ok, true);
});
