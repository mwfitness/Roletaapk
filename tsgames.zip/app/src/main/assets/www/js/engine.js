/*
 * TSGames — Motor matemático
 * Uma criação de Thalisson Torricelli.
 *
 * Funções puras de probabilidade e retorno. Não acessam carteira nem tela.
 * Funciona no navegador (TS.engine) e no Node (module.exports), para testes.
 *
 * Observação: a probabilidade implícita de uma cotação NÃO é necessariamente
 * a probabilidade real do evento. E frequência observada NÃO é probabilidade teórica.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  } else {
    root.TS = root.TS || {};
    root.TS.engine = api;
  }
})(typeof window !== "undefined" ? window : this, function () {
  "use strict";

  function round2(n) { return Math.round(n * 100) / 100; }

  function checkOdds(o) {
    if (typeof o !== "number" || !isFinite(o) || o <= 1) {
      throw new RangeError("A cotação deve ser um número maior que 1.");
    }
  }

  // Probabilidade implícita bruta = 1 / cotação decimal.
  function impliedProbability(odds) { checkOdds(odds); return 1 / odds; }
  function impliedPercent(odds) { return impliedProbability(odds) * 100; }

  // Retorno potencial = valor × cotação. Resultado líquido = retorno − valor.
  function potentialReturn(stake, odds) {
    checkOdds(odds);
    if (typeof stake !== "number" || !isFinite(stake) || stake < 0) {
      throw new RangeError("O valor deve ser um número não negativo.");
    }
    return round2(stake * odds);
  }
  function netProfit(stake, odds) {
    return round2(potentialReturn(stake, odds) - stake);
  }

  // Margem teórica do mercado = soma das probabilidades implícitas − 1.
  function margin(oddsList) {
    var sum = 0;
    oddsList.forEach(function (o) { sum += impliedProbability(o); });
    return sum - 1;
  }

  // Probabilidade normalizada = implícita individual / soma das implícitas.
  function normalizedProbabilities(oddsList) {
    var imp = oddsList.map(impliedProbability);
    var sum = imp.reduce(function (a, b) { return a + b; }, 0);
    return imp.map(function (p) { return p / sum; });
  }

  // Cotação "justa" de uma probabilidade (sem margem).
  function fairOdds(p) {
    if (!(p > 0 && p <= 1)) throw new RangeError("Probabilidade deve estar em (0, 1].");
    return 1 / p;
  }

  // Cotação combinada = produto das cotações. Só é válido para seleções
  // independentes entre si (ex.: eventos distintos). Para resultados do mesmo
  // evento (dependentes) não deve ser usada.
  function combinedOdds(oddsList) {
    if (!oddsList.length) throw new RangeError("Informe ao menos uma cotação.");
    var prod = 1;
    oddsList.forEach(function (o) { checkOdds(o); prod *= o; });
    return round2(prod);
  }

  function checkOutcomes(outcomes) {
    var sum = 0;
    outcomes.forEach(function (o) {
      if (!(o.p >= 0 && o.p <= 1)) throw new RangeError("Probabilidade inválida.");
      sum += o.p;
    });
    if (Math.abs(sum - 1) > 1e-9) throw new RangeError("As probabilidades devem somar 1.");
  }

  // Valor esperado = Σ (resultado líquido × probabilidade).
  function expectedValue(outcomes) {
    checkOutcomes(outcomes);
    return outcomes.reduce(function (a, o) { return a + o.p * o.net; }, 0);
  }
  // Variância = Σ p × (net − EV)².
  function variance(outcomes) {
    var ev = expectedValue(outcomes);
    return outcomes.reduce(function (a, o) { return a + o.p * Math.pow(o.net - ev, 2); }, 0);
  }
  function stdDev(outcomes) { return Math.sqrt(variance(outcomes)); }

  // Frequência observada: { chave: { count, freq } }.
  function observedFrequencies(results) {
    var out = {}, n = results.length;
    results.forEach(function (r) {
      out[r] = out[r] || { count: 0, freq: 0 };
      out[r].count += 1;
    });
    Object.keys(out).forEach(function (k) { out[k].freq = out[k].count / n; });
    return out;
  }

  // Compara a expectativa teórica com o observado (inclui qui-quadrado).
  function compareDistribution(theory, results) {
    var n = results.length, obs = observedFrequencies(results), chi = 0;
    var rows = Object.keys(theory).map(function (k) {
      var expected = theory[k] * n;
      var count = obs[k] ? obs[k].count : 0;
      if (expected > 0) chi += Math.pow(count - expected, 2) / expected;
      return {
        key: k, theoretical: theory[k], expectedCount: expected,
        observedCount: count, observedFreq: n ? count / n : 0
      };
    });
    return { n: n, rows: rows, chiSquare: chi };
  }

  // ---- Roleta europeia (37 resultados equiprováveis: 0 a 36) ----
  var ROULETTE = {
    straight: { covers: 1, pays: 35 },
    red: { covers: 18, pays: 1 }, black: { covers: 18, pays: 1 },
    even: { covers: 18, pays: 1 }, odd: { covers: 18, pays: 1 },
    low: { covers: 18, pays: 1 }, high: { covers: 18, pays: 1 },
    dozen: { covers: 12, pays: 2 }, column: { covers: 12, pays: 2 }
  };
  var RED = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
  function rouletteColor(n) {
    if (n === 0) return "green";
    return RED.indexOf(n) >= 0 ? "red" : "black";
  }
  function rouletteBet(type) {
    var b = ROULETTE[type];
    if (!b) throw new RangeError("Tipo de aposta desconhecido.");
    var p = b.covers / 37;
    var ev = expectedValue([{ p: p, net: b.pays }, { p: 1 - p, net: -1 }]);
    return {
      type: type, covers: b.covers, probability: p, pays: b.pays,
      expectedValue: ev, returnToPlayer: 1 + ev
    };
  }

  // Inteiro aleatório uniforme em [0, n) com amostragem por rejeição (sem viés).
  function randomInt(n) {
    if (!Number.isInteger(n) || n <= 0 || n > 4294967296) {
      throw new RangeError("n deve ser inteiro entre 1 e 2^32.");
    }
    var c = (typeof crypto !== "undefined" && crypto.getRandomValues) ? crypto : null;
    if (!c && typeof require === "function") c = require("crypto").webcrypto;
    if (!c) throw new Error("Gerador aleatório indisponível.");
    var limit = Math.floor(4294967296 / n) * n;
    var buf = new Uint32Array(1), x;
    do { c.getRandomValues(buf); x = buf[0]; } while (x >= limit);
    return x % n;
  }

  return {
    round2: round2, impliedProbability: impliedProbability, impliedPercent: impliedPercent,
    potentialReturn: potentialReturn, netProfit: netProfit, margin: margin,
    normalizedProbabilities: normalizedProbabilities, fairOdds: fairOdds,
    combinedOdds: combinedOdds, expectedValue: expectedValue, variance: variance,
    stdDev: stdDev, observedFrequencies: observedFrequencies,
    compareDistribution: compareDistribution, ROULETTE: ROULETTE,
    rouletteColor: rouletteColor, rouletteBet: rouletteBet, randomInt: randomInt
  };
});
