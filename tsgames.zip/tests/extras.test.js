"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const J = "../app/src/main/assets/www/js/";
const { create } = require(J + "wallet.js");
const Stats = require(J + "statistics.js");
const Security = require(J + "security.js");

function mem() {
  const m = {};
  return { get: (k, d) => (k in m && m[k] !== null ? JSON.parse(JSON.stringify(m[k])) : d), set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); return true; } };
}

test("carteira: openBets lista apostas reservadas e some depois da liquidação", () => {
  const w = create();
  const a = w.placeBet(10, { desc: "Cassino · Teste" });
  const b = w.placeBet(20, { desc: "Bilhete · X" });
  const open = w.openBets();
  assert.equal(open.length, 2);
  assert.deepEqual(open.map((x) => x.amount).sort((p, q) => p - q), [10, 20]);
  assert.ok(open.some((x) => /^Cassino/.test(x.desc)));
  w.settleBet(a.id, 0);
  assert.equal(w.openBets().length, 1);
  assert.equal(w.summary().reserved, 20);
  w.settleBet(b.id, 40);
  assert.equal(w.openBets().length, 0);
  assert.deepEqual(w.check(), { ok: true, errors: [] });
});

test("estatísticas: conquistas refletem o progresso", () => {
  const s = Stats.create({ storage: mem() });
  let ach = Stats.achievements({ summary: s.summary(), tickets: 0, combined: 0, deposits: 0 });
  assert.equal(ach.filter((x) => x.done).length, 0);
  s.record("dice", 10, 20, "a"); s.record("slots", 5, 0, "b"); s.record("crash", 5, 0, "c");
  ach = Stats.achievements({ summary: s.summary(), tickets: 1, combined: 1, deposits: 50 });
  const done = (id) => ach.find((x) => x.id === id).done;
  assert.ok(done("first") && done("win") && done("explorer") && done("dep") && done("ticket") && done("combo"));
  assert.equal(done("ten"), false);
  for (let i = 0; i < 10; i++) s.record("dice", 1, 0, "x");
  assert.ok(Stats.achievements({ summary: s.summary(), tickets: 0, combined: 0, deposits: 0 }).find((x) => x.id === "ten").done);
});

test("PIN do painel: validação, criação e conferência (sem senha fixa)", () => {
  const v = Security.create({ storage: mem() });
  assert.equal(v.hasPin(), false);
  assert.equal(v.check("1234"), false);
  assert.equal(v.setPin("12", "12").ok, false);
  assert.equal(v.setPin("abcd", "abcd").ok, false);
  assert.equal(v.setPin("1234", "4321").ok, false);
  assert.ok(v.setPin("2468", "2468").ok);
  assert.equal(v.hasPin(), true);
  assert.equal(v.check("2468"), true);
  assert.equal(v.check("1234"), false);
  v.clear();
  assert.equal(v.hasPin(), false);
});

test("PIN: guardado como resumo com sal, nunca em texto puro", () => {
  const st = mem();
  const v = Security.create({ storage: st });
  v.setPin("13579", "13579");
  const saved = JSON.stringify(st.get("pin"));
  assert.ok(!saved.includes("13579"));
  const st2 = mem();
  Security.create({ storage: st2 }).setPin("13579", "13579");
  assert.notEqual(st.get("pin").hash, st2.get("pin").hash); // sal diferente
});
