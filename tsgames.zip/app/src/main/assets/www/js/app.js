/*
 * TSGames — Início, inicialização e recuperação de rodadas interrompidas.
 * Uma criação de Thalisson Torricelli.
 *
 * Ordem dos scripts (ver index.html): storage, router, engine, games-logic, wallet,
 * pages-wallet, statistics, sports, tickets, security, ui, sports-ui, casino/*,
 * admin, profile, app.
 */
(function (g) {
  var TS = g.TS, W = TS.wallet, SP = TS.sports, ui = TS.ui, esc = TS.fmt.esc, brl = TS.brl;
  TS.VERSION = "1.0.0";

  // Atualiza todos os saldos da tela (cabeçalho, Início, Carteira...).
  TS.refreshBalances = function () {
    var s = W.summary();
    document.querySelectorAll("[data-bal]").forEach(function (el) {
      var v = s[el.getAttribute("data-bal")];
      if (typeof v === "number") el.textContent = brl(v);
    });
  };
  W.on(TS.refreshBalances);

  function sportName(id) {
    var s = SP.SPORTS.filter(function (x) { return x[0] === id; })[0];
    return s ? s[1] : id;
  }
  function dec(n) { return Number(n).toFixed(2).replace(".", ","); }

  TS.pages.home = function () {
    var pf = ui.prefs(), sm = TS.stats.summary(), recent = W.list({ limit: 3 });
    var open = SP.list("all").filter(function (e) { return e.status === "open"; });
    var feat = [0, 3, 6, 9].map(function (i) { return open[i]; }).filter(Boolean);
    var ach = TS.achievements();
    return "<h1>Olá, " + esc(pf.name) + "</h1>" +
      '<div class="card balance"><div class="label">Saldo disponível</div>' +
      '<div class="value" data-bal="available">' + brl(W.summary().available) + "</div>" +
      '<div class="row"><button class="btn primary" data-go="deposit">Depositar</button>' +
      '<button class="btn" data-go="withdraw">Sacar</button></div></div>' +
      '<input class="field" id="homeSearch" placeholder="Buscar jogos e eventos" autocomplete="off">' +
      '<div id="homeRes" class="stack"></div>' +
      "<h2>Esportes</h2><div class=\"scroller\">" + SP.SPORTS.map(function (s) {
        return '<div class="pill" data-go="sports" data-arg="' + s[0] + '">' + s[1] + "</div>";
      }).join("") + "</div>" +
      "<h2>Eventos em destaque</h2>" + feat.map(function (ev) {
        var m = ev.markets[0];
        return '<div class="ev"><div class="meta"><span>' + sportName(ev.sport) + " · " + esc(ev.when) + "</span><span>" + esc(m.name) + "</span></div>" +
          '<div class="teams" data-go="event" data-arg="' + ev.id + '">' + esc(ev.home) + " x " + esc(ev.away) + " ›</div>" +
          '<div class="odds c' + m.sels.length + '">' + m.sels.map(function (s) {
            return '<div class="od" data-go="event" data-arg="' + ev.id + '"><small>' + (s.id === "h" ? "Casa" : s.id === "d" ? "Empate" : "Fora") + "</small><b>" + dec(s.odds) + "</b></div>";
          }).join("") + "</div></div>";
      }).join("") +
      "<h2>Jogos populares</h2><div class=\"grid\">" + TS.GAMES.map(function (c) {
        return '<div class="tile" data-go="' + c[0] + '"><b>' + c[1] + "</b><span>" + c[2] + "</span></div>";
      }).join("") + "</div>" +
      "<h2>Seu desempenho</h2><div class=\"grid stats\">" +
      '<div class="stat"><div class="k">Rodadas</div><div class="v">' + sm.rounds + "</div></div>" +
      '<div class="stat"><div class="k">Vitórias</div><div class="v">' + (sm.rounds ? ui.pct(sm.wins / sm.rounds) : "—") + "</div></div>" +
      '<div class="stat"><div class="k">Resultado</div><div class="v">' + brl(sm.net) + "</div></div>" +
      '<div class="stat" data-go="profile"><div class="k">Conquistas</div><div class="v">' + ach.filter(function (a) { return a.done; }).length + "/" + ach.length + "</div></div></div>" +
      "<h2>Últimas atividades</h2><div class=\"card\">" +
      recent.map(function (r) {
        return '<div class="sumrow"><span>' + esc(r.type) + "</span><b>" + TS.fmt.signed(r.amount) + "</b></div>";
      }).join("") + '<button class="btn full" data-go="statement">Ver extrato</button></div>';
  };

  // Busca na tela inicial: eventos (equipes e modalidade) e jogos.
  document.addEventListener("input", function (e) {
    if (e.target.id !== "homeSearch") return;
    var q = e.target.value.trim().toLowerCase(), box = document.getElementById("homeRes");
    if (!box) return;
    if (q.length < 2) { box.innerHTML = ""; return; }
    var evs = SP.list("all").filter(function (ev) {
      return (ev.home + " " + ev.away + " " + sportName(ev.sport)).toLowerCase().indexOf(q) >= 0;
    }).slice(0, 6);
    var games = TS.GAMES.filter(function (c) { return (c[1] + " " + c[2]).toLowerCase().indexOf(q) >= 0; });
    var html = evs.map(function (ev) {
      return '<div class="tile" data-go="event" data-arg="' + ev.id + '"><b>' + esc(ev.home) + " x " + esc(ev.away) + "</b><span>" + sportName(ev.sport) + " · " + esc(ev.when) + "</span></div>";
    }).join("") + games.map(function (c) {
      return '<div class="tile" data-go="' + c[0] + '"><b>' + c[1] + "</b><span>Cassino · " + c[2] + "</span></div>";
    }).join("");
    box.innerHTML = html || '<div class="muted" style="padding:8px 0">Nada encontrado.</div>';
  });

  // Rodadas de cassino que ficaram abertas (app encerrado no meio) contam como perdidas.
  function recover() {
    var n = 0;
    W.openBets().forEach(function (b) {
      if (/^Cassino/.test(b.desc) && W.settleBet(b.id, 0).ok) n++;
    });
    return n;
  }

  // Aprovação automática de saques em análise (regra interna do app).
  function tick() {
    if (W.processPending() > 0 && ["wallet", "withdraw", "statement"].indexOf(TS.current) >= 0) {
      var a = document.activeElement;
      if (!a || a.tagName !== "INPUT") TS.refresh();
    }
  }

  window.addEventListener("DOMContentLoaded", function () {
    ui.applyTheme();
    document.getElementById("hdrBalance").innerHTML = '<small>Saldo</small><span data-bal="available"></span>';
    TS.initNav();
    var lost = recover();
    TS.refreshBalances();
    tick();
    TS.go("home");
    if (lost) TS.toast("Rodada interrompida registrada como perdida");
    setInterval(tick, 5000);

    var splash = document.getElementById("splash"), wel = document.getElementById("welcome");
    setTimeout(function () {
      splash.classList.add("hide");
      if (!TS.store.get("welcomed", false)) wel.classList.remove("hide");
    }, 1400);
    document.getElementById("welcomeOk").onclick = function () {
      TS.store.set("welcomed", true);
      wel.classList.add("hide");
    };
  });
})(window);
