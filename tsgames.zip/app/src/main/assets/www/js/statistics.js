/*
 * TSGames — Histórico e estatísticas de rodadas e bilhetes.
 * Uma criação de Thalisson Torricelli.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else { root.TS = root.TS || {}; root.TS.Stats = api; if (root.TS.store) root.TS.stats = api.create({ storage: root.TS.store }); }
})(typeof window !== "undefined" ? window : this, function () {
  "use strict";
  function create(opts) {
    var storage = opts.storage, clock = opts.now || Date.now, MAX = 400;
    function all() { return storage.get("hist", []); }
    return {
      record: function (game, stake, payout, detail) {
        var h = all();
        h.push({ ts: clock(), game: game, stake: stake, payout: payout, detail: detail || "" });
        if (h.length > MAX) h.splice(0, h.length - MAX);
        storage.set("hist", h);
      },
      list: function (game, limit) {
        var h = all().filter(function (x) { return !game || game === "all" || x.game === game; }).reverse();
        return limit ? h.slice(0, limit) : h;
      },
      summary: function () {
        var s = { rounds: 0, wins: 0, staked: 0, returned: 0, net: 0, best: 0, games: {} };
        all().forEach(function (x) {
          s.rounds++; s.staked += x.stake; s.returned += x.payout;
          if (x.payout > x.stake) s.wins++;
          s.best = Math.max(s.best, x.payout - x.stake);
          s.games[x.game] = (s.games[x.game] || 0) + 1;
        });
        s.net = Math.round((s.returned - s.staked) * 100) / 100;
        s.staked = Math.round(s.staked * 100) / 100;
        s.returned = Math.round(s.returned * 100) / 100;
        s.best = Math.round(s.best * 100) / 100;
        return s;
      },
      clear: function () { storage.set("hist", []); }
    };
  }
  // Conquistas virtuais (apenas progresso dentro do app).
  // ctx: { summary, tickets, combined, deposits }
  function achievements(ctx) {
    var sm = ctx.summary, n = Object.keys(sm.games).length;
    return [
      { id: "first", name: "Primeira rodada", done: sm.rounds >= 1 },
      { id: "ten", name: "10 rodadas", done: sm.rounds >= 10 },
      { id: "fifty", name: "50 rodadas", done: sm.rounds >= 50 },
      { id: "explorer", name: "Explorador: 3 modalidades diferentes", done: n >= 3 },
      { id: "dep", name: "Primeiro depósito", done: ctx.deposits > 0 },
      { id: "ticket", name: "Primeiro bilhete", done: ctx.tickets >= 1 },
      { id: "combo", name: "Primeira combinada", done: ctx.combined >= 1 },
      { id: "win", name: "Primeira vitória", done: sm.wins >= 1 }
    ];
  }
  return { create: create, achievements: achievements };
});
