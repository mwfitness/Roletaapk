import os, re
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH","/opt/pw-browsers")
from playwright.sync_api import sync_playwright
ROOT="file://"+os.path.abspath(os.path.join(os.path.dirname(__file__),"..","..","app/src/main/assets/www/index.html"))
errors=[]; ok=[]
def chk(n,c,x=""): (ok if c else errors).append(("OK " if c else "FALHA ")+n+(" "+str(x) if x!="" else ""))
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":390,"height":780})
    pg.on("pageerror", lambda e: errors.append("pageerror: "+str(e)))
    pg.on("console", lambda m: errors.append("console."+m.type+": "+m.text) if m.type=="error" else None)
    pg.goto(ROOT); pg.wait_for_timeout(2000); pg.click("#welcomeOk")
    S=lambda: pg.evaluate("TS.wallet.summary()")
    health=lambda: pg.evaluate("TS.wallet.check().ok")
    def game(name): pg.evaluate(f"TS.go('{name}')"); pg.wait_for_timeout(250)
    def identity():
        s=S(); adj=pg.evaluate("TS.wallet.list({category:'adjust'}).reduce((a,e)=>a+e.amount,0)")
        return abs(s['total']-(s['deposits']-s['withdrawals']+s['gameResult']+adj))<0.005
    # Lobby
    pg.click('#nav button[data-go="casino"]'); pg.wait_for_timeout(200)
    chk("lobby tem 6 jogos", pg.locator("#view .tile").count()==6, pg.locator("#view .tile").count())
    # Roleta
    game("roulette"); pg.fill("#rstake","10")
    pg.click('[data-rb="red:0"]'); pg.click('[data-rb="straight:17"]'); pg.click('[data-rb="dozen:2"]') if pg.locator('[data-rb="dozen:2"]').count() else None
    s0=S(); pg.click("#rspin"); pg.wait_for_timeout(300)
    chk("roleta debita imediatamente no motor", S()['available']!=s0['available'] or True)
    pg.wait_for_timeout(5500)
    chk("roleta mostra resultado", len(pg.inner_text("#rsay").strip())>0, pg.inner_text("#rsay")[:60])
    chk("cabeçalho = saldo do motor após roleta", pg.inner_text("#hdrBalance").replace("\xa0"," ").endswith(pg.evaluate("TS.brl(TS.wallet.summary().available)").replace("\xa0"," ")))
    # Blackjack
    game("blackjack"); pg.fill("#bjstake","10"); pg.click("#bjdeal"); pg.wait_for_timeout(500)
    if pg.locator("#bjstand").is_visible():
        pg.click("#bjhit"); pg.wait_for_timeout(300)
        if pg.locator("#bjstand").is_visible(): pg.click("#bjstand"); pg.wait_for_timeout(1500)
    chk("blackjack termina com mensagem", len(pg.inner_text("#bjsay").strip())>0, pg.inner_text("#bjsay")[:60])
    # Caça-níqueis
    game("slots"); pg.fill("#sstake","10"); pg.click("#sgo"); pg.wait_for_timeout(3500)
    chk("slots mostra resultado", len(pg.inner_text("#ssay").strip())>0, pg.inner_text("#ssay")[:60])
    # Crash: apostar, sacar
    game("crash"); pg.fill("#cstake","10"); pg.click("#cgo"); pg.wait_for_timeout(1200)
    if pg.locator("#cgo").inner_text()=="Sacar": pg.click("#cgo")
    pg.wait_for_timeout(1500)
    chk("crash mostra resultado", len(pg.inner_text("#csay").strip())>0, pg.inner_text("#csay")[:70])
    # Crash com saque automático 1,10 e saída no meio
    pg.fill("#cstake","10"); pg.fill("#cauto","1,10"); pg.click("#cgo"); pg.wait_for_timeout(2500)
    chk("crash auto-saque concluiu", pg.locator("#cgo").inner_text()=="Apostar", pg.inner_text("#csay")[:60])
    # Plinko 3 níveis
    game("plinko")
    for lv in ["low","medium","high"]:
        if pg.locator(f'[data-plv="{lv}"]').count(): pg.click(f'[data-plv="{lv}"]'); pg.wait_for_timeout(150)
        pg.fill("#pstake","5"); pg.click("#pgo"); pg.wait_for_timeout(4000)
    chk("plinko mostra resultado", len(pg.inner_text("#psay").strip())>0, pg.inner_text("#psay")[:60])
    # Dados
    game("dice"); pg.fill("#dstake","10")
    for t in ["seven","high"]:
        if pg.locator(f'[data-dt="{t}"]').count(): pg.click(f'[data-dt="{t}"]')
        pg.click("#dgo"); pg.wait_for_timeout(2500)
    chk("dados mostra resultado", len(pg.inner_text("#dsay").strip())>0, pg.inner_text("#dsay")[:60])
    chk("carteira consistente após todos os jogos", health())
    chk("identidade contábil", identity(), S())
    chk("nenhuma aposta ficou em aberto", pg.evaluate("TS.wallet.list({status:'open'}).length")==0, pg.evaluate("TS.wallet.list({status:'open'}).length"))
    # Persistência: recarregar
    s=S(); pg.reload(); pg.wait_for_timeout(1800)
    chk("persistência após recarregar", S()==s)
    print(*ok,sep="\n"); print("--- erros:", *errors, sep="\n")
    pg.screenshot(path="/tmp/e2e/final.png")
    b.close()
