/* TSGames — navegação. Uma criação de Thalisson Torricelli.
 * TS.go(nome, arg, opts)  opts.keep = redesenha a tela mantendo a rolagem (sem nova entrada no histórico)
 * TS.refresh()            redesenha a tela atual mantendo a rolagem
 * TS.onLeave              função opcional chamada ao sair da tela atual (usada pelos jogos)
 * TS.onBack()             botão voltar do Android; retorna true se consumiu o evento
 */
(function (g) {
  var TS = g.TS;
  TS.pages = TS.pages || {};
  TS.parentTab = TS.parentTab || {};
  var stack = [];
  var tabs = [
    ["home", "Início", '<path d="M3 11 12 3l9 8v10H3z"/>'],
    ["sports", "Esportes", '<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18"/>'],
    ["casino", "Cassino", '<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="15" r="1"/>'],
    ["wallet", "Carteira", '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M16 12h5"/>'],
    ["profile", "Perfil", '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>']
  ];

  TS.go = function (name, arg, opts) {
    opts = opts === true ? { back: true } : (opts || {});
    if (!TS.pages[name]) name = "home";
    if (!opts.keep && TS.onLeave) {
      var f = TS.onLeave; TS.onLeave = null;
      try { f(); } catch (e) { /* ignora */ }
    }
    var main = document.getElementById("view"), top = main.scrollTop, html;
    try { html = TS.pages[name](arg); }
    catch (e) { html = '<h1>Ops</h1><div class="card"><span class="muted">Não foi possível abrir esta tela.</span></div>'; }
    main.innerHTML = '<div class="page">' + html + "</div>";
    main.scrollTop = opts.keep ? top : 0;
    if (!opts.back && !opts.keep) {
      var last = stack[stack.length - 1];
      if (last && last[0] === name) last[1] = arg; else stack.push([name, arg]);
      if (stack.length > 30) stack.shift();
    }
    TS.current = name;
    TS.currentArg = arg;
    var cur = tabs.some(function (t) { return t[0] === name; }) ? name : (TS.parentTab[name] || "home");
    document.querySelectorAll("#nav button").forEach(function (b) {
      b.classList.toggle("on", b.dataset.go === cur);
    });
    if (TS.pages[name].after) {
      try { TS.pages[name].after(arg); } catch (e) { /* ignora */ }
    }
  };
  TS.refresh = function () { TS.go(TS.current, TS.currentArg, { keep: true }); };

  TS.onBack = function () {
    if (stack.length > 1) {
      stack.pop();
      var t = stack[stack.length - 1];
      TS.go(t[0], t[1], { back: true });
      return true;
    }
    if (TS.current && TS.current !== "home") { stack = []; TS.go("home"); return true; }
    return false;
  };

  TS.initNav = function () {
    var nav = document.getElementById("nav");
    nav.innerHTML = tabs.map(function (t) {
      return '<button data-go="' + t[0] + '"><svg viewBox="0 0 24 24">' + t[2] + "</svg>" + t[1] + "</button>";
    }).join("");
    document.body.addEventListener("click", function (e) {
      var el = e.target.closest("[data-go]");
      if (el) TS.go(el.dataset.go, el.dataset.arg);
    });
  };
})(window);
