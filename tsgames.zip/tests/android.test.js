"use strict";
// Verificação estática da configuração Android e do empacotamento (não substitui a compilação real).
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");
const ROOT = path.join(__dirname, "..");
const rd = (p) => fs.readFileSync(path.join(ROOT, p), "utf8");
const ex = (p) => fs.existsSync(path.join(ROOT, p));
const WWW = "app/src/main/assets/www/";
const PKG = "com.thalissontorricelli.tsgames";

function balanced(xml) {
  const s = xml.replace(/<!--[\s\S]*?-->/g, "").replace(/<\?[\s\S]*?\?>/g, "");
  const stack = [];
  for (const m of s.matchAll(/<(\/?)([\w:.-]+)[^>]*?(\/?)>/g)) {
    if (m[3]) continue;
    if (m[1]) { if (stack.pop() !== m[2]) return false; } else stack.push(m[2]);
  }
  return stack.length === 0;
}

test("pacote consistente: gradle, manifesto e caminho da MainActivity", () => {
  const g = rd("app/build.gradle");
  assert.ok(g.includes(`namespace '${PKG}'`));
  assert.ok(g.includes(`applicationId "${PKG}"`));
  assert.ok(ex("app/src/main/java/" + PKG.replace(/\./g, "/") + "/MainActivity.java"));
  assert.ok(/^package com\.thalissontorricelli\.tsgames;/m.test(rd("app/src/main/java/com/thalissontorricelli/tsgames/MainActivity.java")));
  assert.ok(rd("app/src/main/AndroidManifest.xml").includes('android:name=".MainActivity"'));
  assert.ok(rd("app/src/main/res/values/strings.xml").includes(">TSGames<"));
  assert.ok(rd("settings.gradle").includes("include ':app'"));
  assert.ok(/com\.android\.application' version '8\.\d+\.\d+'/.test(rd("build.gradle")));
});

test("manifesto: sem permissões, sem backup e com ícone", () => {
  const m = rd("app/src/main/AndroidManifest.xml");
  assert.ok(!/uses-permission/.test(m));
  assert.ok(m.includes('android:allowBackup="false"'));
  assert.ok(m.includes('android:exported="true"'));
  assert.ok(m.includes("android.intent.action.MAIN") && m.includes("android.intent.category.LAUNCHER"));
});

test("MainActivity: WebView restrita e sem ponte nativa", () => {
  const j = rd("app/src/main/java/com/thalissontorricelli/tsgames/MainActivity.java");
  assert.ok(!/addJavascriptInterface/.test(j));
  assert.ok(j.includes("setAllowFileAccess(false)"));
  assert.ok(j.includes("setJavaScriptEnabled(true)") && j.includes("setDomStorageEnabled(true)"));
  assert.ok(j.includes('"file:///android_asset/www/index.html"'));
  assert.ok(j.includes("TS.onBack"));
  assert.equal((j.match(/\{/g) || []).length, (j.match(/\}/g) || []).length);
  assert.equal((j.match(/\(/g) || []).length, (j.match(/\)/g) || []).length);
});

test("XML dos recursos bem formado e referências @tipo/nome resolvidas", () => {
  const files = ["app/src/main/AndroidManifest.xml", "app/src/main/res/values/strings.xml", "app/src/main/res/values/colors.xml",
    "app/src/main/res/values/styles.xml", "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml",
    "app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml", "app/src/main/res/drawable/ic_launcher_foreground.xml"];
  let all = "";
  files.forEach((f) => { const x = rd(f); assert.ok(balanced(x), f); all += x; });
  const values = ["strings", "colors", "styles"].map((n) => rd(`app/src/main/res/values/${n}.xml`)).join("\n");
  for (const m of all.matchAll(/@(\w+)\/([\w]+)/g)) {
    const [, type, name] = m;
    if (type === "android") continue;
    if (type === "drawable" || type === "mipmap") {
      const dir = path.join(ROOT, "app/src/main/res");
      const found = fs.readdirSync(dir).filter((d) => d.startsWith(type)).some((d) => fs.existsSync(path.join(dir, d, name + ".xml")));
      assert.ok(found, `${type}/${name}`);
    } else {
      assert.ok(new RegExp(`name="${name}"`).test(values), `${type}/${name}`);
    }
  }
});

test("index.html: todos os scripts, estilos e imagens existem", () => {
  const html = rd(WWW + "index.html");
  const refs = [...html.matchAll(/(?:src|href)="([^"#]+)"/g)].map((m) => m[1]);
  assert.ok(refs.length > 25);
  refs.forEach((r) => assert.ok(ex(WWW + r), r));
  // imagens citadas em JS
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  walk(path.join(ROOT, WWW, "js")).forEach((f) => {
    for (const m of fs.readFileSync(f, "utf8").matchAll(/assets\/[\w.-]+\.svg/g)) assert.ok(ex(WWW + m[0]), m[0] + " em " + path.basename(f));
  });
});

test("identidade: logos e assinatura do criador presentes", () => {
  ["logo-icon", "logo-horizontal", "logo-compact", "logo-mono", "signature-tt"].forEach((n) => assert.ok(ex(`${WWW}assets/${n}.svg`), n));
  const all = rd(WWW + "index.html") + rd(WWW + "js/profile.js");
  assert.ok(all.includes("Uma criação de Thalisson Torricelli"));
  assert.ok(rd("README.md").includes("Thalisson Torricelli"));
  assert.ok(rd("LICENSE").includes("Thalisson Torricelli"));
});

test("interface limpa: sem avisos repetitivos nem a palavra 'fake'", () => {
  const html = rd(WWW + "index.html");
  const js = ["app", "profile", "admin", "ui", "sports-ui", "pages-wallet"].map((n) => rd(`${WWW}js/${n}.js`)).join("\n") + html;
  assert.ok(!/fake/i.test(js));
  assert.ok(!/SIMULADOR TSGAMES/i.test(js));
  assert.ok(!/SEM DINHEIRO REAL/i.test(js));
});

test("sem integrações financeiras reais", () => {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  walk(path.join(ROOT, WWW)).filter((f) => /\.(js|html)$/.test(f)).forEach((f) => {
    const s = fs.readFileSync(f, "utf8");
    assert.ok(!/fetch\(|XMLHttpRequest|WebSocket|https?:\/\/(?!www\.w3\.org)/.test(s), path.basename(f));
    assert.ok(!/qr ?code|chave pix|cartão de crédito/i.test(s), path.basename(f));
  });
});

test("workflow: testes, JDK 17, Android SDK, Gradle, APK e artefato", () => {
  const y = rd(".github/workflows/build.yml");
  ["npm test", "java-version: 17", "setup-android", "setup-gradle", "assembleDebug", "upload-artifact", "workflow_dispatch", "tsgames.zip"]
    .forEach((k) => assert.ok(y.includes(k), k));
  assert.ok(!/password|secret|keystore/i.test(y.replace(/secrets-free/g, "")), "sem credenciais no workflow");
  assert.ok(/app\/build\/outputs\/apk\/debug/.test(y));
  assert.ok(ex(".github/workflows/unpack.yml"));
});

test("sem chaves ou senhas no repositório", () => {
  assert.ok(rd(".gitignore").includes("*.keystore"));
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.name === "node_modules" ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  walk(ROOT).forEach((f) => assert.ok(!/\.(jks|keystore|pem|p12)$/.test(f), f));
});

test("package.json executa todos os testes", () => {
  const p = JSON.parse(rd("package.json"));
  assert.equal(p.scripts.test, "node --test tests/*.test.js");
  assert.equal(p.author, "Thalisson Torricelli");
});
