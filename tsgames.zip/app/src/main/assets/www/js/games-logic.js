/*
 * TSGames — Lógica pura dos jogos (sem tela, sem carteira).
 * Uma criação de Thalisson Torricelli.
 * O resultado de cada rodada é sorteado aqui ANTES da animação; a tela só mostra.
 */
(function (root, factory) {
  var E = typeof module === "object" && module.exports ? require("./engine.js") : root.TS.engine;
  var api = factory(E);
  if (typeof module === "object" && module.exports) module.exports = api;
  else { root.TS = root.TS || {}; root.TS.logic = api; }
})(typeof window !== "undefined" ? window : this, function (E) {
  "use strict";
  var r2 = E.round2;

  // ---------------- Roleta europeia ----------------
  var ORDER = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
  function rWins(b, n) {
    switch (b.type) {
      case "straight": return n === b.v;
      case "red": return n > 0 && E.rouletteColor(n) === "red";
      case "black": return n > 0 && E.rouletteColor(n) === "black";
      case "even": return n > 0 && n % 2 === 0;
      case "odd": return n % 2 === 1;
      case "low": return n >= 1 && n <= 18;
      case "high": return n >= 19 && n <= 36;
      case "dozen": return n >= 1 && Math.ceil(n / 12) === b.v;
      case "column": return n >= 1 && ((n - 1) % 3) + 1 === b.v;
    }
    return false;
  }
  // Retorno total (aposta + lucro) das apostas vencedoras.
  function rPayout(bets, n) {
    var t = 0;
    bets.forEach(function (b) {
      if (rWins(b, n)) t += b.stake * (E.ROULETTE[b.type].pays + 1);
    });
    return r2(t);
  }
  var roulette = { ORDER: ORDER, wins: rWins, payout: rPayout,
                   spin: function () { return E.randomInt(37); } };

  // ---------------- Blackjack ----------------
  var RANKS = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"], SUITS = ["♠","♥","♦","♣"];
  function newDeck() {
    var d = [];
    SUITS.forEach(function (s) { RANKS.forEach(function (r) { d.push({ r: r, s: s }); }); });
    for (var i = d.length - 1; i > 0; i--) {
      var j = E.randomInt(i + 1), t = d[i]; d[i] = d[j]; d[j] = t;
    }
    return d;
  }
  function cardVal(c) { return c.r === "A" ? 11 : ("JQK".indexOf(c.r) >= 0 ? 10 : Number(c.r)); }
  function handValue(cards) {
    var t = 0, aces = 0;
    cards.forEach(function (c) { t += cardVal(c); if (c.r === "A") aces++; });
    while (t > 21 && aces > 0) { t -= 10; aces--; }
    return { total: t, soft: aces > 0 };
  }
  function isBJ(h) { return h.length === 2 && handValue(h).total === 21; }
  function dealerPlay(deck, hand) { // o dealer para em 17 (inclusive 17 "soft")
    while (handValue(hand).total < 17) hand.push(deck.pop());
    return hand;
  }
  // mult = retorno total sobre o valor apostado.
  function bjResult(p, d) {
    var pt = handValue(p).total, dt = handValue(d).total, pb = isBJ(p), db = isBJ(d);
    if (pb && db) return { outcome: "push", mult: 1 };
    if (pb) return { outcome: "blackjack", mult: 2.5 };
    if (db) return { outcome: "lose", mult: 0 };
    if (pt > 21) return { outcome: "lose", mult: 0 };
    if (dt > 21) return { outcome: "win", mult: 2 };
    if (pt > dt) return { outcome: "win", mult: 2 };
    if (pt === dt) return { outcome: "push", mult: 1 };
    return { outcome: "lose", mult: 0 };
  }
  var blackjack = { newDeck: newDeck, cardVal: cardVal, handValue: handValue, isBlackjack: isBJ,
                    dealerPlay: dealerPlay, result: bjResult };

  // ---------------- Caça-níqueis (3 rolos, símbolos originais) ----------------
  var SYM = [
    { s: "◆", w: 30, p3: 6 }, { s: "▲", w: 24, p3: 12 }, { s: "●", w: 18, p3: 25 },
    { s: "★", w: 10, p3: 60 }, { s: "7", w: 5, p3: 150 }, { s: "♛", w: 2, p3: 500 }
  ];
  var SW = SYM.reduce(function (a, x) { return a + x.w; }, 0);
  var PAIR_DIAMOND = 2; // ◆ ◆ nos dois primeiros rolos (e o terceiro diferente)
  function reelDraw() {
    var u = E.randomInt(SW), acc = 0;
    for (var i = 0; i < SYM.length; i++) { acc += SYM[i].w; if (u < acc) return i; }
    return 0;
  }
  function slotMult(r) { // r = [i, j, k] índices dos símbolos
    if (r[0] === r[1] && r[1] === r[2]) return SYM[r[0]].p3;
    if (r[0] === 0 && r[1] === 0) return PAIR_DIAMOND;
    return 0;
  }
  function slotStats() {
    var rtp = 0, hit = 0, n = SYM.length, i, j, k;
    for (i = 0; i < n; i++) for (j = 0; j < n; j++) for (k = 0; k < n; k++) {
      var p = (SYM[i].w / SW) * (SYM[j].w / SW) * (SYM[k].w / SW), m = slotMult([i, j, k]);
      rtp += p * m; if (m > 0) hit += p;
    }
    return { rtp: rtp, hitFrequency: hit };
  }
  var slots = { SYM: SYM, spin: function () { return [reelDraw(), reelDraw(), reelDraw()]; },
                mult: slotMult, stats: slotStats };

  // ---------------- Crash ----------------
  // P(ponto >= m) = (1 - margem) / m  para m >= 1  =>  RTP = 1 - margem em qualquer saque.
  function crashPoint(edge, u) {
    var m = (1 - edge) / u;
    return Math.max(1, Math.floor(m * 100) / 100);
  }
  var crash = {
    point: crashPoint,
    random: function (edge) { return crashPoint(edge, (E.randomInt(1000000000) + 1) / 1000000000); },
    multAt: function (t, rate) { return Math.floor(Math.exp(rate * t) * 100) / 100; },
    timeTo: function (m, rate) { return Math.log(m) / rate; }
  };

  // ---------------- Plinko (8 fileiras, 9 compartimentos) ----------------
  var PL = {
    low: [5.6, 2.1, 1.1, 1, 0.5, 1, 1.1, 2.1, 5.6],
    medium: [13, 3, 1.3, 0.7, 0.4, 0.7, 1.3, 3, 13],
    high: [29, 4, 1.5, 0.3, 0.2, 0.3, 1.5, 4, 29]
  };
  var BIN = [1, 8, 28, 56, 70, 56, 28, 8, 1];
  function plDrop() {
    var path = [], bin = 0;
    for (var i = 0; i < 8; i++) { var b = E.randomInt(2); path.push(b); bin += b; }
    return { path: path, bin: bin };
  }
  function plRtp(level) {
    var t = 0;
    PL[level].forEach(function (m, i) { t += m * BIN[i] / 256; });
    return t;
  }
  var plinko = { MULT: PL, PROB: BIN.map(function (c) { return c / 256; }), drop: plDrop, rtp: plRtp };

  // ---------------- Dados (2 dados, soma) ----------------
  var DB = {
    under7: { name: "Menos de 7", count: 15, mult: 2.3 },
    over7: { name: "Mais de 7", count: 15, mult: 2.3 },
    seven: { name: "Exatamente 7", count: 6, mult: 5.5 },
    doubles: { name: "Dados iguais", count: 6, mult: 5.5 }
  };
  function dWins(t, a, b) {
    var s = a + b;
    return t === "under7" ? s < 7 : t === "over7" ? s > 7 : t === "seven" ? s === 7 : a === b;
  }
  function dRtp(t) {
    var w = 0;
    for (var a = 1; a <= 6; a++) for (var b = 1; b <= 6; b++) if (dWins(t, a, b)) w++;
    return { combos: w, probability: w / 36, rtp: (w / 36) * DB[t].mult };
  }
  var dice = { TYPES: DB, wins: dWins, rtp: dRtp,
               roll: function () { return [E.randomInt(6) + 1, E.randomInt(6) + 1]; } };

  return { roulette: roulette, blackjack: blackjack, slots: slots, crash: crash, plinko: plinko, dice: dice };
});
