"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../app/src/main/assets/www/js/games-logic.js");
const close = (a, b, t = 1e-9) => assert.ok(Math.abs(a - b) <= t, `${a} != ${b}`);
const c = (r, s = "♠") => ({ r, s });

test("roleta: ordem da roda tem os 37 números sem repetição", () => {
  assert.equal(L.roulette.ORDER.length, 37);
  assert.equal(new Set(L.roulette.ORDER).size, 37);
  L.roulette.ORDER.forEach((n) => assert.ok(n >= 0 && n <= 36));
});

test("roleta: pagamentos de cada tipo de aposta", () => {
  const P = L.roulette.payout;
  assert.equal(P([{ type: "straight", v: 17, stake: 10 }], 17), 360);
  assert.equal(P([{ type: "straight", v: 17, stake: 10 }], 18), 0);
  assert.equal(P([{ type: "red", stake: 10 }], 1), 20);
  assert.equal(P([{ type: "red", stake: 10 }], 2), 0);
  assert.equal(P([{ type: "black", stake: 10 }], 2), 20);
  assert.equal(P([{ type: "even", stake: 10 }], 4), 20);
  assert.equal(P([{ type: "odd", stake: 10 }], 5), 20);
  assert.equal(P([{ type: "low", stake: 10 }], 18), 20);
  assert.equal(P([{ type: "high", stake: 10 }], 19), 20);
  assert.equal(P([{ type: "dozen", v: 2, stake: 10 }], 13), 30);
  assert.equal(P([{ type: "column", v: 3, stake: 10 }], 36), 30);
  assert.equal(P([{ type: "column", v: 1, stake: 10 }], 1), 30);
});

test("roleta: o zero perde todas as apostas externas", () => {
  ["red", "black", "even", "odd", "low", "high"].forEach((t) =>
    assert.equal(L.roulette.payout([{ type: t, stake: 10 }], 0), 0, t));
  [1, 2, 3].forEach((v) => {
    assert.equal(L.roulette.payout([{ type: "dozen", v, stake: 1 }], 0), 0);
    assert.equal(L.roulette.payout([{ type: "column", v, stake: 1 }], 0), 0);
  });
  assert.equal(L.roulette.payout([{ type: "straight", v: 0, stake: 1 }], 0), 36);
});

test("roleta: retorno esperado exato de 36/37 em cada aposta (enumeração)", () => {
  const bets = [{ type: "red" }, { type: "even" }, { type: "dozen", v: 1 }, { type: "column", v: 2 }, { type: "straight", v: 7 }];
  bets.forEach((b) => {
    let tot = 0;
    for (let n = 0; n <= 36; n++) tot += L.roulette.payout([{ ...b, stake: 1 }], n);
    close(tot / 37, 36 / 37, 1e-12);
  });
});

test("blackjack: valor da mão e ás", () => {
  const V = L.blackjack.handValue;
  assert.equal(V([c("A"), c("K")]).total, 21);
  assert.equal(V([c("A"), c("A"), c("9")]).total, 21);
  assert.equal(V([c("A"), c("5"), c("K")]).total, 16);
  assert.equal(V([c("K"), c("Q"), c("5")]).total, 25);
  assert.equal(V([c("A"), c("6")]).soft, true);
  assert.equal(V([c("A"), c("6"), c("10")]).soft, false);
  assert.equal(L.blackjack.isBlackjack([c("A"), c("Q")]), true);
  assert.equal(L.blackjack.isBlackjack([c("7"), c("7"), c("7")]), false);
});

test("blackjack: baralho com 52 cartas distintas", () => {
  const d = L.blackjack.newDeck();
  assert.equal(d.length, 52);
  assert.equal(new Set(d.map((x) => x.r + x.s)).size, 52);
});

test("blackjack: resultados da mão", () => {
  const R = L.blackjack.result;
  assert.deepEqual(R([c("A"), c("K")], [c("9"), c("8")]), { outcome: "blackjack", mult: 2.5 });
  assert.equal(R([c("A"), c("K")], [c("A"), c("Q")]).outcome, "push");
  assert.equal(R([c("9"), c("8")], [c("A"), c("Q")]).outcome, "lose");
  assert.equal(R([c("K"), c("Q"), c("5")], [c("9"), c("8")]).mult, 0);
  assert.equal(R([c("9"), c("8")], [c("K"), c("6"), c("9")]).mult, 2);
  assert.equal(R([c("K"), c("9")], [c("K"), c("8")]).mult, 2);
  assert.equal(R([c("K"), c("8")], [c("K"), c("8")]).mult, 1);
  assert.equal(R([c("K"), c("7")], [c("K"), c("8")]).mult, 0);
  // 21 com três cartas não é blackjack natural
  assert.equal(R([c("7"), c("7"), c("7")], [c("K"), c("9")]).mult, 2);
});

test("blackjack: dealer compra até 17", () => {
  const deck = [c("2"), c("3"), c("4"), c("5")].reverse();
  const h = L.blackjack.dealerPlay(deck, [c("5"), c("6")]);
  assert.ok(L.blackjack.handValue(h).total >= 17);
  const h2 = L.blackjack.dealerPlay([c("2")], [c("K"), c("7")]);
  assert.equal(h2.length, 2);
});

test("caça-níqueis: tabela, RTP teórico e frequência de prêmio", () => {
  const s = L.slots.stats();
  assert.ok(s.rtp > 0.9 && s.rtp < 1, "RTP " + s.rtp);
  assert.ok(s.hitFrequency > 0.05 && s.hitFrequency < 0.4);
  assert.equal(L.slots.mult([0, 0, 0]), 6);
  assert.equal(L.slots.mult([5, 5, 5]), 500);
  assert.equal(L.slots.mult([0, 0, 3]), 2);
  assert.equal(L.slots.mult([0, 1, 0]), 0);
  assert.equal(L.slots.mult([1, 1, 2]), 0);
});

test("caça-níqueis: giro produz índices válidos e a frequência observada se aproxima da teórica", () => {
  let hits = 0; const N = 60000;
  for (let i = 0; i < N; i++) {
    const r = L.slots.spin();
    r.forEach((x) => assert.ok(x >= 0 && x < L.slots.SYM.length));
    if (L.slots.mult(r) > 0) hits++;
  }
  close(hits / N, L.slots.stats().hitFrequency, 0.01);
});

test("crash: ponto mínimo 1,00 e RTP de (1 - margem) em qualquer saque", () => {
  assert.equal(L.crash.point(0.04, 1), 1);
  assert.equal(L.crash.point(0.04, 0.96), 1);
  assert.equal(L.crash.point(0.04, 0.48), 2);
  let ge2 = 0, ge10 = 0; const N = 100000;
  for (let i = 0; i < N; i++) { const p = L.crash.random(0.04); assert.ok(p >= 1); if (p >= 2) ge2++; if (p >= 10) ge10++; }
  close(ge2 / N, 0.48, 0.01);
  close(ge10 / N, 0.096, 0.006);
});

test("crash: multiplicador cresce com o tempo", () => {
  assert.equal(L.crash.multAt(0, 0.15), 1);
  assert.ok(L.crash.multAt(10, 0.15) > L.crash.multAt(5, 0.15));
  close(L.crash.timeTo(2, 0.15), Math.log(2) / 0.15);
});

test("plinko: probabilidades somam 1 e RTP exato de cada nível", () => {
  close(L.plinko.PROB.reduce((a, b) => a + b, 0), 1);
  ["low", "medium", "high"].forEach((lv) => {
    assert.equal(L.plinko.MULT[lv].length, 9);
    const r = L.plinko.rtp(lv);
    assert.ok(r > 0.97 && r < 1, lv + " " + r);
  });
});

test("plinko: queda tem 8 passos e o compartimento é a soma", () => {
  for (let i = 0; i < 2000; i++) {
    const d = L.plinko.drop();
    assert.equal(d.path.length, 8);
    assert.equal(d.bin, d.path.reduce((a, b) => a + b, 0));
    assert.ok(d.bin >= 0 && d.bin <= 8);
  }
});

test("dados: combinações, probabilidades e RTP", () => {
  assert.equal(L.dice.rtp("under7").combos, 15);
  assert.equal(L.dice.rtp("over7").combos, 15);
  assert.equal(L.dice.rtp("seven").combos, 6);
  assert.equal(L.dice.rtp("doubles").combos, 6);
  Object.keys(L.dice.TYPES).forEach((t) => { const r = L.dice.rtp(t).rtp; assert.ok(r > 0.9 && r < 1, t + r); });
  assert.equal(L.dice.wins("under7", 3, 3), true);
  assert.equal(L.dice.wins("over7", 4, 4), true);
  assert.equal(L.dice.wins("seven", 3, 4), true);
  assert.equal(L.dice.wins("doubles", 2, 2), true);
  assert.equal(L.dice.wins("doubles", 2, 3), false);
  for (let i = 0; i < 500; i++) L.dice.roll().forEach((x) => assert.ok(x >= 1 && x <= 6));
});
