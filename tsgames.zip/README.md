# TSGames

**TSGames — Uma criação de Thalisson Torricelli.**

Aplicativo Android de entretenimento com esportes, cassino, carteira e painel local. Funciona **100% offline**, dentro do aparelho: HTML, CSS e JavaScript em uma `WebView`, sem internet e sem nenhuma permissão do Android.

> Os créditos do aplicativo são virtuais e não têm valor monetário. Depósitos e saques são registros internos, guardados apenas neste aparelho. **Não existe** Pix, cartão, banco, QR Code de pagamento nem qualquer transferência real. Eventos, equipes e partidas são inventados.

---

## O que tem

| Área | Conteúdo |
|---|---|
| **Início** | Saldo, atalhos Depositar/Sacar, busca (eventos e jogos), esportes, eventos em destaque, jogos populares, desempenho, últimas atividades |
| **Esportes** | Futebol, basquete, tênis, vôlei, MMA, boxe e e-sports (3 eventos cada); mercados, cotações, probabilidade implícita, margem do mercado |
| **Bilhetes** | Simples e combinada, valor, retorno potencial, confirmação, histórico, liquidação automática |
| **Cassino** | Roleta europeia, blackjack, caça-níqueis, crash, plinko e dados, cada um com regras, tabela de pagamentos, probabilidades e histórico |
| **Carteira** | Saldo disponível, reservado e total; Depositar; Sacar (com status); Extrato com filtros, ordenação e exportação CSV (texto para copiar) |
| **Perfil** | Nome, avatar, estatísticas, conquistas, histórico de jogos, sons, cor de destaque, reiniciar/apagar dados, Sobre e Créditos |
| **Painel local** | Cotações, resultados dos eventos, parâmetros do crash, limites da carteira, solicitações de saque, ajuste de saldo, estatísticas, registro de ações, restauração dos dados de teste |

## Regras da carteira

Um único módulo (`wallet.js`) altera saldos. Valores em centavos inteiros (sem erros de ponto flutuante).

- **Disponível**: saldo livre.
- **Reservado**: valor separado em saques em análise e apostas em aberto.
- **Total** = disponível + reservado.
- Saque: reserva o valor e fica *Em análise*; depois vira *Aprovado* (sai do total), *Recusado* ou *Cancelado* (volta ao disponível, com lançamento de estorno). A aprovação automática ocorre depois de 20 s com o app aberto (configurável no painel).
- Aposta: reserva o valor; ao liquidar, o reservado é liberado e o prêmio (se houver) é creditado.
- Identidade verificada nos testes: `total = crédito inicial + depósitos − saques + resultado dos jogos + ajustes`.
- Toques repetidos não duplicam operações (chave de operação por formulário).

## Probabilidades (resumo)

| Jogo | Retorno teórico | Observação |
|---|---|---|
| Roleta europeia | 36/37 = 97,30% | 37 resultados equiprováveis; zero perde as apostas externas |
| Blackjack | depende da estratégia | Baralho de 52 cartas por mão; dealer compra até 17; blackjack paga 3:2 |
| Caça-níqueis | calculado em `games-logic.js` | Símbolos ponderados; tabela e frequência teórica × observada na tela do jogo |
| Crash | 1 − margem (padrão 96%) | P(crash ≥ m) = (1 − margem) ÷ m; o ponto é sorteado antes da animação |
| Plinko | por nível de risco | 8 fileiras, distribuição binomial exata |
| Dados | por tipo de aposta | 2 dados, enumeração das 36 combinações |

Resultado de cada rodada é definido pelo motor **antes** da animação. A probabilidade implícita de uma cotação **não** é a probabilidade real do evento; frequência observada **não** é probabilidade teórica.

## Estrutura

```
tsgames/
├── .github/workflows/build.yml     compila e publica o APK
├── .github/workflows/unpack.yml    (opcional) extrai tsgames.zip
├── build.gradle  settings.gradle  gradle.properties
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/thalissontorricelli/tsgames/MainActivity.java
│       ├── res/                    ícone adaptativo, textos, tema
│       └── assets/www/             o aplicativo (HTML, CSS, JS, SVG)
│           ├── index.html
│           ├── css/                base, wallet, games
│           ├── assets/             logos e assinatura TT (SVG)
│           └── js/                 storage, router, engine, games-logic, wallet, pages-wallet,
│                                   statistics, sports, tickets, security, ui, sports-ui,
│                                   casino/*, admin, profile, app
├── tests/                          testes automatizados (Node)
├── package.json  README.md  LICENSE
```

## Testes

```
npm test        # node --test tests/*.test.js  (precisa de Node 18 ou superior)
```

Cobrem: fórmulas de probabilidade, carteira (depósitos, saques, transições de status, duplicidade, limites, persistência, sequência aleatória longa), lógica dos 6 jogos, esportes, bilhetes e liquidação, estatísticas, PIN, integração das telas (DOM simulado), e a consistência do projeto Android (pacote, manifesto, recursos, workflow).

---

### Testes de interface no navegador (opcional, fora do GitHub Actions)

`tests/e2e/*.py` abrem o app em um Chromium headless e clicam pelas telas (carteira, bilhetes, os 6 jogos, perfil, painel). Exigem Python com Playwright e um Chromium instalado; não rodam no celular nem no workflow.

---

## Passo a passo só com o celular

### 1. Criar o repositório
1. No navegador do celular, entre em **github.com** e faça login (ou crie a conta).
2. Toque em **+** → **New repository**. Nome: `tsgames`. Marque **Private** (ou Public) e toque em **Create repository**.

### 2. Enviar o projeto (método mais simples: um único ZIP)
1. Na página do repositório, toque em **Add file** → **Upload files**.
2. Escolha o arquivo **`tsgames.zip`** e toque em **Commit changes**. (O ZIP é enviado inteiro; não precisa extrair.)

### 3. Criar o workflow (arquivo de texto)
1. **Add file** → **Create new file**.
2. No campo do nome digite exatamente: `.github/workflows/build.yml` (ao digitar as barras, o GitHub cria as pastas).
3. Cole o conteúdo abaixo e toque em **Commit changes**.

```yaml
# TSGames — Uma criação de Thalisson Torricelli.
# Compila o app na nuvem: testes -> APK de depuração (assinado com a chave de depuração do Android Gradle Plugin).
name: Build TSGames APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Baixar o repositório
        uses: actions/checkout@v4

      # Se você enviou o projeto como "tsgames.zip" (método mais simples pelo celular), extrai aqui.
      - name: Extrair tsgames.zip (se necessário)
        run: |
          if [ ! -d app ] && [ -f tsgames.zip ]; then
            unzip -q -o tsgames.zip
          fi
          ls -la

      - name: Instalar Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Testes automatizados
        run: npm test

      - name: Instalar JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - name: Configurar Android SDK
        uses: android-actions/setup-android@v3

      - name: Configurar Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.9

      - name: Compilar APK de depuração
        run: gradle --no-daemon assembleDebug

      - name: Conferir o APK
        run: |
          ls -la app/build/outputs/apk/debug/
          unzip -l app/build/outputs/apk/debug/app-debug.apk | grep "assets/www/index.html"

      - name: Publicar o APK
        uses: actions/upload-artifact@v4
        with:
          name: TSGames-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
```

> Este workflow já extrai o `tsgames.zip` sozinho quando as pastas do projeto não estão no repositório.

### 4. Executar
1. Aba **Actions** → **Build TSGames APK** → **Run workflow** → **Run workflow**. (Também roda sozinho a cada envio.)
2. Aguarde alguns minutos. Ícone verde = sucesso; vermelho = falha (veja “Se a compilação falhar”).

### 5. Baixar o APK
1. Abra a execução concluída e role até **Artifacts**.
2. Toque em **TSGames-debug-apk** (baixa um `.zip`). No gerenciador de arquivos do celular, extraia o ZIP: dentro está `app-debug.apk`.

### 6. Instalar
1. Toque no `app-debug.apk`. Se o Android pedir, permita **instalar apps desconhecidos** para o app que você usou (navegador ou gerenciador de arquivos).
2. O Google Play Protect pode avisar que o app não é conhecido: é esperado, o APK é assinado apenas com a chave de depuração.

### Método alternativo: arquivos soltos
Se preferir o repositório com as pastas extraídas: depois do passo 3, vá em **Actions** → **Extrair tsgames.zip** (crie também `unpack.yml` com o conteúdo do arquivo do ZIP) → **Run workflow**. Ele extrai e salva os arquivos (exceto a pasta `.github`, que você já criou).

## Compilação, assinatura e instalação

- **Compilação**: transforma o código-fonte em um APK. Feita pelo GitHub Actions (Gradle + Android SDK). O **APK Tools M não compila** código-fonte.
- **Assinatura**: o Android só instala APKs assinados. O APK de depuração sai assinado automaticamente pela chave de depuração do Android Gradle Plugin. Para atualizar um app já instalado, o novo APK precisa estar assinado com a **mesma** chave.
- **Instalação**: abrir o APK no aparelho.

## Usando o APK Tools M (somente etapas compatíveis)

Use-o para trabalhar **com o APK já gerado**: inspecionar o conteúdo, reassinar com a sua própria chave (criada por você no aplicativo, nunca colocada no repositório) e instalar. Não use para compilar o projeto, e confira as funções disponíveis na sua versão da ferramenta. Se reassinar com outra chave, desinstale antes a versão assinada com a chave anterior.

## Se a compilação falhar

1. Abra a execução vermelha em **Actions** e toque no passo marcado com ✗.
2. Falha em **Testes automatizados**: a linha `not ok` indica qual teste e por quê.
3. Falha em **Compilar APK**: procure a primeira linha com `error:` ou `What went wrong`. Erros de `AndroidManifest`, recursos ou Java aparecem ali com o arquivo e a linha.
4. Corrija o arquivo (pelo ícone de lápis no GitHub) e rode o workflow de novo. Se você enviou só o ZIP, envie um novo `tsgames.zip` corrigido.

## Limitações conhecidas

- **O APK ainda não foi compilado nem instalado por quem gerou este projeto**: o ambiente de desenvolvimento não tinha Gradle, Android SDK nem internet. A primeira execução do workflow é a primeira compilação real; pode exigir um pequeno ajuste.
- O Gradle Wrapper (`gradlew` e o `.jar`) não está incluído (arquivo binário). O workflow instala o Gradle 8.9 por conta própria.
- A interface foi testada com DOM simulado (`npm test`) e em um Chromium headless de computador, na largura de 390 px (`tests/e2e/`, Python + Playwright, fora do `npm test`). **Não** foi testada em uma WebView de Android nem em um aparelho real; ajustes visuais finos podem ser necessários.
- Esportes: futebol tem 5 mercados (resultado, dupla possibilidade, total, ambas marcam, handicap); basquete tem vencedor, total e handicap; as demais modalidades têm vencedor (e total quando aplicável). Não há resultado correto nem mercados por período.
- Tutorial interativo, minijogos adicionais e temas desbloqueáveis além das 3 cores de destaque não foram implementados.
- Exportação de extrato: o CSV é exibido para copiar (a WebView não baixa arquivos).
- O PIN do painel evita alterações acidentais; **não** tem a segurança de um servidor com autenticação.
- Rodada de cassino interrompida (app fechado no meio) é registrada como perdida. A aprovação automática de saques só ocorre com o app aberto.
- Apenas APK de depuração; assinatura de release não está configurada.
- `minSdk 26` (Android 8.0 ou superior).

## Créditos

**TSGames — Uma criação de Thalisson Torricelli.**
Licença MIT (ver `LICENSE`).
