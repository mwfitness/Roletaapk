/* TSGames — Blackjack. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic.blackjack, ui = TS.ui, brl = TS.brl;
  var S = null;
  function card(c, hide) {
    if (hide) return '<div class="pc back"></div>';
    return '<div class="pc' + (c.s === "♥" || c.s === "♦" ? " r" : "") + '"><span>' + c.r + "</span><span>" + c.s + "</span></div>";
  }
  function draw() {
    if (!ui.el("bjd")) return;
    var hide = S && !S.over;
    ui.el("bjd").innerHTML = S ? S.dealer.map(function (c, i) { return card(c, hide && i === 1); }).join("") : "";
    ui.el("bjp").innerHTML = S ? S.player.map(function (c) { return card(c); }).join("") : "";
    ui.el("bjds").textContent = S ? (hide ? "Dealer: " + L.cardVal(S.dealer[0]) : "Dealer: " + L.handValue(S.dealer).total) : "Dealer";
    ui.el("bjps").textContent = S ? "Você: " + L.handValue(S.player).total : "Você";
    var active = S && !S.over;
    ui.el("bjdeal").style.display = active ? "none" : "";
    ui.el("bjact").style.display = active ? "flex" : "none";
  }
  function end(forfeit) {
    if (!S || S.over) return;
    S.over = true;
    var res, payout;
    if (forfeit) { res = { outcome: "lose", mult: 0 }; payout = 0; }
    else {
      var pt = L.handValue(S.player).total;
      if (pt <= 21 && !L.isBlackjack(S.player)) L.dealerPlay(S.deck, S.dealer);
      res = L.result(S.player, S.dealer); payout = S.bet.stake * res.mult;
    }
    var p = ui.finish("blackjack", S.bet, payout, { win: "Vitória", blackjack: "Blackjack", push: "Empate", lose: "Derrota" }[res.outcome] + " · " + brl(S.bet.stake));
    if (TS.current === "blackjack") {
      draw();
      ui.say("bjsay", { win: "Você venceu! Retorno " + brl(p), blackjack: "Blackjack! Retorno " + brl(p), push: "Empate. Valor devolvido.", lose: "Você perdeu a rodada." }[res.outcome],
        res.mult > 1 ? "win" : "lose");
      ui.refreshHist("blackjack");
    }
  }
  TS.pages.blackjack = function () {
    S = null;
    TS.onLeave = function () { if (S && !S.over) end(true); };
    return ui.head("Blackjack", "casino") +
      '<div class="card"><div class="score" id="bjds">Dealer</div><div class="cards" id="bjd"></div>' +
      '<div class="score" id="bjps">Você</div><div class="cards" id="bjp"></div></div>' +
      '<div class="say" id="bjsay">Escolha o valor e dê as cartas</div>' +
      ui.stake("bjstake", "10,00") +
      '<button class="btn primary full" id="bjdeal">Dar cartas</button>' +
      '<div class="row" id="bjact" style="display:none"><button class="btn" id="bjhit">Pedir</button><button class="btn gold" id="bjstand">Parar</button></div>' +
      ui.rules("Objetivo: chegar o mais perto possível de 21 sem passar. Figuras valem 10; o ás vale 11 ou 1. O dealer compra até 17 e para em 17. " +
        "Pagamentos: vitória 1:1, blackjack natural (ás + carta de valor 10 nas duas primeiras cartas) 3:2, empate devolve o valor. " +
        "Baralho único de 52 cartas embaralhado a cada rodada. Sair no meio da mão conta como derrota.") +
      ui.hist("blackjack");
  };
  TS.pages.blackjack.after = draw;
  document.addEventListener("click", function (e) {
    var t = e.target.closest("#bjdeal,#bjhit,#bjstand");
    if (!t || TS.current !== "blackjack") return;
    if (t.id === "bjdeal") {
      var bet = ui.bet("bjstake", "Cassino · Blackjack"); if (!bet) return;
      var deck = L.newDeck();
      S = { deck: deck, bet: bet, player: [deck.pop(), deck.pop()], dealer: [deck.pop(), deck.pop()], over: false };
      ui.say("bjsay", "Sua vez", "info"); ui.sfx("tick");
      if (L.isBlackjack(S.player) || L.isBlackjack(S.dealer)) end(false); else draw();
    } else if (!S || S.over) { return; }
    else if (t.id === "bjhit") {
      S.player.push(S.deck.pop()); ui.sfx("tick");
      if (L.handValue(S.player).total >= 21) end(false); else draw();
    } else if (t.id === "bjstand") end(false);
  });
})(window);
