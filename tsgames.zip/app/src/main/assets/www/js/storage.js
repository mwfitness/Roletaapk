/* TSGames — armazenamento local. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = (g.TS = g.TS || {});
  var P = "tsgames:";
  TS.store = {
    get: function (k, d) {
      try { var v = localStorage.getItem(P + k); return v === null ? d : JSON.parse(v); }
      catch (e) { return d; }
    },
    set: function (k, v) {
      try { localStorage.setItem(P + k, JSON.stringify(v)); return true; }
      catch (e) { return false; }
    },
    clear: function () {
      try {
        Object.keys(localStorage).filter(function (k) { return k.indexOf(P) === 0; })
          .forEach(function (k) { localStorage.removeItem(k); });
      } catch (e) { /* ignora */ }
    }
  };
  TS.brl = function (n) {
    return Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  };
})(window);
