package com.thalissontorricelli.tsgames;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * TSGames — Uma criação de Thalisson Torricelli.
 * Activity mínima: abre a WebView com os arquivos locais em assets/www.
 * Nenhuma interface nativa é exposta à página e nenhuma permissão é usada.
 */
public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final String ALLOWED_PREFIX = "file:///android_asset/www/";
    private static final String ERROR_HTML =
            "<body style='background:#0A0A0B;color:#F2F0EA;font-family:sans-serif;padding:32px'>"
            + "<h3>TSGames</h3><p>Não foi possível carregar o aplicativo. Feche e abra novamente.</p></body>";

    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0A0A0B"));
        setContentView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);        // necessário: o app é feito em JavaScript
        s.setDomStorageEnabled(true);        // localStorage (carteira, histórico, preferências)
        s.setAllowFileAccess(false);         // não afeta file:///android_asset
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setGeolocationEnabled(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Só navega dentro dos arquivos do próprio app.
                return !request.getUrl().toString().startsWith(ALLOWED_PREFIX);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null);
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                recreate();
                return true;
            }
        });

        web.loadUrl(START_URL);
    }

    @Override
    public void onBackPressed() {
        // A página decide: volta uma tela ou, se estiver no Início, o app fecha.
        web.evaluateJavascript(
                "(function(){try{return !!(window.TS&&TS.onBack&&TS.onBack());}catch(e){return false;}})()",
                value -> {
                    if (!"true".equals(value)) {
                        finish();
                    }
                });
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
