/*
 * TSGames — Painel administrativo local.
 * Uma criação de Thalisson Torricelli.
 * Controla apenas os dados deste aparelho (eventos, cotações, resultados, limites e carteira).
 * Acesso por PIN criado pelo usuário (ver security.js). Todas as ações ficam no Registro.
 */
(function (g) {
  var TS = g.TS, W = TS.wallet, SP = TS.sports, TK = TS.tickets, ui = TS.ui, esc = TS.fmt.esc, brl = TS.brl, V = TS.vault, L = TS.logic;
  var P = TS.Wallet.parseBRL;
  var st = { ok: false, tab: "over", sport: "football" };
  var TABS = [["over", "Geral"], ["events", "Eventos"], ["games", "Jogos"], ["ops", "Operações"], ["data", "Dados"], ["log", "Registro"]];
  TS.parentTab.admin = TS.parentTab.adminlogin = TS.parentTab.adminevent = "profile";

  function log(t) {
    var l = TS.store.get("adminlog", []);
    l.push({ ts: Date.now(), t: t });
    if (l.length > 200) l.shift();
    TS.store.set("adminlog", l);
  }
  TS.adminLog = log;
  function dec(n) { return Number(n).toFixed(2).replace(".", ","); }
  function pct(n) { return ui.pct(n); }
  function cfg() { return Object.assign({ crashEdge: 0.04, crashRate: 0.15 }, TS.store.get("gcfg", {})); }
  function row(a, b) { return '<div class="sumrow"><span>' + a + "</span><b>" + b + "</b></div>"; }
  function stat(k, v) { return '<div class="stat"><div class="k">' + k + '</div><div class="v">' + v + "</div></div>"; }

  // ---------- Acesso ----------
  TS.pages.adminlogin = function () {
    var has = V.hasPin();
    return ui.head("Painel local", "profile") +
      '<div class="card"><div class="muted">' + (has ? "Digite o seu PIN." : "Crie um PIN de 4 a 8 dígitos para proteger o painel.") + "</div>" +
      '<input class="field" id="pin1" type="password" inputmode="numeric" maxlength="8" placeholder="PIN" style="margin-top:8px">' +
      (has ? "" : '<input class="field" id="pin2" type="password" inputmode="numeric" maxlength="8" placeholder="Confirmar PIN" style="margin-top:8px">') +
      '<button class="btn primary full" id="pinGo">' + (has ? "Entrar" : "Criar PIN") + "</button></div>" +
      '<p class="muted" style="line-height:1.5">O painel local evita alterações acidentais, mas não tem a segurança de um sistema com servidor e autenticação.</p>';
  };

  // ---------- Painel ----------
  TS.pages.admin = function () {
    if (!st.ok) return TS.pages.adminlogin();
    return ui.head("Painel local", "profile") +
      '<div class="scroller" style="margin-bottom:10px">' + TABS.map(function (t) {
        return '<div class="pill' + (st.tab === t[0] ? " on" : "") + '" data-atab="' + t[0] + '">' + t[1] + "</div>";
      }).join("") + "</div>" + TABS_HTML[st.tab]();
  };

  var TABS_HTML = {
    over: function () {
      var s = W.summary(), sm = TS.stats.summary(), all = SP.list("all"), tk = TK.list();
      return '<div class="grid">' +
        stat("Disponível", brl(s.available)) + stat("Reservado", brl(s.reserved)) + stat("Total", brl(s.total)) +
        stat("Depósitos", brl(s.deposits)) + stat("Saques", brl(s.withdrawals)) + stat("Resultado dos jogos", brl(s.gameResult)) +
        stat("Rodadas", sm.rounds) + stat("Vitórias", sm.rounds ? pct(sm.wins / sm.rounds) : "—") +
        stat("Bilhetes", tk.filter(function (t) { return t.status === "open"; }).length + " abertos / " + tk.length) +
        stat("Eventos", all.filter(function (e) { return e.status === "open"; }).length + " abertos / " + all.length) +
        stat("Saques em análise", W.pendingWithdrawals().length) + stat("Apostas em aberto", W.openBets().length) + "</div>" +
        "<h2>Rodadas por jogo</h2><div class=\"card\">" +
        (Object.keys(sm.games).length ? Object.keys(sm.games).map(function (k) { return row(esc(k), sm.games[k]); }).join("") : '<div class="muted">Sem rodadas.</div>') + "</div>";
    },
    events: function () {
      return '<div class="scroller">' + SP.SPORTS.map(function (s) {
        return '<div class="pill' + (st.sport === s[0] ? " on" : "") + '" data-asport="' + s[0] + '">' + s[1] + "</div>";
      }).join("") + "</div><div style=\"height:10px\"></div>" +
        SP.list(st.sport).map(function (ev) {
          return '<div class="ev"><div class="meta"><span>' + esc(ev.id) + " · " + esc(ev.when) + "</span><span>" +
            (ev.status === "finished" ? "Encerrado " + ev.score[0] + "–" + ev.score[1] : "Aberto") + "</span></div>" +
            '<div class="teams" data-go="adminevent" data-arg="' + ev.id + '">' + esc(ev.home) + " x " + esc(ev.away) + " ›</div></div>";
        }).join("");
    },
    games: function () {
      var c = cfg(), lg = L.dice;
      return '<div class="card"><b>Crash</b><div class="muted" style="margin:6px 0">Margem da casa (%) e velocidade de subida</div>' +
        '<input class="field" id="cfgEdge" inputmode="decimal" value="' + dec(c.crashEdge * 100) + '">' +
        '<input class="field" id="cfgRate" inputmode="decimal" value="' + dec(c.crashRate) + '" style="margin-top:8px">' +
        '<button class="btn primary full" id="cfgSave">Salvar</button></div>' +
        "<h2>Retorno teórico</h2><div class=\"card\">" +
        row("Roleta europeia", pct(36 / 37)) + row("Caça-níqueis", pct(L.slots.stats().rtp)) +
        row("Crash (qualquer saque)", pct(1 - c.crashEdge)) +
        ["low", "medium", "high"].map(function (k) { return row("Plinko · " + k, pct(L.plinko.rtp(k))); }).join("") +
        Object.keys(lg.TYPES).map(function (k) { return row("Dados · " + lg.TYPES[k].name, pct(lg.rtp(k).rtp)); }).join("") + "</div>";
    },
    ops: function () {
      var S = W.getSettings(), pend = W.pendingWithdrawals();
      function inp(id, v) { return '<input class="field sm" id="' + id + '" inputmode="decimal" value="' + dec(v) + '">'; }
      return "<h2>Solicitações de saque</h2><div class=\"card\">" +
        (pend.length ? pend.map(function (r) {
          return '<div class="tx"><div class="l"><b>' + r.id + '</b><div class="muted small">' + TS.fmt.fdate(r.ts) + '</div></div><div class="r"><div class="amt">' + brl(Math.abs(r.amount)) + "</div>" +
            '<div class="row"><button class="mini" data-wd="approved|' + r.id + '">Aprovar</button><button class="mini" data-wd="rejected|' + r.id + '">Recusar</button><button class="mini" data-wd="cancelled|' + r.id + '">Cancelar</button></div></div></div>';
        }).join("") : '<div class="muted">Nenhuma solicitação em análise.</div>') + "</div>" +
        '<div class="card"><b>Limites e aprovação</b>' +
        '<div class="oddrow"><span>Depósito mínimo</span>' + inp("lmDmin", S.minDeposit) + "</div>" +
        '<div class="oddrow"><span>Depósito máximo</span>' + inp("lmDmax", S.maxDeposit) + "</div>" +
        '<div class="oddrow"><span>Saque mínimo</span>' + inp("lmSmin", S.minWithdraw) + "</div>" +
        '<div class="oddrow"><span>Saque máximo</span>' + inp("lmSmax", S.maxWithdraw) + "</div>" +
        '<div class="oddrow"><span>Aprovação automática (s, 0 = manual)</span>' + inp("lmAuto", S.autoApproveMs / 1000) + "</div>" +
        '<button class="btn primary full" id="lmSave">Salvar limites</button></div>' +
        "<h2>Últimas operações</h2><div class=\"card\">" +
        W.list({ limit: 12 }).map(function (r) { return row(esc(r.id) + " · " + esc(r.type), TS.fmt.signed(r.amount)); }).join("") +
        '<button class="btn full" data-go="statement">Abrir extrato</button></div>';
    },
    data: function () {
      return '<div class="card"><b>Ajuste de saldo</b><div class="muted" style="margin:6px 0">Use sinal negativo para debitar.</div>' +
        '<input class="field" id="adjV" inputmode="decimal" placeholder="Ex.: 100,00 ou -50,00">' +
        '<input class="field" id="adjD" placeholder="Descrição" style="margin-top:8px">' +
        '<button class="btn primary full" id="adjGo">Aplicar ajuste</button></div>' +
        '<div class="card"><b>Resultados dos eventos</b>' +
        '<button class="btn full" id="simAll">Encerrar eventos abertos (simulação)</button>' +
        '<button class="btn full" id="rstEv">Restaurar eventos de demonstração</button></div>' +
        '<div class="card"><b>Dados de teste</b><div class="muted" style="margin:6px 0">Restaura carteira, eventos, bilhetes e histórico de rodadas.</div>' +
        '<button class="btn danger full" id="rstAll">Restaurar dados de teste</button>' +
        '<button class="btn full" id="pinClear">Remover PIN do painel</button>' +
        '<button class="btn full" id="admOut">Sair do painel</button></div>';
    },
    log: function () {
      var l = TS.store.get("adminlog", []).slice().reverse().slice(0, 60);
      return '<div class="card">' + (l.length ? l.map(function (x) {
        return '<div class="hrow"><span>' + TS.fmt.fdate(x.ts) + "</span><span style=\"color:var(--text);text-align:right\">" + esc(x.t) + "</span></div>";
      }).join("") : '<div class="muted">Nenhuma ação registrada.</div>') + "</div>";
    }
  };

  // ---------- Edição de evento ----------
  TS.pages.adminevent = function (id) {
    if (!st.ok) return TS.pages.adminlogin();
    var ev = SP.get(id);
    if (!ev) return ui.head("Evento", "admin") + '<div class="card muted">Evento não encontrado.</div>';
    var fin = ev.status === "finished";
    return ui.head(esc(ev.home) + " x " + esc(ev.away), "admin") +
      '<div class="muted" style="margin-bottom:10px">' + esc(ev.id) + " · " + esc(ev.when) + "</div>" +
      ev.markets.map(function (m) {
        return '<div class="card"><b>' + esc(m.name) + "</b>" + m.sels.map(function (s) {
          return '<div class="oddrow"><span>' + esc(s.label) + '</span><input class="field sm" data-odd="' + ev.id + "|" + m.id + "|" + s.id + '" inputmode="decimal" value="' + dec(s.odds) + '"></div>';
        }).join("") + "</div>";
      }).join("") +
      '<button class="btn primary full" id="oddSave" data-ev="' + ev.id + '">Salvar cotações</button>' +
      "<h2>Resultado</h2><div class=\"card\">" +
      (fin ? row("Placar", ev.score[0] + " – " + ev.score[1]) + '<button class="btn full" id="evReopen" data-ev="' + ev.id + '">Reabrir evento</button>' +
             '<div class="muted" style="margin-top:8px">Bilhetes já liquidados não são alterados.</div>'
           : '<div class="row"><input class="field" id="sc0" inputmode="numeric" placeholder="Casa"><input class="field" id="sc1" inputmode="numeric" placeholder="Fora"></div>' +
             '<button class="btn gold full" id="evFinish" data-ev="' + ev.id + '">Encerrar com este placar</button>' +
             '<button class="btn full" id="evSim" data-ev="' + ev.id + '">Simular e encerrar</button>') + "</div>";
  };

  // ---------- Ações ----------
  function arm(btn, label, fn) {
    if (btn.dataset.armed) { fn(); return; }
    var old = btn.textContent;
    btn.dataset.armed = "1"; btn.textContent = label;
    setTimeout(function () { if (btn.isConnected) { delete btn.dataset.armed; btn.textContent = old; } }, 4000);
  }
  function num(id) { var e = ui.el(id); return e ? P(e.value) : NaN; }
  function done(msg) { TS.toast(msg); TS.refresh(); }
  function fail(msg) { TS.toast(msg, "err"); }
  function settledMsg(r) { return r.settled ? " · " + r.settled + " bilhete(s) liquidado(s)" : ""; }

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-atab],[data-asport],[data-wd],#pinGo,#cfgSave,#lmSave,#adjGo,#simAll,#rstEv,#rstAll,#pinClear,#admOut,#oddSave,#evFinish,#evSim,#evReopen");
    if (!t) return;
    if (t.hasAttribute("data-atab")) { st.tab = t.getAttribute("data-atab"); TS.refresh(); return; }
    if (t.hasAttribute("data-asport")) { st.sport = t.getAttribute("data-asport"); TS.refresh(); return; }
    if (t.hasAttribute("data-wd")) {
      var p = t.getAttribute("data-wd").split("|"), r = W.resolveWithdrawal(p[1], p[0]);
      if (!r.ok) return fail(r.error);
      log("Saque " + p[1] + " → " + p[0]); return done("Solicitação atualizada");
    }
    switch (t.id) {
      case "pinGo": {
        var a = ui.el("pin1").value;
        if (V.hasPin()) {
          if (!V.check(a)) return fail("PIN incorreto.");
        } else {
          var s = V.setPin(a, ui.el("pin2").value);
          if (!s.ok) return fail(s.error);
          log("PIN do painel criado");
        }
        st.ok = true; TS.go("admin"); return;
      }
      case "cfgSave": {
        var ed = num("cfgEdge") / 100, rt = num("cfgRate");
        if (!(ed >= 0.01 && ed <= 0.15)) return fail("Margem entre 1% e 15%.");
        if (!(rt >= 0.05 && rt <= 0.5)) return fail("Velocidade entre 0,05 e 0,50.");
        TS.store.set("gcfg", { crashEdge: ed, crashRate: rt });
        log("Crash: margem " + dec(ed * 100) + "% · velocidade " + dec(rt)); return done("Configuração salva");
      }
      case "lmSave": {
        var r2 = W.setSettings({ minDeposit: num("lmDmin"), maxDeposit: num("lmDmax"), minWithdraw: num("lmSmin"), maxWithdraw: num("lmSmax"),
                                 autoApproveMs: Math.round(num("lmAuto") * 1000) });
        if (!r2.ok) return fail(r2.error);
        log("Limites da carteira atualizados"); return done("Limites salvos");
      }
      case "adjGo": {
        var v = num("adjV"), n = ui.el("adjV").value.trim().charAt(0) === "-" ? -Math.abs(P(ui.el("adjV").value.replace("-", ""))) : v;
        var r3 = W.adjust(n, ui.el("adjD").value.trim() || "Ajuste administrativo");
        if (!r3.ok) return fail(r3.error);
        log("Ajuste de saldo " + dec(n)); return done("Ajuste aplicado");
      }
      case "simAll": {
        var c = 0, q = 0;
        SP.list("all").forEach(function (ev) {
          if (ev.status !== "open") return;
          var rr = TK.finishEvent(ev.id, SP.simulate(ev)); if (rr.ok) { c++; q += rr.settled; }
        });
        log("Eventos encerrados por simulação: " + c); return done(c + " evento(s) encerrado(s) · " + q + " bilhete(s)");
      }
      case "rstEv":
        if (TK.list("open").length) return fail("Há bilhetes abertos. Liquide-os antes.");
        return arm(t, "Toque novamente para confirmar", function () { SP.reset(); log("Eventos restaurados"); done("Eventos restaurados"); });
      case "rstAll":
        return arm(t, "Toque novamente para confirmar", function () {
          W.reset(); SP.reset(); TK.reset(); TS.stats.clear(); TS.store.set("deferred", []);
          log("Dados de teste restaurados"); done("Dados de teste restaurados");
        });
      case "pinClear": V.clear(); st.ok = false; log("PIN removido"); TS.go("profile"); return;
      case "admOut": st.ok = false; TS.go("profile"); return;
      case "oddSave": {
        var bad = 0, ch = 0;
        document.querySelectorAll("[data-odd]").forEach(function (i) {
          var k = i.getAttribute("data-odd").split("|"), cur = SP.get(k[0]).markets.filter(function (m) { return m.id === k[1]; })[0].sels.filter(function (s) { return s.id === k[2]; })[0];
          var val = P(i.value);
          if (Math.abs(val - cur.odds) < 1e-9) return;
          if (SP.setOdds(k[0], k[1], k[2], val).ok) ch++; else bad++;
        });
        if (bad) return fail(bad + " cotação(ões) inválida(s) (1,01 a 1000).");
        log("Cotações do evento " + t.getAttribute("data-ev") + " (" + ch + " alteradas)"); return done("Cotações salvas");
      }
      case "evFinish": {
        var sc = [num("sc0"), num("sc1")], id = t.getAttribute("data-ev");
        var rf = TK.finishEvent(id, sc);
        if (!rf.ok) return fail(rf.error);
        log("Evento " + id + " encerrado " + sc[0] + "–" + sc[1]); return done("Evento encerrado" + settledMsg(rf));
      }
      case "evSim": {
        var id2 = t.getAttribute("data-ev"), sc2 = SP.simulate(SP.get(id2)), rs = TK.finishEvent(id2, sc2);
        if (!rs.ok) return fail(rs.error);
        log("Evento " + id2 + " simulado " + sc2[0] + "–" + sc2[1]); return done("Evento encerrado" + settledMsg(rs));
      }
      case "evReopen": SP.reopen(t.getAttribute("data-ev")); log("Evento " + t.getAttribute("data-ev") + " reaberto"); return done("Evento reaberto");
    }
  });
})(window);
