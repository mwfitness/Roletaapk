/*
 * TSGames — Esportes: eventos fictícios, mercados, cotações e liquidação.
 * Uma criação de Thalisson Torricelli.
 * Todas as equipes e partidas são inventadas; não representam eventos reais.
 */
(function (root, factory) {
  var E = typeof module === "object" && module.exports ? require("./engine.js") : root.TS.engine;
  var api = factory(E);
  if (typeof module === "object" && module.exports) module.exports = api;
  else { root.TS = root.TS || {}; root.TS.Sports = api; if (root.TS.store) root.TS.sports = api.create({ storage: root.TS.store }); }
})(typeof window !== "undefined" ? window : this, function (E) {
  "use strict";
  var SPORTS = [["football", "Futebol"], ["basketball", "Basquete"], ["tennis", "Tênis"],
                ["volleyball", "Vôlei"], ["mma", "MMA"], ["boxing", "Boxe"], ["esports", "E-sports"]];
  // [casa, fora, força da casa (0-1), horário]
  var TABLE = {
    football: [["Aurora FC", "Vila Marinha", .58, "Hoje 19:30"], ["Estrela do Vale", "Norte Unido", .45, "Hoje 21:00"], ["Cobalto SC", "Ferroviário Serra", .35, "Amanhã 16:00"]],
    basketball: [["Titãs de Ferro", "Cometas do Sul", .6, "Hoje 20:00"], ["Lobos da Baía", "Falcões Urbanos", .5, "Hoje 22:00"], ["Pioneiros", "Tempestade", .4, "Amanhã 19:00"]],
    tennis: [["M. Valdez", "K. Ostrow", .62, "Hoje 14:00"], ["L. Brandt", "A. Nakamura", .48, "Hoje 16:30"], ["S. Moreau", "D. Quintana", .37, "Amanhã 11:00"]],
    volleyball: [["Ondas Azuis", "Serra Alta", .55, "Hoje 18:00"], ["Guardiões", "Fênix VC", .46, "Amanhã 17:00"], ["Costa Norte", "Ventania", .6, "Amanhã 20:00"]],
    mma: [["R. Salgado", "T. Kovac", .57, "Sábado 23:00"], ["J. Duarte", "B. Okoye", .44, "Sábado 23:40"], ["P. Lindqvist", "H. Moura", .66, "Sábado 00:15"]],
    boxing: [["A. Ferraz", "C. Whitlock", .52, "Sábado 22:00"], ["E. Montoya", "L. Dragan", .4, "Sábado 22:45"], ["V. Barreto", "N. Idowu", .63, "Domingo 21:00"]],
    esports: [["Vórtex Gaming", "Núcleo Z", .56, "Hoje 17:00"], ["Pulso Esports", "Quasar", .47, "Hoje 19:00"], ["Legião Neon", "Arcano", .38, "Amanhã 15:00"]]
  };
  var LINE = { football: 2.5, basketball: 215.5, tennis: 2.5, volleyball: 3.5, esports: 2.5 };
  var TOT_NAME = { football: "Total de gols", basketball: "Total de pontos", tennis: "Total de sets",
                   volleyball: "Total de sets", esports: "Total de mapas" };

  function od(p, m) { return Math.max(1.05, Math.round(100 / (Math.min(p, .97) * (1 + m))) / 100); }
  function fl(l) { return (l > 0 ? "+" : "−") + Math.abs(l).toFixed(1).replace(".", ","); }

  function buildMarkets(sp, h, a, s) {
    var m = .06, mk = [];
    function sel(id, label, p) { return { id: id, label: label, odds: od(p, m) }; }
    if (sp === "football") {
      var pD = .26, ph = (1 - pD) * s, pa = (1 - pD) * (1 - s);
      mk.push({ id: "x12", type: "x12", name: "Resultado final", sels: [sel("h", h, ph), sel("d", "Empate", pD), sel("a", a, pa)] });
      mk.push({ id: "dc", type: "dc", name: "Dupla possibilidade", sels: [sel("1x", h + " ou Empate", ph + pD), sel("12", h + " ou " + a, ph + pa), sel("x2", "Empate ou " + a, pD + pa)] });
      mk.push({ id: "tot", type: "tot", line: 2.5, name: "Total de gols", sels: [sel("o", "Mais de 2,5", .52), sel("u", "Menos de 2,5", .48)] });
      mk.push({ id: "btts", type: "btts", name: "Ambas as equipes marcam", sels: [sel("y", "Sim", .5), sel("n", "Não", .5)] });
      var ph2 = Math.max(.1, Math.min(.8, ph * .45));
      mk.push({ id: "hcp", type: "hcp", line: -1.5, name: "Handicap", sels: [sel("h", h + " (" + fl(-1.5) + ")", ph2), sel("a", a + " (" + fl(1.5) + ")", 1 - ph2)] });
    } else {
      mk.push({ id: "ml", type: "ml", name: "Vencedor", sels: [sel("h", h, s), sel("a", a, 1 - s)] });
      if (LINE[sp]) {
        var L = LINE[sp], po = sp === "basketball" ? .5 : (sp === "volleyball" ? .5 : .42);
        mk.push({ id: "tot", type: "tot", line: L, name: TOT_NAME[sp], sels: [sel("o", "Mais de " + L.toFixed(1).replace(".", ","), po), sel("u", "Menos de " + L.toFixed(1).replace(".", ","), 1 - po)] });
      }
      if (sp === "basketball") {
        var pc = Math.max(.15, Math.min(.85, s - .12));
        mk.push({ id: "hcp", type: "hcp", line: -4.5, name: "Handicap", sels: [sel("h", h + " (" + fl(-4.5) + ")", pc), sel("a", a + " (" + fl(4.5) + ")", 1 - pc)] });
      }
    }
    return mk;
  }

  function buildEvents() {
    var out = [], n = 0;
    SPORTS.forEach(function (sp) {
      TABLE[sp[0]].forEach(function (r) {
        n++;
        out.push({ id: "E" + (n < 10 ? "0" : "") + n, sport: sp[0], home: r[0], away: r[1], when: r[3],
                   status: "open", score: null, markets: buildMarkets(sp[0], r[0], r[1], r[2]) });
      });
    });
    return out;
  }

  // score = [casa, fora]. Retorna true se a seleção venceu.
  function settleSelection(mkt, selId, score) {
    var sh = score[0], sa = score[1];
    switch (mkt.type) {
      case "x12": return selId === "h" ? sh > sa : selId === "d" ? sh === sa : sh < sa;
      case "ml": return selId === "h" ? sh > sa : sh < sa;
      case "dc": return selId === "1x" ? sh >= sa : selId === "12" ? sh !== sa : sh <= sa;
      case "tot": return selId === "o" ? sh + sa > mkt.line : sh + sa < mkt.line;
      case "btts": return selId === "y" ? (sh > 0 && sa > 0) : !(sh > 0 && sa > 0);
      case "hcp": return selId === "h" ? sh + mkt.line > sa : !(sh + mkt.line > sa);
    }
    return false;
  }

  function simulate(ev) {
    var r = E.randomInt, m = ev.markets[0];
    var pr = E.normalizedProbabilities(m.sels.map(function (s) { return s.odds; }));
    var u = r(1000000) / 1000000, acc = 0, k = 0;
    for (; k < pr.length - 1; k++) { acc += pr[k]; if (u < acc) break; }
    var w = m.sels[k].id, h, a, sp = ev.sport;
    if (sp === "football") {
      h = r(4); a = r(4);
      if (w === "d") a = h; else if (w === "h" && h <= a) h = a + 1 + r(2); else if (w === "a" && a <= h) a = h + 1 + r(2);
    } else if (sp === "basketball") {
      h = 85 + r(30); a = 85 + r(30);
      if (w === "h" && h <= a) h = a + 1 + r(10); else if (w === "a" && a <= h) a = h + 1 + r(10);
    } else if (sp === "volleyball") {
      h = w === "h" ? 3 : r(3); a = w === "a" ? 3 : r(3);
    } else if (sp === "mma" || sp === "boxing") {
      h = w === "h" ? 1 : 0; a = w === "a" ? 1 : 0;
    } else { h = w === "h" ? 2 : r(2); a = w === "a" ? 2 : r(2); }
    return [h, a];
  }

  function create(opts) {
    var storage = opts.storage, st = storage.get("sports", null);
    if (!st || st.v !== 1) { st = { v: 1, events: buildEvents() }; storage.set("sports", st); }
    function save() { storage.set("sports", st); }
    function get(id) { return st.events.filter(function (e) { return e.id === id; })[0] || null; }
    return {
      SPORTS: SPORTS,
      list: function (sport) { return st.events.filter(function (e) { return !sport || sport === "all" || e.sport === sport; }); },
      get: get,
      setOdds: function (eid, mid, sid, odds) {
        var o = Number(odds), ev = get(eid);
        if (!ev || !isFinite(o) || o < 1.01 || o > 1000) return { ok: false, error: "Cotação inválida (1,01 a 1000)." };
        var m = ev.markets.filter(function (x) { return x.id === mid; })[0];
        var s = m && m.sels.filter(function (x) { return x.id === sid; })[0];
        if (!s) return { ok: false, error: "Seleção não encontrada." };
        s.odds = Math.round(o * 100) / 100; save();
        return { ok: true };
      },
      finish: function (eid, score) {
        var ev = get(eid);
        if (!ev) return { ok: false, error: "Evento não encontrado." };
        if (ev.status === "finished") return { ok: false, error: "Evento já encerrado." };
        if (!score || score.length !== 2 || score.some(function (x) { return !Number.isInteger(x) || x < 0 || x > 999; }))
          return { ok: false, error: "Placar inválido." };
        ev.status = "finished"; ev.score = score; save();
        return { ok: true, event: ev };
      },
      reopen: function (eid) {
        var ev = get(eid); if (!ev) return { ok: false, error: "Evento não encontrado." };
        ev.status = "open"; ev.score = null; save(); return { ok: true };
      },
      simulate: simulate,
      reset: function () { st = { v: 1, events: buildEvents() }; save(); }
    };
  }
  return { create: create, buildEvents: buildEvents, settleSelection: settleSelection, simulate: simulate, SPORTS: SPORTS };
});
