/*
 * TSGames — Perfil, preferências, Sobre e Créditos.
 * Uma criação de Thalisson Torricelli.
 */
(function (g) {
  var TS = g.TS, W = TS.wallet, ui = TS.ui, esc = TS.fmt.esc, brl = TS.brl;
  var AVATARS = ["◆", "★", "●", "▲", "■", "♦", "✦", "✚"];
  var THEME_NAMES = { esmeralda: "Esmeralda", ouro: "Ouro", cobalto: "Cobalto" };
  var THEME_UNLOCK = { esmeralda: 0, ouro: 5, cobalto: 20 }; // rodadas necessárias
  TS.parentTab.credits = "profile";
  TS.AVATARS = AVATARS;

  function row(a, b) { return '<div class="sumrow"><span>' + a + "</span><b>" + b + "</b></div>"; }
  TS.achievements = function () {
    var tk = TS.tickets.list();
    return TS.Stats.achievements({
      summary: TS.stats.summary(), tickets: tk.length,
      combined: tk.filter(function (t) { return t.mode === "combinada"; }).length,
      deposits: W.summary().deposits
    });
  };

  TS.pages.profile = function () {
    var pf = ui.prefs(), sm = TS.stats.summary(), ach = TS.achievements();
    var okCount = ach.filter(function (a) { return a.done; }).length;
    return "<h1>Perfil</h1>" +
      '<div class="card"><div class="row" style="align-items:center"><div class="av on" style="flex:none">' + AVATARS[pf.avatar] + "</div>" +
      '<input class="field" id="pname" maxlength="20" value="' + esc(pf.name) + '" placeholder="Seu nome"></div>' +
      '<div class="avatars" style="margin-top:12px">' + AVATARS.map(function (a, i) {
        return '<div class="av' + (pf.avatar === i ? " on" : "") + '" data-av="' + i + '">' + a + "</div>";
      }).join("") + "</div>" +
      '<button class="btn primary full" id="pnameSave">Salvar nome</button></div>' +
      "<h2>Estatísticas</h2><div class=\"card\">" +
      row("Rodadas e bilhetes", sm.rounds) + row("Vitórias", sm.wins + (sm.rounds ? " (" + ui.pct(sm.wins / sm.rounds) + ")" : "")) +
      row("Total apostado", brl(sm.staked)) + row("Total recebido", brl(sm.returned)) +
      row("Resultado", brl(sm.net)) + row("Maior ganho", brl(sm.best)) + "</div>" +
      '<div class="row"><button class="btn" data-go="statement">Extrato</button><button class="btn" data-go="tickets">Bilhetes</button></div>' +
      "<h2>Conquistas · " + okCount + "/" + ach.length + "</h2><div class=\"card\">" + ach.map(function (a) {
        return '<div class="ach' + (a.done ? " ok" : "") + '"><b>' + esc(a.name) + "</b><span>" + (a.done ? "Concluída" : "Em andamento") + "</span></div>";
      }).join("") + "</div>" +
      "<h2>Histórico de jogos</h2><div class=\"card hist\">" + ui.histRows(TS.stats.list(null, 8)) + "</div>" +
      "<h2>Preferências</h2><div class=\"card\">" +
      '<div class="toggle"><span>Sons</span><button class="btn" data-sound="1">' + (pf.sound ? "Ativado" : "Desativado") + "</button></div>" +
      '<div class="muted">Cor de destaque</div><div class="scroller" style="margin-top:8px">' + Object.keys(THEME_NAMES).map(function (k) {
        var open = sm.rounds >= THEME_UNLOCK[k];
        return '<div class="pill' + (pf.theme === k ? " on" : "") + '" data-theme="' + k + '">' + THEME_NAMES[k] + (open ? "" : " 🔒") + "</div>";
      }).join("") + "</div></div>" +
      "<h2>Configurações</h2><div class=\"card\">" +
      '<button class="btn full" data-go="adminlogin" style="margin-top:0">Painel administrativo local</button>' +
      '<button class="btn full" id="rstExp">Reiniciar experiência</button>' +
      '<button class="btn danger full" id="wipe">Apagar dados locais</button></div>' +
      "<h2>Sobre</h2><div class=\"card\"><b>Sobre a carteira</b>" +
      '<p class="muted" style="margin-top:6px;line-height:1.5">Os créditos da TSGames são virtuais e não têm valor monetário. ' +
      "Depósitos e saques são registros internos do aplicativo, guardados apenas neste aparelho. " +
      "Nenhuma transação financeira real é realizada.</p>" +
      '<button class="btn full" data-go="credits">Créditos</button></div>';
  };

  TS.pages.credits = function () {
    return ui.head("Créditos", "profile") +
      '<div class="card" style="text-align:center"><img src="assets/logo-horizontal.svg" alt="TSGames" style="width:220px;max-width:80%">' +
      '<p style="margin-top:14px;font-weight:600">TSGames — Uma criação de Thalisson Torricelli</p>' +
      '<img src="assets/signature-tt.svg" width="56" alt="TT" style="margin-top:12px">' +
      '<p class="muted" style="margin-top:12px">Versão ' + (TS.VERSION || "1.0.0") + "</p></div>" +
      '<div class="card"><p class="muted" style="line-height:1.6">Plataforma de entretenimento que funciona totalmente neste aparelho, sem internet. ' +
      "Eventos, equipes e partidas são inventados. Jogos, carteira e histórico são locais.</p></div>";
  };

  function arm(btn, label, fn) {
    if (btn.dataset.armed) { fn(); return; }
    var old = btn.textContent;
    btn.dataset.armed = "1"; btn.textContent = label;
    setTimeout(function () { if (btn.isConnected) { delete btn.dataset.armed; btn.textContent = old; } }, 4000);
  }

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-av],[data-sound],[data-theme],#pnameSave,#rstExp,#wipe");
    if (!t) return;
    if (t.hasAttribute("data-av")) { ui.setPref("avatar", Number(t.getAttribute("data-av"))); TS.refresh(); return; }
    if (t.hasAttribute("data-sound")) { ui.setPref("sound", !ui.prefs().sound); TS.refresh(); return; }
    if (t.hasAttribute("data-theme")) {
      var k = t.getAttribute("data-theme"), need = THEME_UNLOCK[k] || 0;
      if (TS.stats.summary().rounds < need) { TS.toast("Desbloqueie jogando " + need + " rodadas.", "err"); return; }
      ui.setPref("theme", k); ui.applyTheme(); TS.refresh(); return;
    }
    if (t.id === "pnameSave") {
      var n = ui.el("pname").value.trim().slice(0, 20);
      if (!n) { TS.toast("Informe um nome.", "err"); return; }
      ui.setPref("name", n); TS.toast("Nome salvo"); TS.refresh(); return;
    }
    if (t.id === "rstExp") {
      arm(t, "Toque novamente para confirmar", function () {
        W.reset(); TS.sports.reset(); TS.tickets.reset(); TS.stats.clear(); TS.store.set("deferred", []);
        TS.toast("Experiência reiniciada"); TS.go("home");
      });
      return;
    }
    if (t.id === "wipe") {
      arm(t, "Toque novamente para apagar tudo", function () {
        TS.store.clear(); W.reset(); TS.sports.reset(); TS.tickets.reset();
        g.location.reload();
      });
    }
  });
})(window);
