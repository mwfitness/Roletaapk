/*
 * TSGames — Telas de Esportes, Evento, Bilhete e Meus bilhetes.
 * Uma criação de Thalisson Torricelli.
 */
(function (g) {
  var TS = g.TS, SP = TS.sports, TK = TS.tickets, E = TS.engine, esc = TS.fmt.esc, brl = TS.brl, ui = TS.ui;
  var cur = { sport: "football", mode: "combined" };
  TS.parentTab.event = "sports"; TS.parentTab.slip = "sports"; TS.parentTab.tickets = "sports";
  function dec(n) { return Number(n).toFixed(2).replace(".", ","); }
  function sportName(id) { return SP.SPORTS.filter(function (s) { return s[0] === id; })[0][1]; }

  function oddBtn(ev, m, s, withLabel) {
    var on = TK.isSel(ev.id, m.id, s.id);
    return '<button class="od' + (on ? " on" : "") + '" data-sel="' + ev.id + "|" + m.id + "|" + s.id + '">' +
      "<small>" + esc(withLabel ? s.label : (s.id === "h" ? "Casa" : s.id === "d" ? "Empate" : s.id === "a" ? "Fora" : s.label)) + "</small><b>" + dec(s.odds) + "</b>" +
      (withLabel ? "<em>" + ui.pct(E.impliedProbability(s.odds)) + "</em>" : "") + "</button>";
  }
  function slipBar() {
    var n = TK.slip().length;
    if (!n) return "";
    var q = TK.quote(1, "combined");
    return '<div class="slipbar" data-go="slip"><span>Bilhete (' + n + ")</span><span>" + (n > 1 ? "Cotação " + dec(q.odds) : "") + " ›</span></div>";
  }

  TS.pages.sports = function (arg) {
    if (arg) cur.sport = arg;
    var evs = SP.list(cur.sport);
    return "<h1>Esportes</h1>" +
      '<div class="scroller">' + SP.SPORTS.map(function (s) {
        return '<div class="pill' + (cur.sport === s[0] ? " on" : "") + '" data-sport="' + s[0] + '">' + s[1] + "</div>";
      }).join("") + "</div>" +
      '<div class="row" style="margin:12px 0"><button class="btn" data-go="tickets">Meus bilhetes</button></div>' +
      evs.map(function (ev) {
        var m = ev.markets[0];
        return '<div class="ev"><div class="meta"><span>' + sportName(ev.sport) + " · " + esc(ev.when) + "</span><span>" +
          (ev.status === "finished" ? "Encerrado " + ev.score[0] + "–" + ev.score[1] : m.name) + "</span></div>" +
          '<div class="teams" data-go="event" data-arg="' + ev.id + '">' + esc(ev.home) + " x " + esc(ev.away) + " ›</div>" +
          (ev.status === "open" ? '<div class="odds c' + m.sels.length + '">' + m.sels.map(function (s) { return oddBtn(ev, m, s, false); }).join("") + "</div>"
                                : '<div class="muted">Mercados encerrados</div>') + "</div>";
      }).join("") + slipBar();
  };

  TS.pages.event = function (id) {
    var ev = SP.get(id);
    if (!ev) return "<h1>Evento</h1><div class=\"card muted\">Evento não encontrado.</div>";
    return ui.head(esc(ev.home) + " x " + esc(ev.away), "sports") +
      '<div class="muted" style="margin-bottom:12px">' + sportName(ev.sport) + " · " + esc(ev.when) +
      (ev.status === "finished" ? " · Encerrado " + ev.score[0] + "–" + ev.score[1] : "") + "</div>" +
      ev.markets.map(function (m) {
        var margin = E.margin(m.sels.map(function (s) { return s.odds; }));
        return '<div class="card mk"><h3>' + m.name + ' <span class="muted">· margem ' + ui.pct(margin) + "</span></h3>" +
          '<div class="odds c' + (m.sels.length === 3 ? 1 : m.sels.length) + '">' +
          m.sels.map(function (s) { return ev.status === "open" ? oddBtn(ev, m, s, true) : '<div class="od"><small>' + esc(s.label) + "</small><b>" + dec(s.odds) + "</b></div>"; }).join("") +
          "</div></div>";
      }).join("") +
      '<p class="muted" style="line-height:1.5">A probabilidade implícita (1 ÷ cotação) inclui a margem do mercado e não é a probabilidade real do evento.</p>' +
      slipBar();
  };

  TS.pages.slip = function () {
    var legs = TK.slip(), stakeDef = TS.store.get("slipstake", "10,00");
    if (!legs.length) return ui.head("Bilhete", "sports") + '<div class="card muted">Seu bilhete está vazio. Escolha cotações em Esportes.</div>';
    var multi = legs.length > 1;
    return ui.head("Bilhete", "sports") +
      '<div class="card">' + legs.map(function (l, i) {
        return '<div class="leg"><div><b>' + esc(l.label) + '</b><div class="muted">' + esc(l.market) + " · " + esc(l.match) + '</div></div><div><b>' + dec(l.odds) +
          '</b> <button data-rm="' + i + '" aria-label="Remover">✕</button></div></div>';
      }).join("") +
      (multi ? '<div class="seg"><button data-mode="combined" class="' + (cur.mode === "combined" ? "on" : "") + '">Combinada</button><button data-mode="single" class="' + (cur.mode === "single" ? "on" : "") + '">Simples</button></div>' : "") +
      ui.stake("slipStake", stakeDef) + '<div class="sum" id="slipSum"></div>' +
      '<button class="btn primary full" id="slipGo">Confirmar bilhete</button></div>' +
      ui.rules("<b>Combinada:</b> a cotação é o produto das cotações (seleções de eventos diferentes são tratadas como independentes). " +
        "<b>Simples:</b> o valor vale para cada seleção, gerando um bilhete por seleção. Só é possível uma seleção por evento, pois resultados do mesmo evento são dependentes.");
  };
  TS.pages.slip.after = function () { slipSum(); };
  function slipSum() {
    var box = ui.el("slipSum"); if (!box) return;
    var s = ui.readStake("slipStake");
    if (!(s > 0)) { box.innerHTML = '<div class="sumrow"><span>Informe um valor</span><b>—</b></div>'; return; }
    var q = TK.quote(s, cur.mode);
    function r(a, b) { return '<div class="sumrow"><span>' + a + "</span><b>" + b + "</b></div>"; }
    box.innerHTML = (q.odds ? r("Cotação", dec(q.odds)) : "") + r("Total apostado", brl(q.total)) +
      r("Retorno potencial", brl(q.potential)) + r("Lucro potencial", brl(Math.round((q.potential - q.total) * 100) / 100));
  }

  TS.pages.tickets = function () {
    var l = TK.list();
    return ui.head("Meus bilhetes", "sports") +
      (l.length ? l.map(function (t) {
        var open = t.status === "open", lbl = { open: "Em aberto", won: "Ganhou", lost: "Perdeu" }[t.status];
        return '<div class="card"><div class="row" style="justify-content:space-between"><b>' + t.id + " · " + t.mode + '</b><span class="badge st-' + t.status + '">' + lbl + "</span></div>" +
          t.legs.map(function (x) {
            return '<div class="leg"><div>' + esc(x.label) + '<div class="muted">' + esc(x.match) + " · " + esc(x.market) + '</div></div><div>' + dec(x.odds) +
              (x.result ? ' <span class="muted">' + (x.result === "won" ? "✓" : "✗") + "</span>" : "") + "</div></div>";
          }).join("") +
          '<div class="sumrow"><span>Valor · Cotação</span><b>' + brl(t.stake) + " · " + dec(t.odds) + "</b></div>" +
          '<div class="sumrow"><span>' + (open ? "Retorno potencial" : "Pagamento") + "</span><b>" + brl(open ? E.potentialReturn(t.stake, t.odds) : t.payout) + "</b></div>" +
          (open ? '<button class="btn full" data-simt="' + t.id + '">Simular resultados</button>' : "") + "</div>";
      }).join("") : '<div class="card muted">Você ainda não tem bilhetes.</div>');
  };

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-sel],[data-sport],[data-rm],[data-mode],#slipGo,[data-simt]");
    if (!t) return;
    if (t.hasAttribute("data-sel")) {
      var p = t.getAttribute("data-sel").split("|"), r = TK.toggle(p[0], p[1], p[2]);
      if (!r.ok) TS.toast(r.error, "err"); else ui.sfx("click");
      TS.refresh(); return;
    }
    if (t.hasAttribute("data-sport")) { cur.sport = t.getAttribute("data-sport"); TS.go("sports", cur.sport, { keep: true }); return; }
    if (t.hasAttribute("data-rm")) { TK.remove(Number(t.getAttribute("data-rm"))); TS.refresh(); return; }
    if (t.hasAttribute("data-mode")) { cur.mode = t.getAttribute("data-mode"); TS.refresh(); return; }
    if (t.id === "slipGo") {
      var s = ui.readStake("slipStake");
      TS.store.set("slipstake", ui.el("slipStake").value);
      var key = TS.slipKey = TS.slipKey || ("slip-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7));
      t.disabled = true;
      var res = TK.place(s, cur.mode, key);
      if (!res.ok) { TS.toast(res.error, "err"); t.disabled = false; return; }
      TS.slipKey = null;
      TS.toast(res.tickets.length > 1 ? "Bilhetes confirmados" : "Bilhete confirmado");
      TS.go("tickets"); return;
    }
    if (t.hasAttribute("data-simt")) {
      var tk = TK.list().filter(function (x) { return x.id === t.getAttribute("data-simt"); })[0];
      if (!tk) return;
      var n = 0;
      tk.legs.forEach(function (l) {
        var ev = SP.get(l.eventId);
        if (ev && ev.status === "open") { var rr = TK.finishEvent(ev.id, SP.simulate(ev)); if (rr.ok) n += rr.settled; }
      });
      TS.toast("Resultados simulados"); TS.refresh();
    }
  });
  document.addEventListener("input", function (e) { if (e.target.id === "slipStake") slipSum(); });
})(window);
