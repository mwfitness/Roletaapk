import os, json
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH","/opt/pw-browsers")
from playwright.sync_api import sync_playwright
ROOT="file://"+os.path.abspath(os.path.join(os.path.dirname(__file__),"..","..","app/src/main/assets/www/index.html"))
errors=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":390,"height":780})
    pg.on("pageerror", lambda e: errors.append("pageerror: "+str(e)))
    pg.on("console", lambda m: errors.append("console."+m.type+": "+m.text) if m.type in("error","warning") else None)
    pg.goto(ROOT); pg.wait_for_timeout(2200)
    print("welcome visible:", pg.locator("#welcome:not(.hide)").count())
    pg.click("#welcomeOk")
    print("header:", pg.inner_text("#hdrBalance"))
    tabs=pg.locator("#nav button")
    print("tabs:", [tabs.nth(i).inner_text().strip() for i in range(tabs.count())])
    for i in range(tabs.count()):
        tabs.nth(i).click(); pg.wait_for_timeout(250)
        print("tab",i,"->", pg.inner_text("#view h1")[:40] if pg.locator("#view h1").count() else "(sem h1)")
    pg.screenshot(path="/tmp/e2e/profile.png")
    print("ERRORS:", errors)
    b.close()
