/* TSGames — Plinko (8 fileiras). Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic.plinko, ui = TS.ui, brl = TS.brl;
  var level = "medium", busy = false, settle = null, raf = 0;
  var W = 300, H = 280, SP = 30, CX = 150, TOP = 24, DY = 28;
  function pos(k, sum) { return { x: CX + (sum - k / 2) * SP, y: TOP + k * DY }; }
  function drawBoard(ball) {
    var cv = ui.el("plk"); if (!cv) return;
    var c = cv.getContext("2d"); c.clearRect(0, 0, W, H);
    c.fillStyle = "#8B8D93";
    for (var k = 0; k < 8; k++) for (var j = 0; j <= k; j++) { var p = pos(k, j); c.beginPath(); c.arc(p.x, p.y, 3, 0, 6.3); c.fill(); }
    if (ball) { c.fillStyle = "#C9A24B"; c.beginPath(); c.arc(ball.x, ball.y - 9, 7, 0, 6.3); c.fill(); }
  }
  function bins(hit) {
    return L.MULT[level].map(function (m, i) { return '<div class="bin' + (hit === i ? " hit" : "") + '">' + String(m).replace(".", ",") + "×</div>"; }).join("");
  }
  TS.pages.plinko = function () {
    busy = false; settle = null; cancelAnimationFrame(raf);
    TS.onLeave = function () { cancelAnimationFrame(raf); if (settle) settle(); };
    return ui.head("Plinko", "casino") +
      '<canvas class="plk" id="plk" width="' + W + '" height="' + H + '"></canvas><div class="bins" id="pbins">' + bins(-1) + "</div>" +
      '<div class="say" id="psay">Escolha o risco e solte a bolinha</div>' +
      '<div class="scroller">' + [["low", "Baixo"], ["medium", "Médio"], ["high", "Alto"]].map(function (l) {
        return '<div class="pill' + (level === l[0] ? " on" : "") + '" data-plv="' + l[0] + '">' + l[1] + "</div>";
      }).join("") + "</div>" + ui.stake("pstake", "5,00") +
      '<button class="btn primary full" id="pgo">Soltar</button>' +
      ui.rules("A bolinha passa por 8 fileiras de pinos e, em cada uma, desvia para a esquerda ou direita com 50% de chance. O compartimento final segue a distribuição binomial (1, 8, 28, 56, 70, 56, 28, 8, 1 em 256)." +
        "<table><tr><th>Nível</th><th>Retorno teórico</th></tr>" + ["low", "medium", "high"].map(function (l) { return "<tr><td>" + l + "</td><td>" + ui.pct(L.rtp(l)) + "</td></tr>"; }).join("") + "</table>" +
        "Níveis mais altos têm prêmios maiores nas pontas e menores no centro, com a mesma expectativa.") + ui.hist("plinko");
  };
  TS.pages.plinko.after = function () { drawBoard(null); };
  document.addEventListener("click", function (e) {
    if (TS.current !== "plinko") return;
    var lv = e.target.closest("[data-plv]");
    if (lv) { if (busy) return; level = lv.getAttribute("data-plv"); TS.refresh(); return; }
    if (!e.target.closest("#pgo") || busy) return;
    var bet = ui.bet("pstake", "Cassino · Plinko"); if (!bet) return;
    var d = L.drop(), mult = L.MULT[level][d.bin], lvl = level, done = false;
    busy = true; ui.say("psay", "Caindo…", "info");
    var t0 = performance.now(), per = 260;
    function frame(now) {
      var t = (now - t0) / per, k = Math.min(7, Math.floor(t)), f = t - k;
      var sum = d.path.slice(0, k).reduce(function (a, b) { return a + b; }, 0);
      var a = pos(k, sum), b = pos(k + 1, sum + d.path[k]);
      if (t >= 8) { drawBoard(pos(8, d.bin)); if (settle) settle(); return; }
      drawBoard({ x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f });
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);
    settle = function () {
      if (done) return; done = true; settle = null; busy = false; cancelAnimationFrame(raf);
      var p = ui.finish("plinko", bet, bet.stake * mult, ui.x(mult) + " (" + lvl + ") · " + brl(bet.stake));
      if (TS.current === "plinko") {
        drawBoard(pos(8, d.bin)); ui.el("pbins").innerHTML = bins(d.bin);
        ui.say("psay", ui.x(mult) + " · Retorno " + brl(p), mult > 1 ? "win" : "lose"); ui.refreshHist("plinko");
      }
    };
  });
})(window);
