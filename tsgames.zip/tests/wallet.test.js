"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { create, parseBRL } = require("../app/src/main/assets/www/js/wallet.js");

function mk(storage) {
  let t = 1000000;
  const w = create({ now: () => t, storage });
  w.advance = (ms) => { t += ms; };
  return w;
}
const near = (a, b) => assert.ok(Math.abs(a - b) < 0.005, `${a} != ${b}`);
const healthy = (w) => assert.deepEqual(w.check(), { ok: true, errors: [] });

test("parseBRL aceita formatos brasileiros e rejeita inválidos", () => {
  assert.equal(parseBRL("1.250,50"), 1250.5);
  assert.equal(parseBRL("R$ 100"), 100);
  assert.equal(parseBRL("1.250"), 1250);
  assert.equal(parseBRL("12.5"), 12.5);
  assert.equal(parseBRL(7.25), 7.25);
  ["", "abc", "-5", "1,2,3", "R$"].forEach((v) => assert.ok(Number.isNaN(parseBRL(v)), v));
});

test("estado inicial: R$ 1.250,00 disponíveis e consistente", () => {
  const w = mk();
  const s = w.summary();
  assert.equal(s.available, 1250);
  assert.equal(s.reserved, 0);
  assert.equal(s.total, 1250);
  assert.equal(s.deposits, 0);
  assert.equal(s.withdrawals, 0);
  assert.equal(w.list().length, 1);
  healthy(w);
});

test("depósito válido atualiza saldo, extrato e acumulado", () => {
  const w = mk();
  const r = w.deposit(100);
  assert.ok(r.ok);
  const s = w.summary();
  assert.equal(s.available, 1350);
  assert.equal(s.deposits, 100);
  const e = w.list()[0];
  assert.equal(e.id, r.id);
  assert.equal(e.before, 1250);
  assert.equal(e.after, 1350);
  assert.equal(e.status, "completed");
  assert.equal(e.category, "deposit");
  healthy(w);
});

test("depósito aceita texto em formato brasileiro", () => {
  const w = mk();
  assert.ok(w.deposit("1.000,50").ok);
  assert.equal(w.summary().available, 2250.5);
});

test("depósito rejeita valores inválidos e fora dos limites", () => {
  const w = mk();
  [undefined, null, "", "abc", -5, 0, 5, 10001].forEach((v) => {
    const r = w.deposit(v);
    assert.equal(r.ok, false, String(v));
    assert.ok(r.error);
  });
  assert.equal(w.summary().available, 1250);
  assert.equal(w.list().length, 1);
  healthy(w);
});

test("toque repetido (mesma chave) não duplica operações", () => {
  const w = mk();
  const a = w.deposit(50, { key: "k1" });
  const b = w.deposit(50, { key: "k1" });
  assert.ok(a.ok && b.ok);
  assert.equal(b.duplicate, true);
  assert.equal(b.id, a.id);
  assert.equal(w.summary().available, 1300);
  const s1 = w.requestWithdraw(100, { key: "k2" });
  const s2 = w.requestWithdraw(100, { key: "k2" });
  assert.equal(s2.duplicate, true);
  assert.equal(w.summary().reserved, 100);
  healthy(w);
});

test("saque reserva o valor e fica em análise", () => {
  const w = mk();
  const r = w.requestWithdraw(200);
  assert.ok(r.ok);
  const s = w.summary();
  assert.equal(s.available, 1050);
  assert.equal(s.reserved, 200);
  assert.equal(s.total, 1250);
  assert.equal(s.withdrawals, 0);
  assert.equal(w.pendingWithdrawals().length, 1);
  assert.equal(w.pendingWithdrawals()[0].status, "review");
  healthy(w);
});

test("saque aprovado libera a reserva e soma ao acumulado", () => {
  const w = mk();
  const r = w.requestWithdraw(200);
  assert.ok(w.resolveWithdrawal(r.id, "approved").ok);
  const s = w.summary();
  assert.equal(s.available, 1050);
  assert.equal(s.reserved, 0);
  assert.equal(s.total, 1050);
  assert.equal(s.withdrawals, 200);
  assert.equal(w.list({ category: "withdraw" }).find((e) => e.id === r.id).status, "approved");
  healthy(w);
});

test("saque cancelado ou recusado devolve o valor com estorno", () => {
  ["cancelled", "rejected"].forEach((outcome) => {
    const w = mk();
    const r = w.requestWithdraw(300);
    assert.ok(w.resolveWithdrawal(r.id, outcome).ok);
    const s = w.summary();
    assert.equal(s.available, 1250);
    assert.equal(s.reserved, 0);
    assert.equal(s.withdrawals, 0);
    const rows = w.list({ category: "withdraw" });
    assert.equal(rows.length, 2);
    assert.equal(rows[0].type, "Estorno de saque");
    assert.equal(rows[0].amount, 300);
    assert.equal(rows[1].status, outcome);
    healthy(w);
  });
});

test("transições de status inválidas são bloqueadas", () => {
  const w = mk();
  const r = w.requestWithdraw(100);
  assert.equal(w.resolveWithdrawal(r.id, "paid").ok, false);
  assert.ok(w.resolveWithdrawal(r.id, "approved").ok);
  assert.equal(w.resolveWithdrawal(r.id, "cancelled").ok, false);
  assert.equal(w.resolveWithdrawal("TSG-999999", "approved").ok, false);
  assert.equal(w.summary().available, 1150);
  healthy(w);
});

test("saque rejeita valor acima do saldo, fora dos limites e inválido", () => {
  const w = mk();
  assert.equal(w.requestWithdraw(5000).ok, false);   // acima do saldo
  assert.equal(w.requestWithdraw(10).ok, false);     // abaixo do mínimo (R$ 20)
  assert.equal(w.requestWithdraw("x").ok, false);
  assert.equal(w.requestWithdraw(-30).ok, false);
  assert.equal(w.summary().available, 1250);
  healthy(w);
});

test("não é possível sacar duas vezes o mesmo saldo", () => {
  const w = mk();
  assert.ok(w.requestWithdraw(1000).ok);
  assert.equal(w.requestWithdraw(1000).ok, false);
  healthy(w);
});

test("aprovação automática depois do tempo configurado", () => {
  const w = mk();
  const r = w.requestWithdraw(100);
  w.advance(5000);
  assert.equal(w.processPending(), 0);
  w.advance(20000);
  assert.equal(w.processPending(), 1);
  assert.equal(w.summary().withdrawals, 100);
  assert.equal(w.summary().reserved, 0);
  assert.equal(w.processPending(), 0);
  w.setSettings({ autoApproveMs: 0 });
  w.requestWithdraw(50);
  w.advance(999999);
  assert.equal(w.processPending(), 0);
  void r;
  healthy(w);
});

test("aposta reserva o valor; vitória paga o prêmio", () => {
  const w = mk();
  const b = w.placeBet(100, { desc: "Roleta" });
  assert.ok(b.ok);
  assert.equal(w.summary().available, 1150);
  assert.equal(w.summary().reserved, 100);
  const s = w.settleBet(b.id, 250);
  assert.ok(s.ok);
  assert.equal(s.status, "won");
  const r = w.summary();
  assert.equal(r.available, 1400);
  assert.equal(r.reserved, 0);
  assert.equal(r.gameResult, 150);
  assert.equal(w.list({ category: "prize" }).length, 1);
  healthy(w);
});

test("aposta perdida e aposta devolvida", () => {
  const w = mk();
  const a = w.placeBet(100);
  assert.equal(w.settleBet(a.id, 0).status, "lost");
  assert.equal(w.summary().gameResult, -100);
  const b = w.placeBet(50);
  assert.equal(w.settleBet(b.id, 50).status, "refunded");
  assert.equal(w.summary().gameResult, -100);
  assert.equal(w.summary().available, 1150);
  healthy(w);
});

test("aposta não pode ser liquidada duas vezes nem exceder o saldo", () => {
  const w = mk();
  const b = w.placeBet(100);
  assert.ok(w.settleBet(b.id, 200).ok);
  assert.equal(w.settleBet(b.id, 200).ok, false);
  assert.equal(w.placeBet(99999).ok, false);
  assert.equal(w.settleBet("TSG-000999", 1).ok, false);
  healthy(w);
});

test("playRound registra aposta e prêmio de forma atômica", () => {
  const w = mk();
  const r = w.playRound(100, 0, { desc: "Crash", key: "r1" });
  assert.ok(r.ok);
  assert.equal(r.status, "lost");
  assert.equal(w.playRound(100, 0, { key: "r1" }).duplicate, true);
  assert.equal(w.summary().available, 1150);
  assert.equal(w.playRound(100, -5).ok, false);
  assert.equal(w.playRound(100000, 0).ok, false);
  assert.equal(w.list({ category: "bet" }).length, 1);
  healthy(w);
});

test("ajuste administrativo não deixa o saldo negativo", () => {
  const w = mk();
  assert.ok(w.adjust(50, "Teste").ok);
  assert.equal(w.summary().available, 1300);
  assert.equal(w.adjust(-5000).ok, false);
  assert.equal(w.adjust(0).ok, false);
  assert.ok(w.adjust(-300).ok);
  assert.equal(w.summary().available, 1000);
  healthy(w);
});

test("configurações: limites em reais e validação", () => {
  const w = mk();
  assert.ok(w.setSettings({ minDeposit: 50, maxDeposit: 500 }).ok);
  assert.equal(w.deposit(20).ok, false);
  assert.ok(w.deposit(60).ok);
  assert.equal(w.deposit(600).ok, false);
  assert.equal(w.setSettings({ minDeposit: 900 }).ok, false);
  assert.equal(w.getSettings().minDeposit, 50);
});

test("filtros, ordenação e CSV do extrato", () => {
  const w = mk();
  w.deposit(100);
  w.advance(1000);
  w.requestWithdraw(50);
  w.playRound(10, 30, { desc: 'Jogo "teste"' });
  assert.equal(w.list({ category: "deposit" }).length, 1);
  assert.equal(w.list({ category: "withdraw" }).length, 1);
  assert.equal(w.list({ category: "prize" }).length, 1);
  assert.equal(w.list({ category: "all" }).length, w.list().length);
  const desc = w.list({ order: "desc" }), asc = w.list({ order: "asc" });
  assert.equal(desc[0].id, asc[asc.length - 1].id);
  assert.equal(w.list({ limit: 2 }).length, 2);
  const csv = w.toCSV(asc);
  const lines = csv.split("\n");
  assert.equal(lines[0], "id;data;tipo;categoria;descricao;valor;saldo_anterior;saldo_posterior;status");
  assert.equal(lines.length, asc.length + 1);
  assert.ok(csv.includes('"Jogo ""teste"""'));
  assert.ok(csv.includes("100,00"));
});

test("dados persistem entre instâncias", () => {
  const shared = {};
  const storage = {
    get: (k, d) => (k in shared ? JSON.parse(JSON.stringify(shared[k])) : d),
    set: (k, v) => { shared[k] = JSON.parse(JSON.stringify(v)); return true; }
  };
  const a = mk(storage);
  a.deposit(100);
  a.requestWithdraw(40);
  const b = mk(storage);
  assert.deepEqual(b.summary(), a.summary());
  assert.equal(b.list().length, a.list().length);
  healthy(b);
  assert.ok(b.deposit(10).ok);
  assert.notEqual(b.list()[0].id, a.list()[0].id);
});

test("ouvintes são avisados a cada operação e podem ser removidos", () => {
  const w = mk();
  let n = 0;
  const off = w.on(() => { n++; });
  w.deposit(20);
  w.requestWithdraw(30);
  assert.equal(n, 2);
  w.deposit(-1);
  assert.equal(n, 2);
  off();
  w.deposit(20);
  assert.equal(n, 2);
});

test("reset restaura o estado inicial", () => {
  const w = mk();
  w.deposit(500);
  w.requestWithdraw(100);
  w.reset();
  const s = w.summary();
  assert.equal(s.available, 1250);
  assert.equal(s.reserved, 0);
  assert.equal(s.deposits, 0);
  assert.equal(w.list().length, 1);
  healthy(w);
});

test("identificadores são únicos", () => {
  const w = mk();
  for (let i = 0; i < 30; i++) w.deposit(10);
  const ids = w.list().map((e) => e.id);
  assert.equal(new Set(ids).size, ids.length);
});

test("sequência aleatória longa mantém a carteira consistente", () => {
  const w = mk();
  let seed = 12345;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
  const amount = () => Math.round((1 + rnd() * 300) * 100) / 100;
  const openBets = [], openWd = [];
  for (let i = 0; i < 600; i++) {
    const k = Math.floor(rnd() * 7);
    if (k === 0) w.deposit(amount());
    else if (k === 1) { const r = w.requestWithdraw(amount()); if (r.ok) openWd.push(r.id); }
    else if (k === 2 && openWd.length) {
      w.resolveWithdrawal(openWd.splice(Math.floor(rnd() * openWd.length), 1)[0],
        ["approved", "rejected", "cancelled"][Math.floor(rnd() * 3)]);
    }
    else if (k === 3) { const r = w.placeBet(amount()); if (r.ok) openBets.push(r.id); }
    else if (k === 4 && openBets.length) {
      w.settleBet(openBets.splice(Math.floor(rnd() * openBets.length), 1)[0], rnd() < 0.5 ? 0 : amount() * 2);
    }
    else if (k === 5) w.playRound(amount(), rnd() < 0.5 ? 0 : amount());
    else if (k === 6) w.adjust(rnd() < 0.5 ? amount() : -amount());
    healthy(w);
  }
  openBets.forEach((id) => w.settleBet(id, 0));
  openWd.forEach((id) => w.resolveWithdrawal(id, "approved"));
  healthy(w);
  const s = w.summary();
  assert.equal(s.reserved, 0);
  const adjusts = w.list({ category: "adjust" }).reduce((a, e) => a + e.amount, 0);
  near(s.total, s.deposits - s.withdrawals + s.gameResult + adjusts);
});
