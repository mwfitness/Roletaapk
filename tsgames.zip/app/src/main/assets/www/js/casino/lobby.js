/* TSGames — Lobby do Cassino. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS;
  ["roulette", "blackjack", "slots", "crash", "plinko", "dice"].forEach(function (k) { TS.parentTab[k] = "casino"; });
  TS.GAMES = [
    ["roulette", "Roleta", "Europeia · 37 números"], ["blackjack", "Blackjack", "21 contra o dealer"],
    ["slots", "Caça-níqueis", "3 rolos"], ["crash", "Crash", "Saque antes da queda"],
    ["plinko", "Plinko", "3 níveis de risco"], ["dice", "Dados", "Soma de 2 dados"]
  ];
  TS.pages.casino = function () {
    return "<h1>Cassino</h1><div class=\"grid\">" + TS.GAMES.map(function (c) {
      return '<div class="tile" data-go="' + c[0] + '"><b>' + c[1] + "</b><span>" + c[2] + "</span></div>";
    }).join("") + "</div>";
  };
})(window);
