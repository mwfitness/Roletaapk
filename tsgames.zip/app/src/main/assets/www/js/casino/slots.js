/* TSGames — Caça-níqueis. Uma criação de Thalisson Torricelli. */
(function (g) {
  var TS = g.TS, L = TS.logic.slots, ui = TS.ui, brl = TS.brl;
  var busy = false, settle = null, timers = [];
  function clear() { timers.forEach(clearInterval); timers = []; }
  TS.pages.slots = function () {
    busy = false; settle = null; clear();
    TS.onLeave = function () { clear(); if (settle) settle(); };
    var st = L.stats(), sm = TS.stats.summary(), n = TS.stats.list("slots").length;
    var obs = TS.stats.list("slots").filter(function (x) { return x.payout > 0; }).length;
    return ui.head("Caça-níqueis", "casino") +
      '<div class="reels">' + [0, 1, 2].map(function (i) { return '<div class="reel" id="rl' + i + '">' + L.SYM[i].s + "</div>"; }).join("") + "</div>" +
      '<div class="say" id="ssay">Gire os rolos</div>' + ui.stake("sstake", "5,00") +
      '<button class="btn primary full" id="sgo">Girar</button>' +
      ui.rules("Três rolos com símbolos ponderados (os mais valiosos são os mais raros). Três símbolos iguais pagam o valor da tabela; dois ◆ nos dois primeiros rolos pagam 2×." +
        "<table><tr><th>Símbolo</th><th>Peso</th><th>3 iguais</th></tr>" + L.SYM.map(function (s) { return "<tr><td>" + s.s + "</td><td>" + s.w + "</td><td>" + s.p3 + "×</td></tr>"; }).join("") +
        "<tr><td>◆ ◆ ✕</td><td>—</td><td>2×</td></tr></table>" +
        "Retorno teórico: " + ui.pct(st.rtp) + " · Frequência teórica de prêmio: " + ui.pct(st.hitFrequency) +
        "<br>Frequência observada neste aparelho: " + (n ? ui.pct(obs / n) + " (" + n + " rodadas)" : "ainda sem rodadas") +
        ". A frequência observada varia e só se aproxima da teórica com muitas rodadas.") + ui.hist("slots");
  };
  document.addEventListener("click", function (e) {
    if (!e.target.closest("#sgo") || TS.current !== "slots" || busy) return;
    var bet = ui.bet("sstake", "Cassino · Caça-níqueis"); if (!bet) return;
    var res = L.spin(), mult = L.mult(res), done = false;
    busy = true; ui.say("ssay", "Girando…", "info");
    var stopped = [false, false, false];
    [0, 1, 2].forEach(function (i) {
      ui.el("rl" + i).classList.add("spin");
      timers.push(setInterval(function () {
        if (!stopped[i]) ui.el("rl" + i) && (ui.el("rl" + i).textContent = L.SYM[Math.floor(Math.random() * L.SYM.length)].s);
      }, 70));
      setTimeout(function () {
        stopped[i] = true;
        var el = ui.el("rl" + i); if (el) { el.textContent = L.SYM[res[i]].s; el.classList.remove("spin"); }
        ui.sfx("tick");
      }, 700 + i * 450);
    });
    settle = function () {
      if (done) return; done = true; settle = null; busy = false; clear();
      var p = ui.finish("slots", bet, bet.stake * mult, L.SYM[res[0]].s + L.SYM[res[1]].s + L.SYM[res[2]].s + " · " + brl(bet.stake));
      if (TS.current === "slots") {
        [0, 1, 2].forEach(function (i) { var el = ui.el("rl" + i); if (el) { el.textContent = L.SYM[res[i]].s; el.classList.remove("spin"); } });
        ui.say("ssay", mult ? "Prêmio " + ui.x(mult) + " · " + brl(p) : "Sem prêmio desta vez", mult ? "win" : "lose");
        ui.refreshHist("slots");
      }
    };
    setTimeout(function () { if (settle) settle(); }, 2300);
  });
})(window);
