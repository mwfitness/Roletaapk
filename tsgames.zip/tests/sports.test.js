"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const W = require("../app/src/main/assets/www/js/wallet.js");
const Sports = require("../app/src/main/assets/www/js/sports.js");
const Tickets = require("../app/src/main/assets/www/js/tickets.js");
const Stats = require("../app/src/main/assets/www/js/statistics.js");
const E = require("../app/src/main/assets/www/js/engine.js");

function mem() {
  const m = {};
  return { get: (k, d) => (k in m ? JSON.parse(JSON.stringify(m[k])) : d), set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); return true; } };
}
function setup() {
  const storage = mem(), wallet = W.create({ storage: mem() });
  const sports = Sports.create({ storage }), stats = Stats.create({ storage });
  const tickets = Tickets.create({ storage, wallet, sports, stats });
  return { storage, wallet, sports, stats, tickets };
}

test("esportes: 7 modalidades com 3 eventos, mercados e cotações válidas", () => {
  const s = setup().sports;
  assert.equal(s.SPORTS.length, 7);
  s.SPORTS.forEach(([id]) => assert.equal(s.list(id).length, 3, id));
  s.list().forEach((ev) => {
    assert.ok(ev.markets.length >= 1);
    ev.markets.forEach((m) => m.sels.forEach((x) => assert.ok(x.odds > 1)));
  });
  const ids = s.list().map((e) => e.id);
  assert.equal(new Set(ids).size, ids.length);
});

test("esportes: mercado de futebol tem margem positiva e probabilidades normalizadas", () => {
  const ev = setup().sports.list("football")[0];
  const odds = ev.markets[0].sels.map((x) => x.odds);
  assert.ok(E.margin(odds) > 0 && E.margin(odds) < 0.15);
  const n = E.normalizedProbabilities(odds);
  assert.ok(Math.abs(n.reduce((a, b) => a + b) - 1) < 1e-9);
});

test("liquidação das seleções por placar", () => {
  const S = Sports.settleSelection;
  const m = (type, line) => ({ type, line });
  assert.equal(S(m("x12"), "h", [2, 1]), true);
  assert.equal(S(m("x12"), "d", [1, 1]), true);
  assert.equal(S(m("x12"), "a", [2, 1]), false);
  assert.equal(S(m("ml"), "a", [0, 1]), true);
  assert.equal(S(m("dc"), "1x", [1, 1]), true);
  assert.equal(S(m("dc"), "12", [1, 1]), false);
  assert.equal(S(m("dc"), "x2", [0, 2]), true);
  assert.equal(S(m("tot", 2.5), "o", [2, 1]), true);
  assert.equal(S(m("tot", 2.5), "u", [1, 1]), true);
  assert.equal(S(m("btts"), "y", [1, 1]), true);
  assert.equal(S(m("btts"), "n", [2, 0]), true);
  assert.equal(S(m("hcp", -1.5), "h", [3, 1]), true);
  assert.equal(S(m("hcp", -1.5), "h", [2, 1]), false);
  assert.equal(S(m("hcp", -1.5), "a", [2, 1]), true);
});

test("simulação de placar respeita o formato de cada modalidade", () => {
  const s = setup().sports;
  for (let i = 0; i < 200; i++) s.list().forEach((ev) => {
    const [h, a] = Sports.simulate(ev);
    assert.ok(Number.isInteger(h) && Number.isInteger(a) && h >= 0 && a >= 0);
    if (ev.sport === "mma" || ev.sport === "boxing") assert.equal(h + a, 1);
    if (ev.sport === "tennis" || ev.sport === "esports") assert.ok(Math.max(h, a) === 2 && Math.min(h, a) <= 1);
    if (ev.sport === "volleyball") assert.ok(Math.max(h, a) === 3 && Math.min(h, a) <= 2);
  });
});

test("administração: alterar cotação e validar", () => {
  const { sports } = setup();
  const ev = sports.list("tennis")[0];
  assert.ok(sports.setOdds(ev.id, "ml", "h", 1.77).ok);
  assert.equal(sports.get(ev.id).markets[0].sels[0].odds, 1.77);
  assert.equal(sports.setOdds(ev.id, "ml", "h", 1).ok, false);
  assert.equal(sports.setOdds(ev.id, "zz", "h", 2).ok, false);
  assert.equal(sports.setOdds("E99", "ml", "h", 2).ok, false);
});

test("bilhete: uma seleção por evento, alternar e remover", () => {
  const { tickets, sports } = setup();
  const [e1, e2] = sports.list("football");
  assert.ok(tickets.toggle(e1.id, "x12", "h").ok);
  assert.equal(tickets.slip().length, 1);
  tickets.toggle(e1.id, "tot", "o");               // mesmo evento: substitui
  assert.equal(tickets.slip().length, 1);
  assert.equal(tickets.slip()[0].marketId, "tot");
  tickets.toggle(e1.id, "tot", "o");               // mesma seleção: remove
  assert.equal(tickets.slip().length, 0);
  tickets.toggle(e1.id, "x12", "h"); tickets.toggle(e2.id, "x12", "a");
  assert.equal(tickets.slip().length, 2);
  tickets.remove(0);
  assert.equal(tickets.slip().length, 1);
});

test("bilhete: cotação combinada e retorno potencial", () => {
  const { tickets, sports } = setup();
  const [e1, e2] = sports.list("basketball");
  tickets.toggle(e1.id, "ml", "h"); tickets.toggle(e2.id, "ml", "a");
  const o1 = tickets.slip()[0].odds, o2 = tickets.slip()[1].odds;
  const qc = tickets.quote(10, "combined");
  assert.equal(qc.odds, E.round2(o1 * o2));
  assert.equal(qc.total, 10);
  assert.equal(qc.potential, E.potentialReturn(10, E.round2(o1 * o2)));
  const qs = tickets.quote(10, "single");
  assert.equal(qs.total, 20);
  assert.equal(qs.potential, E.round2(10 * o1 + 10 * o2));
});

test("bilhete combinado: reserva, vitória e pagamento na carteira", () => {
  const { tickets, sports, wallet } = setup();
  const [e1, e2] = sports.list("football");
  tickets.toggle(e1.id, "x12", "h"); tickets.toggle(e2.id, "tot", "o");
  const r = tickets.place(100, "combined", "k1");
  assert.ok(r.ok && r.tickets.length === 1);
  const t = r.tickets[0];
  assert.equal(wallet.summary().available, 1150);
  assert.equal(wallet.summary().reserved, 100);
  assert.equal(tickets.slip().length, 0);
  assert.equal(tickets.finishEvent(e1.id, [2, 0]).settled, 0);   // falta o segundo evento
  assert.equal(tickets.list("open").length, 1);
  assert.equal(tickets.finishEvent(e2.id, [2, 1]).settled, 1);
  const done = tickets.list()[0];
  assert.equal(done.status, "won");
  assert.equal(done.payout, E.potentialReturn(100, t.odds));
  assert.equal(wallet.summary().reserved, 0);
  assert.equal(wallet.summary().available, 1150 + done.payout);
  assert.deepEqual(wallet.check(), { ok: true, errors: [] });
});

test("bilhete combinado: uma perna perdida liquida na hora como perdido", () => {
  const { tickets, sports, wallet, stats } = setup();
  const [e1, e2] = sports.list("football");
  tickets.toggle(e1.id, "x12", "h"); tickets.toggle(e2.id, "x12", "h");
  tickets.place(50, "combined");
  assert.equal(tickets.finishEvent(e1.id, [0, 3]).settled, 1);
  assert.equal(tickets.list()[0].status, "lost");
  assert.equal(wallet.summary().available, 1200);
  assert.equal(wallet.summary().reserved, 0);
  assert.equal(wallet.summary().gameResult, -50);
  assert.equal(stats.summary().rounds, 1);
  assert.equal(tickets.finishEvent(e2.id, [1, 0]).settled, 0);   // já liquidado
  assert.deepEqual(wallet.check(), { ok: true, errors: [] });
});

test("bilhetes simples: um bilhete por seleção, valor por seleção", () => {
  const { tickets, sports, wallet } = setup();
  const [e1, e2, e3] = sports.list("volleyball");
  [e1, e2, e3].forEach((e) => tickets.toggle(e.id, "ml", "h"));
  const r = tickets.place(20, "single", "k2");
  assert.equal(r.tickets.length, 3);
  assert.equal(wallet.summary().reserved, 60);
  tickets.finishEvent(e1.id, [3, 0]); tickets.finishEvent(e2.id, [1, 3]); tickets.finishEvent(e3.id, [3, 2]);
  const l = tickets.list();
  assert.deepEqual(l.map((t) => t.status).sort(), ["lost", "won", "won"]);
  assert.equal(wallet.summary().reserved, 0);
  assert.deepEqual(wallet.check(), { ok: true, errors: [] });
});

test("bilhete: validações e prevenção de duplicidade", () => {
  const { tickets, sports, wallet } = setup();
  assert.equal(tickets.place(10, "combined").ok, false);               // vazio
  const [e1, e2] = sports.list("esports");
  tickets.toggle(e1.id, "ml", "h"); tickets.toggle(e2.id, "ml", "h");
  assert.equal(tickets.place(0, "combined").ok, false);
  assert.equal(tickets.place(-5, "combined").ok, false);
  assert.equal(tickets.place(99999, "combined").ok, false);            // saldo
  assert.equal(wallet.summary().available, 1250);
  assert.ok(tickets.place(10, "combined", "dupkey").ok);
  tickets.toggle(e1.id, "ml", "h"); tickets.toggle(e2.id, "ml", "h");
  const again = tickets.place(10, "combined", "dupkey");
  assert.ok(again.ok);
  assert.equal(again.tickets.length, 0);                               // ignorado
  assert.equal(wallet.summary().reserved, 10);
  assert.equal(tickets.list().length, 1);
});

test("bilhete: evento encerrado não aceita novas seleções", () => {
  const { tickets, sports } = setup();
  const e = sports.list("mma")[0];
  tickets.finishEvent(e.id, [1, 0]);
  assert.equal(tickets.toggle(e.id, "ml", "h").ok, false);
  assert.equal(sports.finish(e.id, [1, 0]).ok, false);
  assert.equal(sports.finish("E99", [1, 0]).ok, false);
});

test("placar inválido é recusado", () => {
  const { sports } = setup();
  const e = sports.list()[0];
  [null, [1], [-1, 0], [1.5, 0], ["a", 1]].forEach((s) => assert.equal(sports.finish(e.id, s).ok, false));
});

test("persistência de esportes, bilhetes e histórico", () => {
  const a = setup();
  const [e1] = a.sports.list("football");
  a.sports.setOdds(e1.id, "x12", "h", 3.33);
  a.tickets.toggle(e1.id, "x12", "h");
  a.tickets.place(10, "combined");
  const sports2 = Sports.create({ storage: a.storage });
  const tickets2 = Tickets.create({ storage: a.storage, wallet: a.wallet, sports: sports2, stats: a.stats });
  assert.equal(sports2.get(e1.id).markets[0].sels[0].odds, 3.33);
  assert.equal(tickets2.list().length, 1);
});

test("estatísticas: resumo e filtro por jogo", () => {
  const { stats } = setup();
  stats.record("roulette", 10, 0, "x"); stats.record("roulette", 10, 20, "y"); stats.record("dice", 5, 11.5, "z");
  const s = stats.summary();
  assert.equal(s.rounds, 3); assert.equal(s.wins, 2);
  assert.equal(s.staked, 25); assert.equal(s.returned, 31.5); assert.equal(s.net, 6.5); assert.equal(s.best, 10);
  assert.equal(s.games.roulette, 2);
  assert.equal(stats.list("roulette").length, 2);
  assert.equal(stats.list("all", 1).length, 1);
  assert.equal(stats.list("dice")[0].detail, "z");
  stats.clear();
  assert.equal(stats.summary().rounds, 0);
});
